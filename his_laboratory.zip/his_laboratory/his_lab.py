# -*- coding: utf-8 -*-
##############################################################################
#
#    Harmoni HIS
#    Copyright (C) 2013 onwards Electronic Health Records International (<http://ehrinternational.com>).
#    By: Edwin N. Gonzales, EHRI-CTO
#    All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from mx import DateTime
import datetime
from osv import fields, osv
from tools.translate import _

# Add Lab test information to the Patient object

class patient_data (osv.osv):
    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'lab_test_ids': fields.one2many('his.lab.test','patient_id','Lab Tests Required'),
    }

patient_data ()

class lab_sec_data(osv.osv):

    _name = "his.department.section"
    _inherit = "his.department.section"
    _columns = {
        'lab_section_id' : fields.one2many ('his.lab.test_type', 'lab_section_id', 'Lab Section No.'),
    }

lab_sec_data ()

class test_type (osv.osv):
    _name = "his.lab.test_type"
    _description = "Type of Laboratory Test"
    _columns = {
        'name' : fields.char ('Test Name',size=128),
        'lab_section_id': fields.many2one('his.department.section','Lab Section No.', domain="[('hr_department_id.section_group','=','Laboratory')]"),
        'code' : fields.char ('Code',size=128,help="Short name - code for the test"),
        'info' : fields.text ('Description'),
        'product_id' : fields.many2one('product.product', 'Service', required=True, domain="[('type','=','service')]"),
        'critearea': fields.one2many('his.lab.test_critearea','test_type_id','Test Cases'),
    }

    _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The Lab Test Name must be unique')]

test_type ()

class lab (osv.osv):
    _name = "his.lab"
    _description = "Lab Test"
    _columns = {
        'lab_section': fields.many2one('his.department.section','Lab Section No.', domain="[('hr_department_id.section_group','=','Laboratory')]"),
        'name' : fields.char ('ID', size=128, help="Lab result ID"),
        'test' : fields.many2one ('his.lab.test_type', 'Test type', help="Lab test type"),
        'patient' : fields.many2one ('res.partner', 'Patient', help="Patient ID", domain="[('customer','=',True)]"),
        'pathologist' : fields.many2one ('hr.employee','Pathologist',help="Pathologist", domain="[('doctor','=',True)]"),
        'requestor' : fields.many2one ('hr.employee', 'Physician', help="Doctor who requested the test", domain="[('doctor','=',True)]"),
        'results' : fields.text ('Results'),
        'diagnosis' : fields.text ('Diagnosis'),
        'critearea': fields.one2many('his.lab.test_critearea','his_lab_id','Test Cases'),
        'date_requested' : fields.datetime ('Date Requested'),
        'date_analysis' : fields.datetime ('Date of the Analysis'),
        'lab_inf_no' : fields.char ('Lab Info No.', size=128,),
        #'specimen' : fields.char ('Specimen', size=128,),
        #'collection_site' : fields.char ('Site of Collection', size=128,),
        #'collected_by' : fields.char ('Collected By', size=128,),
        #'date_collected' : fields.datetime ('Date and Time Collected'),
        #'date_received' : fields.datetime ('Date and Time Received'),
        #'received_by' : fields.char ('Recived By', size=128,),
        #'lab_info_no' : fields.char ('Lab Info No.', size=128,),
    }

    _defaults = {
        'date_requested': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'date_analysis': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        #'date_collected': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        #'date_received': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'name' : lambda obj, cr, uid, context: obj.pool.get('ir.sequence').get(cr, uid, 'his.lab'),
    }

    _sql_constraints = [
                ('id_uniq', 'unique (name)', 'The test ID code must be unique')]
lab ()

class lab_test_units(osv.osv):
    _name = "his.lab.test.units"
    _description = "Lab Test Units"
    _columns = {
        'name' : fields.char('Unit', size=25),
        'code' : fields.char('Code', size=25),
        }
    _sql_constraints = [
            ('name_uniq', 'unique(name)', 'The Unit name must be unique')]

lab_test_units()

class lab_test_critearea(osv.osv):
    _name = "his.lab.test_critearea"
    _description = "Lab Test Critearea"
    _columns ={
       'name' : fields.char('Test', size=64),
       'result' : fields.text('Result'),
       'normal_range' : fields.text('Normal Range'),
       'units' : fields.many2one('his.lab.test.units', 'Units'),
       'test_type_id' : fields.many2one('his.lab.test_type','Test type'),
       'his_lab_id' : fields.many2one('his.lab','Test Cases'),
       'sequence' : fields.integer('Sequence'),
       }
    _defaults = {
         'sequence' : lambda *a : 1,
         }
    _order="sequence"
lab_test_critearea()



class his_patient_lab_test(osv.osv):
    _name = 'his.patient.lab.test'

    def onchange_name(self, cr, uid, ids, name, pricelist_id, patient_id):

        val = {}
        service_id = self.pool.get('his.lab.test_type').browse(cr, uid, name, context=None).product_id.id
        price = self.pool.get('product.pricelist').price_get(cr, uid, [pricelist_id],
                service_id, 1.0, patient_id)[pricelist_id]
        #raise osv.except_osv(_('Debug !'),_('Patient ID %s') % (price))
        return {'value': {'price': price}}
    
    def onchange_charge_to_phic(self, cr, uid, ids, phic_balance, price, charge_to_phic):
        if charge_to_phic == True:
            if phic_balance < price:
                warn_msg = "PHIC Passbook Balance is not enough.\n\n Total Charges: " + str("%.2f" % price) + "\n PHIC Balance: " + str("%.2f" % phic_balance)
                return {'value':{'charge_to_phic':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
            else:
                return {'value': {'charge_to' : False}}
        return True
    
    def onchange_pdaf_balance(self, cr, uid, ids, pdaf_balance, price, charge_to, partner_sponsor_id):
        if pdaf_balance < price and charge_to == True and partner_sponsor_id != False:
            warn_msg = "PDAF Balance is not enough.\n\n Total Charges: " + str("%.2f" % price) + "\n PDAF Balance: " + str("%.2f" % pdaf_balance)
            return {'value':{'partner_sponsor_id':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
        return True
        
    def onchange_charge_to(self, cr, uid, ids, charge_to):
        if charge_to == True:
           return {'value': {'charge_to_phic' : False, 'partner_sponsor_id' : False}}
        return {'value': {'partner_sponsor_id' : False}}
        
    def onchange_partner_sponsor_id(self, cr, uid, ids, partner_sponsor_id, patient_id):
        #if not part:
        #    return {'value': {}}
        pdaf_balance = 0.00
        if patient_id:
            if partner_sponsor_id:
                sponsored_patient = self.pool.get('his.sponsored.patients')
                sponsored_patient_id = sponsored_patient.search(cr, uid, [('sponsored_patient_name', '=', patient_id),('name', '=', partner_sponsor_id), ('state', '=', 1)])
                
                if sponsored_patient_id:
                    pdaf_balance = sponsored_patient.browse(cr, uid, sponsored_patient_id[0], context=None).balance
        
        return {'value': {'pdaf_balance' : pdaf_balance}}
    
    def onchange_patient_id(self, cr, uid, ids, patient):
        if not patient:
            return {'value': {'pricelist_id': False}}

        val = {}
        val['patient_adstatus'] = False
        part = self.pool.get('res.partner').browse(cr, uid, patient)
        
        phic_passbook = self.pool.get('philhealth.passbook')
        phic_id = phic_passbook.search(cr, uid, [('name','=',patient), ('active','=',True)])
        val['phic_balance'] = 0.00
        val['with_phic'] = False
        val['with_pdaf'] = False
        if phic_id:
            val['with_phic'] = True
            val['phic_balance'] = self.pool.get('philhealth.passbook').get_phic_passbook_balance(cr, uid, patient, True, bal='xlab')
            #raise osv.except_osv(_('Debug !'),_('Patient ID %s') % (val['phic_balance']))
        
        sponsor_ids = []
        for sponsor in self.pool.get('his.sponsored.patients').search(cr, uid, [('sponsored_patient_name', '=', patient), ('state', '=', 1)]):
            if sponsor:
                val['with_pdaf'] = True
                sponsor_ids.append(self.pool.get('his.sponsored.patients').browse(cr, uid, sponsor, context=None).name.id)
        val['sponsor_ids'] = str(sponsor_ids)
        #raise osv.except_osv(_('Debug !'),_('Patient ID %s') % (phic_id))
        admitted = part.admitted
        val['ward_name'] = False
        val['bed_name'] = False
        if admitted == True:
            admission_id = self.pool.get('his.admission').search(cr, uid, [('name', '=', part.id),('state', '=', "Admitted")])
            val['patient_adstatus'] = True
            admission_info = self.pool.get('his.admission').browse(cr, uid, admission_id[0])
            val['clinic'] = admission_info.clinic_id.name
            class_type = admission_info.class_type.id
            val['class_id'] = class_type
            #raise osv.except_osv(_('Debug !'),_('Patient ID %s') % (class_type))
            room_transfer_id = self.pool.get('his.room.transfer').search(cr, uid, [('admission_id', '=', admission_id[0]),('t_out', '=', False)])
            if room_transfer_id:
                room_transfer = self.pool.get('his.room.transfer').browse(cr, uid, room_transfer_id[0])
                ward=room_transfer.ward_no.name.name
                bed=room_transfer.bed_no.name.name
                val['ward_name'] = ward
                val['bed_name'] = bed

        #raise osv.except_osv(_('Debug !'),_('Patient ID %s. Partner ID %s') % (patient.id, part.id))

        pricelist = part.property_product_pricelist and part.property_product_pricelist.id or False
        if pricelist:
            val['pricelist_id'] = pricelist
        return {'value': val}

    #def _get_default_dr(self, cr, uid, context={}):
    #    partner_id = self.pool.get('res.partner').search(cr,uid,[('user_id','=',uid)])
    #    if partner_id:
    #        dr_id = self.pool.get('medical.physician').search(cr,uid,[('name','=',partner_id[0])])
    #        if dr_id:
    #            return dr_id[0]
            #else:
            #    raise osv.except_osv(_('Error !'),
            #            _('There is no physician defined ' \
            #                    'for current user.'))
    #    else:
    #        return False

    _columns = {
        'lab_section_no': fields.many2one('his.department.section','Lab Section No.', domain="[('hr_department_id.section_group','=','Laboratory')]"),
        'name' : fields.many2one('his.lab.test_type','Test Type', domain="[('lab_section_id','=',lab_section_no)]"),
        'date' : fields.datetime('Date'),
        'state' : fields.selection([('draft','Draft'),('tested','Tested'),('cancel','Cancel')],'State',readonly=True),
        'patient_id' : fields.many2one('res.partner','Patient', change_default=True, select=True),
        'partner_patient_id' : fields.many2one('res.partner','Patient'),
        'pricelist_id': fields.many2one('product.pricelist', 'Pricelist', readonly=True, states={'draft': [('readonly', False)]}),
        'doctor_id' : fields.many2one('hr.employee','Doctor', domain="[('doctor','=',True)]", help="Doctor who Request the lab test."),
        #'patient_status': fields.related ('patient_id','admitted',type="boolean",string="Admitted?",store=False, readonly=True),
        'note' : fields.text('Desired Examnation:'),
        'lab_diagnosis' : fields.text('Diagnosis:'),
        'specimen' : fields.char ('Specimen', size=128,),
        'collection_site' : fields.char ('Site of Collection', size=128,),
        'collected_by' : fields.char ('Collected By', size=128,),
        'date_collected' : fields.datetime ('Date and Time Collected'),
        'date_received' : fields.datetime ('Date and Time Received'),
        'received_by' : fields.char ('Recived By', size=128,),
        'lab_info_no' : fields.char ('Lab Info No.', size=128,),
        'ward_name' : fields.char ('Ward', size=128,),
        'bed_name' : fields.char ('Bed', size=128,),
        'clinic' : fields.char ('Clinic', size=128,),
        'class_id' : fields.many2one('his.social_services_class','SSC', select=True),
        'patient_adstatus' : fields.boolean ('Admitted'),
        'price' : fields.float ('Price'),
        'phic_balance' : fields.float ('Balance'),
        'charge_to' : fields.boolean ('Charge to Sponsor'),
        'pdaf_balance' : fields.float ('Balance'),
        'sponsor_ids' : fields.char ('Sponsor ID', size = 20),
        'partner_sponsor_id': fields.many2one('res.partner', 'Charge to', change_default=True, select=1, domain="[('donor', '=', True)]"),
        'lab_request_id' : fields.many2one('his.patient.lab.request','Lab Test Request ID', change_default=True, select=True),
        'charge_to_phic' : fields.boolean ('Charge to PHIC'),
        'with_phic' : fields.boolean ('With PHIC'),
        'with_pdaf' : fields.boolean ('With PDAF'),
        
    }

    _defaults={
       'date' : lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
       'date_collected': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
       'date_received': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
       'state' : lambda *a : 'draft',
       #'doctor_id' : _get_default_dr,
    }

his_patient_lab_test()

class his_patient_lab_request(osv.osv):
    _name = "his.patient.lab.request"
    _description = "Lab Test Request"
    _columns ={
       'patient_id' : fields.many2one('res.partner','Patient', change_default=True, select=True, domain="[('customer', '=', True)]"),
       'lab_section_no': fields.many2one('his.department.section','Lab Section No.', domain="[('hr_department_id.section_group','=','Laboratory')]"),
       'date' : fields.datetime('Date'),
       'ward_name' : fields.char ('Ward', size=128,),
       'bed_name' : fields.char ('Bed', size=128,),
       'patient_adstatus' : fields.boolean ('Admitted'),
       'doctor_id' : fields.many2one('hr.employee','Doctor', domain="[('doctor','=',True)]", help="Doctor who Request the lab test."),
       'pricelist_id': fields.many2one('product.pricelist', 'Pricelist'),
       'his_patient_lab_test' : fields.one2many('his.patient.lab.test', 'lab_request_id', 'Lab Test'),
       }
    
    _defaults={
       'date' : lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    def onchange_patient_id(self, cr, uid, ids, patient):
        if not patient:
            return {'value': {'pricelist_id': False}}

        val = {}
        val['patient_adstatus'] = False
        part = self.pool.get('res.partner').browse(cr, uid, patient)
        admitted = part.admitted
        val['ward_name'] = False
        val['bed_name'] = False
        if admitted == True:
            admission_id = self.pool.get('his.admission').search(cr, uid, [('name', '=', part.id),('state', '=', "Admitted")])
            val['patient_adstatus'] = True
            room_transfer_id = self.pool.get('his.room.transfer').search(cr, uid, [('admission_id', '=', admission_id[0]),('t_out', '=', False)])
            if room_transfer_id:
                room_transfer = self.pool.get('his.room.transfer').browse(cr, uid, room_transfer_id[0])
                ward=room_transfer.ward_no.name.name
                bed=room_transfer.bed_no.name.name
                val['ward_name'] = ward
                val['bed_name'] = bed

        pricelist = part.property_product_pricelist and part.property_product_pricelist.id or False
        if pricelist:
            val['pricelist_id'] = pricelist
        return {'value': val}
        
his_patient_lab_request()


