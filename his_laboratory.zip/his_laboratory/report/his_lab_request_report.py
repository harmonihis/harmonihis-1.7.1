import time
from report import report_sxw
#from osv import fields, osv

class his_lab_request_form(report_sxw.rml_parse):

    def __init__(self, cr, uid, conn, context):
        super(his_lab_request_form, self).__init__(cr, uid, conn, context=context)
        self.total = 0.0
        self.localcontext.update({
            'time': time,
        })
        self.context = context
        self._node = None

report_sxw.report_sxw('report.patient.labrequest', 'his.patient.lab.test', 'addons/his_laboratory/report/his_lab_request_form.rml', parser=his_lab_request_form, header='False')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
