# -*- encoding: utf-8 -*-
{

        'name' : 'Hospital Laboratory',
        'version' : '1.0.4',
        'author' : 'Edwin N. Gonzales',
        'category' : 'Generic Modules/Others',
        'depends' : ['product','hospital_mgmt', 'his_clinics', 'hr'],
        'description' : """

Provides hospital laboratory processing and patient charges management


""",
        "website" : "",
        "init_xml" : [],
        #"update_xml" : ["security/ir.model.access.csv", "his_lab_view.xml", "his_lab_report.xml", "data/his_lab_sequences.xml"],
        "update_xml" : ["his_lab_view.xml", "data/his_lab_sequences.xml", "wizard/create_lab_test.xml", "his_lab_report.xml"],
        "active": False
}

