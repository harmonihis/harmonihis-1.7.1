# -*- coding: utf-8 -*-
{

    'name' : 'Clinics/hrDept',  
    'version' : '3.0',
    'author' : 'vince',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['hospital_mgmt', 'hr', 'sale'],
    'description' : """

HIS Clinics

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["his_clinics.xml", "hr_department_cus.xml", "res_user_custom_view.xml"],
    "active": False 
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
