from osv import fields, osv
from tools.translate import _


class his_department_section(osv.osv):

    _name = 'his.department.section'
    _columns = {
        'name' : fields.char ('Section No.', size=10),
        'section_name' : fields.char ('Section Name', size=50),
        'hr_department_id' : fields.many2one ('hr.department','Department',domain="[('lab_rad_section','=',True)]"),
    }

    #_defaults = {
    #    'medic_sec': lambda *a: False,
    #    'charity': lambda *a: False,
    #}

his_department_section()

class hr_department_c(osv.osv):

    _name = 'hr.department'
    _inherit = 'hr.department'
    _columns = {
        'medic_sec' : fields.boolean ('Medical Section',),
        'charity' : fields.boolean ('Charity',),
        'nurse_station' : fields.boolean ('Nurse Station',),
        'lab_rad_section' : fields.boolean ('Lab/Rad Section',),
        'nurse_partner_id' : fields.many2one ('res.partner','Charge to',domain="[('nurse_station','=',True)]"),
        'dept_group' : fields.selection ([('DEMS','DEMS'), ('OB-AS','OB-AS'), ('OPD','OPD'), ('DPPS','DPPS')],'Group'),
        'his_department_section_id' : fields.one2many ('hr.department.section', 'hr_department_id', 'Section'),
        'section_group' : fields.selection ([('Laboratory','Laboratory'), ('Radiology','Radiology')],'Group'),
    }

    def onchange_medic_sec(self, cr, uid, ids, medic_sec):
        if medic_sec == False:
            return {'value': {'charity': False, 'dept_group': False}}
        else:
            return {'value': {'charity': False, 'nurse_station': False, 'dept_group': False, 'lab_rad_section': False}}

    def onchange_nurse_station(self, cr, uid, ids, nurse_station):
        if nurse_station == True:
            return {'value': {'medic_sec': False, 'nurse_partner_id': False, 'lab_rad_section': False}}
        else:
            return {'value': {'nurse_partner_id': False}}

    def onchange_lab_rad_section(self, cr, uid, ids, lab_rad_section):
        if lab_rad_section == True:
            return {'value': {'medic_sec': False, 'nurse_station': False}}
        else:
            return {'value': {'section_group': False}}

    _defaults = {
        'medic_sec': lambda *a: False,
        'charity': lambda *a: False,
    }

hr_department_c()






