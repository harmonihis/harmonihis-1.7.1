from osv import fields, osv
from tools.translate import _

class res_users_custom(osv.osv):
    _name = "res.users"
    _inherit = 'res.users'
    _columns = {
        'pharmacist' : fields.boolean ('Pharmacist',),
        'nurse' : fields.boolean ('Nurse',),
        'job_id' : fields.many2one ('hr.job', 'Designation',),
        'shop_id' : fields.many2one ('sale.shop', 'Primary Shop', domain="[('nurse_station', '=', nurse)]"),
        'secondary_shop_id' : fields.many2one ('sale.shop', 'Secondary Shop', domain="[('parent_shop_id', '=', shop_id)]"),
    }
    
    def onchange_shop_id(self, cr, uid, ids, shop_id, context=None):
        result = {'value':{'secondary_shop_id': False}}
        return result
        
    def onchange_pharmacist(self, cr, uid, ids, pharmacist, context=None):
        if pharmacist == True:
            result = {'value':{'nurse':False, 'shop_id': False}}
        else:
            result = {'value':{'shop_id': False}}
        return result
        
    def onchange_nurse(self, cr, uid, ids, nurse, context=None):
        if nurse == True:
            result = {'value':{'pharmacist':False, 'shop_id': False}}
        else:
            result = {'value':{'shop_id': False}}
        return result
        
res_users_custom()

class hr_job_custom(osv.osv):
    _name = "hr.job"
    _inherit = 'hr.job'
    _columns = {
        'res_users_id' : fields.one2many ('res.users', 'job_id', 'User ID',),
    }
hr_job_custom()

class res_partner_nurse_custom(osv.osv):
    _name = "res.partner"
    _inherit = 'res.partner'
    _columns = {
        'nurse_station' : fields.boolean ('Nurse Station'),
    }
res_partner_nurse_custom()

class sale_shop_custom(osv.osv):
    _name = "sale.shop"
    _inherit = 'sale.shop'
    _columns = {
        'parent_shop_id' : fields.many2one ('sale.shop', 'Parent Shop Name'),
        'phic_passbook' : fields.boolean ('PhilHealth Passbook'),
        'whitecard' : fields.boolean ('White Card'),
        'pdaf' : fields.boolean ('PDAF'),
        'ecart' : fields.boolean ('E-cart'),
        'caap' : fields.boolean ('CAAP'),
        'walk_in' : fields.boolean ('Walk-in'),
        'nurse_station' : fields.boolean ('Nurse Station'),
        'phic_passbook_auto' : fields.boolean ('PHIC Atomatic Charging'),
    }
    def onchange_phic_passbook(self, cr, uid, ids, phic_passbook, context=None):
        result = {'value':{'phic_passbook_auto':False}}
        return result
        
hr_job_custom()
