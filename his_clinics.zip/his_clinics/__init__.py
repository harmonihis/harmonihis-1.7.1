# -*- coding: utf-8 -*-
import his_clinics
import hr_department_cus
import res_user_custom

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
