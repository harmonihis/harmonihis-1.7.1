from osv import fields, osv
from tools.translate import _

class his_clinics(osv.osv):
    _name = "his.clinics"
    _description = "Clinics"
    _columns = {
        'name' : fields.char ('Clinics', size=30, required="1"),
        'location' : fields.char ('Location', size=60,),
        'department_id' : fields.many2one ('hr.department','Department',),
        'charity' : fields.related ('department_id','charity',type='boolean',string='Charity Department?',store=True, readonly=True),
        
    }
    
his_clinics ()

class hr_department_custom(osv.osv):
    _name = "hr.department"
    _inherit = 'hr.department'
    _columns = {
        'clinic_id' : fields.one2many ('his.clinics', 'department_id', 'Clinic ID',),
    }
hr_department_custom()

