{

    'name' : 'Hospital Management',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : [],
    'description' : """

Hospital Management Menu

""",
	"website" : "http://www.fossibility.com",
	"init_xml" : [],
	"update_xml" : ["hospital_mgmt_view.xml"],
	"active": False 
}
