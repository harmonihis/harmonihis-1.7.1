# -*- coding: utf-8 -*-
##############################################################################
#
#    Harmoni HIS
#    Copyright (C) 2013 onwards Electronic Health Records International (<http://ehrinternational.com>).
#    By: Edwin N. Gonzales, EHRI-CTO
#    All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging

from osv import fields, osv
import pooler
from tools.translate import _
import sys

logging.basicConfig(level=logging.DEBUG)

class create_test_invoice(osv.osv_memory):
    _name='his.lab.test.invoice'

    def get_unit_price(self, cr, uid, ids, pricelist, product, qty=0, uom=False, partner_id=False, date_order=False, context=None):
        if not pricelist:
            warn_msg = _('You have to select a pricelist or a patient.\n'
                    'Please set one before creating the invoice.')
            raise osv.except_osv(_('No Pricelist!'),warn_msg)
        else:
            price = self.pool.get('product.pricelist').price_get(cr, uid, [pricelist],
                    product, qty or 1.0, partner_id, {'uom': uom,'date': date_order,})[pricelist]
            if price is False:
                warn_msg = _("Couldn't find a pricelist line matching this laboratory test.\n"
                        "You have to change either the laboratory test or the pricelist.")
                raise osv.except_osv(_('No Pricelist!'),warn_msg)
            else:
                #result.update({'price_unit': price})
                return price

#Added by Edwin Gonzales
    def get_pricelist(self, cr, uid, ids, patient):
        pricelist_id = False
        
        part = self.pool.get('res.partner').browse(cr, uid, patient)
        
        pricelist = part.property_product_pricelist and part.property_product_pricelist.id or False
        #raise osv.except_osv(_('Debug !'),_('Pricelist ID %s') % (pricelist))

        if pricelist:
            pricelist_id = pricelist
        return pricelist_id
#End

    def create_lab_invoice(self, cr, uid, ids, context={}):

        invoice_obj = self.pool.get('account.invoice')
        test_request_obj = self.pool.get('his.patient.lab.test')

#Added by Edwin Gonzales
        mod_obj = self.pool.get('ir.model.data')
#End

        tests = context.get ('active_ids')
        logging.debug('tests = %s', repr(tests))
        
        pats = []
        for test_id in tests:
            #pats.append(test_request_obj.browse(cr, uid, test_id).patient_id)
            cur_test = test_request_obj.browse(cr, uid, test_id)
            logging.debug('cur_test = %s; pats = %s', repr(cur_test), repr(pats))
            pats.append(cur_test.patient_id)
    
        logging.debug('pats = %s', repr(pats))
    
        if pats.count(pats[0]) == len(pats):
            invoice_data = {}
            for test_id in tests:
                #test = self.browse(cr, uid, test_id)
                test = test_request_obj.browse(cr, uid, test_id)
                logging.debug('test = %s', repr(test))
                if test.invoice_status == 'invoiced':
                    if len(tests) > 1:
                        raise  osv.except_osv(_('UserError'), _('At least one of the selected lab tests is already invoiced'))
                    else:
                        raise  osv.except_osv(_('UserError'), _('Lab test already invoiced'))
                if test.invoice_status == 'no':
                    if len(tests) > 1:
                        raise  osv.except_osv(_('UserError'), _('At least one of the selected lab tests can not be invoiced'))
                    else:
                        raise  osv.except_osv(_('UserError'), _('You can not invoice this lab test'))
    
            logging.debug('test.patient_id = %s; test.patient_id.id = %s', test.patient_id, test.patient_id.id)
            if test.patient_id.id:
                invoice_data['partner_id'] = test.patient_id.id
                res = self.pool.get('res.partner').address_get(cr, uid, [test.patient_id.id], ['contact', 'invoice'])
                invoice_data['address_contact_id'] = res['contact']
                invoice_data['address_invoice_id'] = res['invoice']
                #invoice_data['state'] = 'draft'
                invoice_data['account_id'] = test.patient_id.property_account_receivable.id
                invoice_data['fiscal_position'] = test.patient_id.property_account_position and test.patient_id.property_account_position.id or False
                invoice_data['payment_term'] = test.patient_id.property_payment_term and test.patient_id.property_payment_term.id or False
            prods_data = {}

            tests = context.get ('active_ids')
            logging.debug('tests = %s', repr(tests))

#Added by Edwin Gonzales
#Check if there are tests that does not have a pricelist and assign appropriately
            pricelist_exist = True
            for test_id in tests:
                if not test.pricelist_id.id:
                    pricelist_exist = False
                    #test_request_obj.onchange_patient_id(cr, uid, ids, test.patient_id.id)
                    test_request_obj.write(cr, uid, test_id, {'pricelist_id': self.get_pricelist(cr, uid, ids, test.patient_id.id) })
                    #raise osv.except_osv(_('Debug !'),_('Test ID %s') % (test_id))
            if not pricelist_exist:
                return
#End

            for test_id in tests:
                test = test_request_obj.browse(cr, uid, test_id)
                logging.debug('test.name = %s; test.name.product_id = %s; test.name.product_id.id = %s', test.name, test.name.product_id, test.name.product_id.id)

                if prods_data.has_key(test.name.product_id.id):
                    logging.debug('prods_data = %s; test.name.product_id.id = %s', prods_data, test.name.product_id.id)
                    prods_data[test.name.product_id.id]['quantity'] += 1
                else:
                    logging.debug('test.name.product_id.id = %s', test.name.product_id.id)
                    a = test.name.product_id.product_tmpl_id.property_account_income.id
                    if not a:
                        a = test.name.product_id.categ_id.property_account_income_categ.id
                    prods_data[test.name.product_id.id] = {'product_id':test.name.product_id.id,
                                    'name':test.name.product_id.name,
                                    'quantity':1,
                                    'account_id':a,
                                    'price_unit': self.get_unit_price(cr, uid, ids, test.pricelist_id.id, test.name.product_id.id, context=context) or test.name.product_id.lst_price}
                    logging.debug('prods_data[test.name.product_id.id] = %s', prods_data[test.name.product_id.id])

            product_lines = []
            for prod_id, prod_data in prods_data.items():
                product_lines.append((0, 0, {'product_id':prod_data['product_id'],
                        'name':prod_data['name'],
                        'quantity':prod_data['quantity'],
                        'account_id':prod_data['account_id'],
                        'price_unit':prod_data['price_unit']}))
                
            invoice_data['invoice_line'] = product_lines
            
            patient_lab_test_id = (context.get('active_ids'))
            patient_lab_test = test_request_obj.browse(cr, uid, patient_lab_test_id[0])
            partner_patient_id = patient_lab_test.patient_id.id
            price = patient_lab_test.price
            
#compute for PHIC
            charge_to_phic = patient_lab_test.charge_to_phic
            if charge_to_phic == True:
                philhealth_passbook_id = self.pool.get('philhealth.passbook').update_phic_passbook_balance(cr, uid, ids, partner_patient_id, price, bal='xlab')
                #raise osv.except_osv(_('Warning'),_(" '%s'.") % (test_request_obj.write(cr, uid, ids, { 'philhealth_passbook_id' : philhealth_passbook_id})))
                test_request_obj.write(cr, uid, patient_lab_test_id[0], { 'philhealth_passbook_id' : philhealth_passbook_id})
#end

#compute for PDAF
            charge_to_pdaf = patient_lab_test.charge_to
            partner_id = patient_lab_test.partner_sponsor_id.id
            #raise osv.except_osv(_('Warning'),_(" '%s'.") % (charge_to_phic))
            if charge_to_pdaf == True:
                invoice_data['partner_id'] = partner_id
                sponsored_patient = self.pool.get('his.sponsored.patients')
                sponsored_patient_id = sponsored_patient.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id),('name', '=', partner_id), ('state', '=', 1)])
                sponsored_patient_res = sponsored_patient.browse(cr, uid, sponsored_patient_id[0], context=None)
                sponsored_patient_balance = sponsored_patient_res.balance - price
                sponsored_patient.write(cr, uid, sponsored_patient_id, { 'balance' : sponsored_patient_balance })
#end

            invoice_id = invoice_obj.create(cr, uid, invoice_data)
            
            test_request_obj.write(cr, uid, tests, {'invoice_status':'invoiced'})
            #raise osv.except_osv(_('Warning'),_(" '%s'.") % (invoice_data))
#Added by Edwin Gonzales
            srcres = mod_obj.get_object_reference(cr, uid, 'account', 'view_account_invoice_filter')
            res = mod_obj.get_object_reference(cr, uid, 'account', 'invoice_form')
            res_id = res and res[1] or False,
#End
            #return self.pool.get('account.invoice.confirm').invoice_confirm(cr, uid, invoice_id, context=context)

            return {
                'domain': "[('id','=', " + str(invoice_id) + ")]",
                'name': 'Create Lab Invoice',
                'view_type': 'form',
                'res_model': 'account.invoice',
                'type': 'ir.actions.act_window',
#Added/Modified by Edwin Gonzales
                'view_mode': 'form',
                'view_id': [res_id],
                'target': 'current',
                'res_id': invoice_id or False,
                'search_view_id': srcres and srcres[1] or False
#End
            }
    
        else:
            raise  osv.except_osv(_('UserError'), _('When multiple lab tests are selected, patient must be the same'))


create_test_invoice()


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
