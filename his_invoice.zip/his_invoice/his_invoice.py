# -*- coding: utf-8 -*-
##############################################################################
#
#    Harmoni HIS
#    Copyright (C) 2013 onwards Electronic Health Records International (<http://ehrinternational.com>).
#    By: Edwin N. Gonzales, EHRI-CTO
#    All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields, osv
from tools.translate import _
from mx import DateTime
import datetime

# Add Invoicing information to the Lab Test

class labtest (osv.osv):
    _name = "his.patient.lab.test"
    _inherit = "his.patient.lab.test"

    _columns = {
        'no_invoice' : fields.boolean ('Invoice exempt'),
        'invoice_status' : fields.selection([('invoiced','Invoiced'),('tobe','To be Invoiced')],'Invoice Status'),
    }
    
    _defaults={
        'invoice_status': lambda *a: 'tobe',
        'no_invoice': lambda *a: True
    }
    
labtest()

class radexam (osv.osv):
    _name = "his.patient.rad.exam"
    _inherit = "his.patient.rad.exam"

    _columns = {
        'no_invoice' : fields.boolean ('Invoice exempt'),
        'invoice_status' : fields.selection([('invoiced','Invoiced'),('tobe','To be Invoiced')],'Invoice Status'),
    }
    
    _defaults={
        'invoice_status': lambda *a: 'tobe',
        'no_invoice': lambda *a: True
    }
    
radexam()

