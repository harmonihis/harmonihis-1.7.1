# -*- coding: utf-8 -*-
{

    'name' : 'Discount list',  
    'version' : '3.0',
    'author' : 'vince',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['hospital_mgmt'],
    'description' : """

HIS Discount List

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["his_discounts.xml"],
    "active": False 
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
