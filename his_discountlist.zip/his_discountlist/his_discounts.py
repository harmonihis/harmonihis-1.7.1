from osv import fields, osv
from tools.translate import _

from osv import fields, osv
from tools.translate import _

class his_discounts(osv.osv):
    _name = "his.discounts"
    _description = "Discounts"
    _columns = {
        'name' : fields.char('Discount Name',size=15,required=True),
        'description' : fields.char('Description',size=15),
        'pharma_pctg' : fields.float('Discount(%)'),
        'pricelist_id' : fields.property(
            'product.pricelist',
            type='many2one', 
            relation='product.pricelist', 
            domain=[('type','=','sale')],
            string="Sale Pricelist", 
            view_load=True,
            help="This pricelist will be used, instead of the default one, for sales to the current partner"),
    }
his_discounts ()

