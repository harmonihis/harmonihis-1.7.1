##############################################################################
#
#    Harmoni HIS
#    Copyright (C) 2013 onwards Electronic Health Records International (<http://ehrinternational.com>).
#    By: Edwin N. Gonzales, EHRI-CTO and Jaynar L. Santos, EHRI-Senior Programmer
#    All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import time
from dateutil.relativedelta import relativedelta
from datetime import datetime
from osv import fields, osv
from tools.translate import _


class pathology_category(osv.osv):
        def name_get(self, cr, uid, ids, context={}):
                if not len(ids):
                        return []
                reads = self.read(cr, uid, ids, ['name','parent_id'], context)
                res = []
                for record in reads:
                        name = record['name']
                        if record['parent_id']:
                                name = record['parent_id'][1]+' / '+name
                        res.append((record['id'], name))
                return res

        def _name_get_fnc(self, cr, uid, ids, prop, foo, faa):
                res = self.name_get(cr, uid, ids)
                return dict(res)
        def _check_recursion(self, cr, uid, ids):
                level = 100
                while len(ids):
                        cr.execute('select distinct parent_id from medical_pathology_category where id in ('+','.join(map(str,ids))+')')
                        ids = filter(None, map(lambda x:x[0], cr.fetchall()))
                        if not level:
                                return False
                        level -= 1
                return True

        _description='Disease Categories'
        _name = 'medical.pathology.category'
        _columns = {
                'name': fields.char('Category Name', required=True, size=128),
                'parent_id': fields.many2one('medical.pathology.category', 'Parent Category', select=True),
                'complete_name': fields.function(_name_get_fnc, method=True, type="char", string='Name'),
                'child_ids': fields.one2many('medical.pathology.category', 'parent_id', 'Children Category'),
                'active' : fields.boolean('Active'),
        }
        _constraints = [
                (_check_recursion, 'Error ! You can not create recursive categories.', ['parent_id'])
        ]
        _defaults = {
                'active' : lambda *a: 1,
        }
        _order = 'parent_id,id'

pathology_category()


class pathology (osv.osv):
    _name = "medical.pathology"
    _description = "Diseases"
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['name','code'], context=context)
        res = []
        for record in reads:
            name = record['code'] + ' - ' + record['name']
            res.append((record['id'], name))
        return res
        
    _columns = {
        'name' : fields.char ('Name', size=128, help="Disease name"),
        'code' : fields.char ('Code', size=32, help="Specific Code for the Disease (eg, ICD-10, SNOMED...)"),
        'category' : fields.many2one('medical.pathology.category','Disease Category'),
        'chromosome' : fields.char ('Affected Chromosome', size=128, help="chromosome number"),
        'protein' : fields.char ('Protein involved', size=128, help="Name of the protein(s) affected"),
        'gene' : fields.char ('Gene', size=128, help="Name of the gene(s) affected"),
        'info' : fields.text ('Extra Info'),
    }

    _sql_constraints = [
            ('code_uniq', 'unique (code)', 'The disease code must be unique')]


    def name_search(self, cr, uid, name, args=[], operator='ilike', context={}, limit=80):
        args2 = args[:]
        if name:
                args += [('name', operator, name)]
                args2 += [('code', operator, name)]
        ids = self.search(cr, uid, args, limit=limit)
        ids += self.search(cr, uid, args2, limit=limit)
        res = self.name_get(cr, uid, ids, context)
        return res

pathology ()
