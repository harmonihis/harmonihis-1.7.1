# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


import time
from mx import DateTime
import datetime
from osv import fields, osv
from tools.translate import _

#DEBUG MODE -- DELETE ME !
# import pdb

class phic_casetypes (osv.osv):
    _name = "hospbill.phic_casetypes"
    _description = "PHIC Case Types"
    _columns = {
        'name' : fields.char ('Case type',size=1), 
        'roomboard' : fields.float ('Room and Board'),
        'roomboard_maxdays' : fields.integer ('Maximum Days'),
        'roomboard_cat' : fields.one2many ('hospbill.phic_roomboard_cat', 'name', 'PHIC Room and Board Product Categories'),
        'drugmed' : fields.float ('Drugs and Medicines'),
        'drugsmeds_cat' : fields.one2many ('hospbill.phic_drugsmeds_cat', 'name', 'PHIC Drugs and Medicines Product Categories'),
        'xraylabsupp' : fields.float ('X-Ray, Lab, and Supplies'),
        'xraylabsupp_cat' : fields.one2many ('hospbill.phic_xraylabsupp_cat', 'name', 'PHIC X-Ray, Lab, and Supplies Product Categories'),
        'pfgpperday' : fields.float ('PF-General Practitioner'),
        'pfgpmax' : fields.float ('PF-General Practitioner Maximum'),
        'pfgp_cat' : fields.one2many ('hospbill.phic_pfgp_cat', 'name', 'PHIC Professional Fee: General Practitioner Product Categories'),
        'pfspperday' : fields.float ('PF-Specialist'),
        'pfspmax' : fields.float ('PF-Specialist Maximum'),
        'pfsp_cat' : fields.one2many ('hospbill.phic_pfsp_cat', 'name', 'PHIC Professional Fee: Specialist Product Categories'),
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The PHIC Case Type must be unique')
    ]

phic_casetypes ()

class phic_packages (osv.osv):
    _name = "hospbill.phic_packages"
    _description = "PHIC Packages"
    _columns = {
        'name' : fields.char ('Package',size=50), 
        'rate' : fields.float ('Rate'),
        'pf_pct' : fields.integer ('Prof. Fee %'),
    }

phic_packages ()

class phic_roomboard_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_roomboard_cat"
    _description = "PHIC Room and Board Product Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_casetypes','PHIC Case Type',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC Room and Board Product Category."),
    }

phic_roomboard_cat ()

class phic_drugsmeds_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_drugsmeds_cat"
    _description = "PHIC Drugs and Medicines Product Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_casetypes','PHIC Case Type',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC Drugs and Medicines Product Category."),
    }

phic_drugsmeds_cat ()

class phic_xraylabsupp_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_xraylabsupp_cat"
    _description = "PHIC X-Ray, Lab, and Supplies Product Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_casetypes','PHIC Case Type',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC X-Ray, Lab, and Supplies Product Category."),
        'sub_categ' : fields.selection((('r','Radiology'),('l','Laboratory'),('s','Supplies'),('o','Others')), 'Sub-Category'),
    }

phic_xraylabsupp_cat ()

class phic_pfgp_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_pfgp_cat"
    _description = "Professional Fee: General Practitioner"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_casetypes','PHIC Case Type',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="Professional Fee: General Practitioner Product Category."),
    }

phic_pfgp_cat ()

class phic_pfsp_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_pfsp_cat"
    _description = "Professional Fee: Specialist"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_casetypes','PHIC Case Type',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="Professional Fee: Specialist Product Category."),
    }

phic_pfsp_cat ()

class phic_operatingroom (osv.osv):
    _name = "hospbill.phic_operatingroom"
    _description = "PHIC Operating Room Coverage"
    _columns = {
        'name' : fields.char ('Operating Room Name',size=30), 
        'operatingroom_cat' : fields.one2many ('hospbill.phic_operatingroom_cat', 'name', 'PHIC Operating Room Product Categories'),
        'operatingroom_amt' : fields.one2many ('hospbill.phic_operatingroom_amt', 'name', 'PHIC Operating Room Amount References'),
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The PHIC Operating Room Name must be unique')
    ]

phic_operatingroom ()

class phic_operatingroom_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_operatingroom_cat"
    _description = "PHIC Operating Room Product Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_operatingroom','PHIC Operating Rooms',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC Operating Room Product Category."),
    }

phic_operatingroom_cat ()

class phic_operatingroom_amt (osv.osv):    
    _name = "hospbill.phic_operatingroom_amt"
    _description = "PHIC Operating Room Amount Reference"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_operatingroom','PHIC Operating Rooms',readonly=True),
        'rvu_min' : fields.integer ('Minimum RVU'),
        'rvu_max' : fields.integer ('Maximum RVU'),
        'pcf' : fields.integer ('PCF'),
        'min_amt' : fields.float ('Minimum Amount'),
        'max_amt' : fields.float ('Maximum Amount'),
    }

phic_operatingroom_amt ()

class phic_surgery (osv.osv):
    _name = "hospbill.phic_surgery"
    _description = "PHIC Surgery Coverage"
    _columns = {
        'name' : fields.char ('Surgeon Classification',size=30), 
        'range1_rvu_min': fields.integer('Range1: Min. RVU'),
        'range1_rvu_max': fields.integer('Range1: Max. RVU'),
        'surgeon_pcf' : fields.integer ('Surgeon PCF'),
        'surgeon_max' : fields.float ('Surgeon Maximum Amount'),
        'anesthe_pct' : fields.integer ('Anesthesiologist %'),
        'anesthe_max' : fields.float ('Anesthesiologist Maximum Amount'),
        'anesthe_ref' : fields.many2one ('hospbill.phic_surgery','Computation Reference', required=True),
        'anesthe_ref_range' : fields.selection((('1','RVU Range 1'),('2','RVU Range 2')), 'Range to use', required=True),
        'range2_rvu_min': fields.integer('Range2: Min. RVU'),
        'range2_rvu_max': fields.integer('Range2: Max. RVU'),
        'surgeon_pcf2' : fields.integer ('Surgeon PCF'),
        'surgeon_max2' : fields.float ('Surgeon Maximum Amount'),
        'anesthe_pct2' : fields.integer ('Anesthesiologist %'),
        'anesthe_max2' : fields.float ('Anesthesiologist Maximum Amount'),
        'anesthe_ref2' : fields.many2one ('hospbill.phic_surgery','Computation Reference', required=True),
        'anesthe_ref_range2' : fields.selection((('1','RVU Range 1'),('2','RVU Range 2')), 'Range to use', required=True),
        'surgery_cats' : fields.one2many ('hospbill.phic_surgery_cat', 'name', 'PHIC Surgery Service Categories'),
        'anesthesiology_cats' : fields.one2many ('hospbill.phic_anesthesiology_cat', 'name', 'PHIC Anesthesiology Service Categories'),
        'physicians' : fields.one2many ('hr.employee', 'name', 'Physicians', domain="[('doctor','=',True)]"),
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The PHIC Surgeon Classification must be unique')
    ]

phic_surgery ()

class phic_surgery_surgeon_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_surgery_cat"
    _description = "PHIC Surgery Service Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_surgery','PHIC Surgery Coverage',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC Surgery Service Category."),
    }

phic_surgery_surgeon_cat () 

class phic_surgery_anesthesiologist_cat (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'categ_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _name = "hospbill.phic_anesthesiology_cat"
    _description = "PHIC Anesthesiology Service Categories"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_surgery','PHIC Surgery Coverage',readonly=True),
        'categ_id' : fields.many2one ('product.category','Product Category', required=True, help="PHIC Anesthesiology Service Category."),
    }

phic_surgery_anesthesiologist_cat () 

class phic_procedures_rvu (osv.osv):
    _name = "product.product"
    _inherit = "product.product"
    _columns = {
        'phic_rvu' : fields.integer('Philhealth RVU'),
        'hmo_rvu' : fields.integer('HMO RVU'),
    }
    
phic_procedures_rvu ()

class phic_pathology (osv.osv):
    _name = "medical.pathology"
    _inherit = "medical.pathology"
    _description = "Diseases Case Types"
    _columns = {
        'casetype_id': fields.many2one('hospbill.phic_casetypes', 'PHIC Case Type', help='The PHIC Case Type.'),
        'package_id': fields.many2one('hospbill.phic_packages', 'PHIC Package', help='The PHIC Package.'),
    }

phic_pathology ()

class phic_partner (osv.osv):
    _name = "hospbill.phic_partner"
    _description = "PHIC Partner"
    _columns = {
        'partner_id' : fields.many2one ('res.partner', 'PHIC Partner', required=True, help='Partner - PHIC mapping'),
    }

phic_partner ()

class phic_covered_prods_pathology (osv.osv):
    _name = "hospbill.phic_pathology_covered_prods"
    _description = "Pathologies PHIC with Covered Products"
    _columns = {
        'pathology_id' : fields.many2one ('medical.pathology','Pathology',required=True), 
        'phic_covered_prods' : fields.one2many ('hospbill.phic_covered_prods', 'name', 'PHIC Covered Products'),
    }

    _sql_constraints = [
        ('name_uniq', 'unique (pathology_id)', 'The Pathology must be unique')
    ]

phic_covered_prods_pathology ()

class phic_covered_prods_list (osv.osv):
    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'product_id'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res

    _name = "hospbill.phic_covered_prods"
    _description = "PHIC Covered Products"
    _columns = {
        'name' : fields.many2one ('hospbill.phic_pathology_covered_prods','Pathology', readonly=True),
        'product_id' : fields.many2one ('product.product','Product', required=True, help="PHIC Covered Products."),
    }

phic_covered_prods_list ()

"""class hmo_partner (osv.osv):
    _name = "hospbill.hmo_partner"
    _description = "HMO Partner"
    _columns = {
        'name' : fields.many2one ('res.partner', 'HMO Partner', required=True, help='Partner - HMO mapping'),

    }

    def name_get(self, cr, uid, ids, context={}):
        if not len(ids):
            return []
        rec_name = 'name'
        res = [(r['id'], r[rec_name][1]) for r in self.read(cr, uid, ids, [rec_name], context)]
        return res
    
    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The HMO Partner must be unique')
    ]

hmo_partner ()"""

class hmo_opd_soa (osv.osv):
    _name = "hospbill.hmo_opd_soa"
    _description = "HMO OPD Statement of Account"
    _columns = {
        'hmo_id' : fields.many2one ('res.partner', 'HMO', domain="[('hmo_partner','=',True)]", help='Name of HMO'),
        'period_id' : fields.many2one ('account.period', 'Period', required=True, help='Select Period'),
        'hmo_opd_soa_invoices' : fields.one2many ('hospbill.hmo_opd_soa_invoices', 'name', 'HMO OPD Statement of Account Invoices'),
    }
    
    _sort = 'period_id desc'

hmo_opd_soa ()

class hmo_opd_soa_invoices (osv.osv):
    _name = "hospbill.hmo_opd_soa_invoices"
    _description = "HMO OPD Statement of Account Invoices"
    _columns = {
        'name' : fields.many2one ('hospbill.hmo_opd_soa', 'SOA', readonly=True),
        'invoice_id' : fields.many2one ('account.invoice', 'Invoice', help='Select the invoice to include in this Statement of Account'),
    }

    _sql_constraints = [
        ('invoice_uniq', 'unique (invoice_id)', 'Select an invoice that is not yet specified in other HMO OPD Statement of Account.')
    ]
    
hmo_opd_soa_invoices ()

#Journal References
class hospbill_journals(osv.osv):
    _name = 'hospbill.journal_ref'
    _description = 'Journal References'
    _columns = {
        'transtype' : fields.selection((('prfee','Professional Fee'),('rmbfee','Room and Board')), 'Transaction Type', required=True),
        'journal': fields.many2one('account.journal', 'Journal', required=True, help="Select the Journal to be used for posting transactions."),
    }

hospbill_journals()

#Default Surgeon and Anesthesiologist PF Services
class hospbill_def_surg_anes_serv(osv.osv):
    _name = 'hospbill.def_surg_anes_serv'
    _description = 'Default Surgen and Anesthesiologist Service'
    _columns = {
        'pf_type' : fields.selection((('surgeon','Surgeon'),('anesthesiologist','Anesthesiologist')), 'Profession Fee Type', required=True),
        'pf_service': fields.many2one('product.product', 'Service', domain="[('type','=','service')]", required=True, help="Select the Service to be used for posting PF charges."),
    }

hospbill_def_surg_anes_serv()
