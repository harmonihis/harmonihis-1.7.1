class inpac_soa_patient_list(osv.osv):
    _name = "hospbill.inpac_soa_patient_list_view"
    _auto = False
    _description = "In-Patient Statement of Account List of Patients"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_id': fields.integer('Patient ID', readonly=True),
        'partner_id': fields.integer('Partner ID', readonly=True),
        'patient_name': fields.char('Patient Name', size=256, readonly=True),
        'name': fields.char('Patient Info', size=256, readonly=True),
        'case_no': fields.char('Case Number', size=128, readonly=True),
        'bed_product_name' : fields.char ('Room/Bed', size=128, readonly=True),
        'hospitalization_date': fields.date('Date Admitted', readonly=True),
        'days': fields.char('Length of Stay', size=64, readonly=True),
    }

    _order = 'id'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_inpac_soa_patient_list_view')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_inpac_soa_patient_list_view AS (
                SELECT
                a.id as id, a.patient as patient_id, c.id as partner_id, c.name as patient_name, 
                ('['||a.name||'] '||c.name||' ('||e.name_template||')') as name,
                a.state, a.name as case_no, a.bed as bed_id, d.name as bed_product_id, e.name_template as bed_product_name,
                a.hospitalization_date, (now() - a.hospitalization_date) as days
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join medical_hospital_bed d on d.id = a.bed
                left join product_product e on e.id = d.name
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                order by id
            )""")

inpac_soa_patient_list()

class inpac_soa_lines_ref(osv.osv):
    _name = "hospbill.inpac_soa_lines_ref_view"
    _auto = False
    _description = "In-Patient Statement of Account Item Reference"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_id': fields.integer('Patient', readonly=True),
        'partner_id': fields.integer('Partner', readonly=True),
        'invoice_no': fields.char('Invoice Number', size=64, readonly=True),
        'date_invoice': fields.date('Invoice Date', readonly=True),
        'product_category': fields.char('Category', size=128, readonly=True),
        'name': fields.char('Product/Service', size=256, readonly=True),
        'price_subtotal': fields.float('Sub-Total', readonly=True),
        'phic_covered': fields.boolean('PHIC Covered'),
        'hmo_covered': fields.boolean('HMO Covered'),
    }

    _order = 'id'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_inpac_soa_lines_ref_view')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_inpac_soa_lines_ref_view AS (
                SELECT
                g.id as id, a.patient as patient_id, c.id as partner_id,
                f.number as invoice_no, f.date_invoice, j.name as product_category, g.name as name, 
                (g.price_unit * g.quantity) - ((g.price_unit * g.quantity)*(g.discount/100)) as price_subtotal, 
                g.phic_covered, g.hmo_covered
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join account_invoice f on f.partner_id = c.id and (f.date_invoice >= a.hospitalization_date::date and f.date_invoice <= now()::date)
                left join account_invoice_line g on g.invoice_id = f.id
                left join product_product h on h.id = g.product_id
                left join product_template i on i.id = h.product_tmpl_id
                left join product_category j on j.id = i.categ_id
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                and g.id is not null
                order by partner_id
            )""")

inpac_soa_lines_ref()
