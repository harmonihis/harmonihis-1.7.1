# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


from osv import fields, osv
from tools.translate import _
import netsvc
import pooler
import datetime

class inpac_get_invoice_line(osv.osv_memory):
    _name = "hospbill.inpac_get_invoice_line"
    _description = "In-Patient Get Invoice Line"
    def process_invoice_lines(self, cr, uid, ids, context=None):
        """
            Process the invoice lines to be included in the bill.

            @param self: The object pointer.
            @param cr: A database cursor
            @param uid: ID of the user currently logged in
            @param ids: the ID or list of IDs
            @param context: A standard dictionary

            @return: A dictionary of fields with values.
        """
        if context is None:
            context = {}
        wf_service = netsvc.LocalService('workflow')

        hospbill_inpac_soa = self.pool.get('hospbill.inpac_soa')

        if 'active_ids' in context:
            record_id = context.get('active_id')            
            inpac_soa_data = hospbill_inpac_soa.browse(cr, uid, context['active_id'])
            if inpac_soa_data:
                soa_id = inpac_soa_data.id
                partner_id = inpac_soa_data.patient_case_id.name.id
                partner_name = inpac_soa_data.patient_case_id.name.whole_name
                case_no = inpac_soa_data.patient_case_id.admission_no
                hospitalization_date = inpac_soa_data.patient_case_id.date_admitted
                discharge_date = inpac_soa_data.patient_case_id.date_discharged or datetime.datetime.now()
                #raise osv.except_osv(_('Warning'), ('Values:\nPartner ID: %s\n'
                #                                    'Partner Name: %s\n'
                #                                    'Hospitalization Date: %s\n'
                #                                    'Discharge Date: %s\n' % 
                #                                    (partner_id, partner_name, hospitalization_date, discharge_date)))
                inpac_soa_lines_obj = self.pool.get('hospbill.inpac_soa_lines')
                invoice_obj = self.pool.get('account.invoice')
                invoice_tax_obj = self.pool.get('account.invoice.tax')
                invoice_line_obj = self.pool.get('account.invoice.line')

                #Gather all invoices
                invoice_ids = {}
                invoice_ids = invoice_obj.search(cr,uid, [
                                    ('partner_id','=',partner_id),
                                    ('date_invoice','>=',hospitalization_date),
                                    ('date_invoice','<=',discharge_date),
                                    ('state','in',['open','draft'])])
                if not invoice_ids:
                    raise osv.except_osv(('Error !'), ('No charges encoded for patient: '+ partner_name + ' with Case No.: '+ str(case_no)))
                else:
                    """invoice_data = {}
                    invoice_data = invoice_obj.browse(cr, uid, invoice_ids, context=context)
                    error_ctr = 0
                    recrd_ctr = 0
                    for invoice in invoice_data:
                        context.update({'company_id': invoice.company_id.id})
                        #Check if the invoice have taxes. It needs to be removed
                        if invoice.tax_line:
                            if invoice.state not in ('cancel','paid'):
                                wf_service.trg_validate(uid, 'account.invoice', invoice.id, 'invoice_cancel', cr)
                                invoice_obj.write(cr, uid, invoice.id, {'state':'draft'})
                                wf_service.trg_delete(uid, 'account.invoice', invoice.id, cr)
                                wf_service.trg_create(uid, 'account.invoice', invoice.id, cr)
                                invoice_obj.write(cr, uid, invoice.id, {'fiscal_position':2})
                            
                            #invline_ids = invoice_line_obj.search(cr, uid [('invoice_id','=',invoice.id)])
                            invline_ids = invoice.invoice_line
                            for invline in invline_ids:
                                #invoice_line_obj.write(cr, uid, [invline.id], {'invoice_line_tax_id': [(5)]})
                                #upd_invline = self.product_id_change(cr, uid, invline.id, invline.product_id, invline.uos_id, invline.quantity, '', 'out_invoice', partner_id, 2, False, False, False, context)
                                inv_data = {'name': invline.name,
                                    'origin': invline.origin,
                                    'invoice_id': invline.invoice_id.id,
                                    'uos_id': invline.uos_id.id,
                                    'product_id': invline.product_id.id,
                                    'account_id': invline.account_id.id,
                                    'price_unit': invline.price_unit,
                                    'quantity': invline.quantity,
                                    'discount': invline.discount,
                                    'invoice_line_tax_id': [],
                                    'note': invline.note,
                                    'account_analytic_id': invline.account_analytic_id.id,
                                    'hmo_covered': invline.hmo_covered,
                                    'phic_covered': invline.phic_covered,
                                }
                                #raise osv.except_osv(('Debug!'), ('Value: %s') % inv_data)
                                invoice_line_obj.unlink(cr, uid, invline.id)
                                invoice_line_obj.create(cr, uid, inv_data)
                                #invoice_line_obj.write(cr, uid, invline.id, upd_invline['value'])
                                #invoice_line_obj.write(cr, uid, invline.id, {'invoice_line_tax_id': [(5)]})
                            #Remove the Taxes
                            invtax_ids = invoice_tax_obj.search(cr, uid, [('invoice_id','=',invoice.id)])
                            if invtax_ids:
                                invoice_tax_obj.unlink(cr, uid, invtax_ids)
                            
                            #wf_service.trg_validate(uid, 'account.invoice', invoice.id, 'invoice_open', cr)
                            cr.commit()
                            modifiedInv = True
                        else:
                            modifiedInv = False"""

                    invoice_data = {}
                    invoice_data = invoice_obj.browse(cr, uid, invoice_ids, context=context)
                    error_ctr = 0
                    recrd_ctr = 0
                    for invoice in invoice_data:
                        invoice_line_ids = invoice.invoice_line
                        if invoice_line_ids:
                            for lines in invoice_line_ids:
                                if lines.discount > 0:
                                    apply_disc = True
                                    discval = (lines.price_unit * lines.quantity) * (lines.discount/100)
                                else:
                                    apply_disc = False
                                    discval = 0
                                product_id = lines.product_id.id
                                if not lines.product_id.product_tmpl_id.categ_id.id:
                                    raise osv.except_osv(('Error !'), ('An invoice have a missing product.'))
                                    break
                                product_cat_id = lines.product_id.product_tmpl_id.categ_id.id
                                #raise osv.except_osv(('Error !'), ('Product ID: '+str(product_id)+' Category ID: '+str(product_cat_id)))
                                bill_cat, bill_sub_cat = self.pool.get('hospbill.inpac_soa').get_bill_cat(cr, uid, product_id, product_cat_id)
                                if not bill_cat:
                                    raise osv.except_osv(('Error !'), ('Either product or category ID are missing in the parameters.'))
                                    break
                                recrd_ctr += 1
                                vals = {}
                                vals = {'name': soa_id, 
                                        'invoice_line_id': lines.id, 
                                        'category': bill_cat, 
                                        'sub_category': bill_sub_cat, 
                                        'apply_disc': apply_disc,
                                        'discval': discval}
                                try:
                                    soa_line_id = inpac_soa_lines_obj.create(cr, uid, vals, context=None)
                                    cr.commit()
                                except: #Exception, e:
                                    cr.rollback()
                                    error_ctr += 1
                    if (error_ctr == recrd_ctr) and (recrd_ctr > 0):
                        raise osv.except_osv(('Error !'), ('No new invoice line/s added to the bill.' ))
            else:
                raise osv.except_osv(('Error !'), ('No Patient case selected'))
        else:
            raise osv.except_osv(('Error !'), ('No SOA Selected'))

        return {'type': 'ir.actions.act_window_close'}

inpac_get_invoice_line()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

