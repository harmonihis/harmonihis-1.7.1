﻿CREATE OR REPLACE VIEW hospbill_hmo_opd_soa_report_summary AS 
SELECT a.id, a.hmo_id, b.name AS hmo_partner_id, c.name AS hmo_partner, a.period_id, a.soa_period_id, 
f.name AS period, d.invoice_id, g.number AS hmo_idnumber, a.number AS invoice_number, a.partner_id, 
a.date_invoice, e.name AS patient_name, d.price_unit * d.quantity::numeric AS amount, 
d.name AS invoice_line, d.product_id as product_id, i.categ_id, 
case when i.categ_id = 11 then d.price_unit * d.quantity else 0 end as pf,
case when (i.categ_id = 45 or i.categ_id = 46 or i.categ_id = 172 or i.categ_id = 174) then d.price_unit * d.quantity else 0 end as lab,
case when i.categ_id not in (172,45,174,46,195,196,70,199,200,195,196,99,6,7,5,19,21,64,68,166,197,198,187,9,11,12,15,16,17,18,176,101) then d.price_unit * d.quantity else 0 end as meds, 
case when i.categ_id in (195,196,70,199,200,195,196,99,6,7,5,19,21,64,68,166,197,198,187,9,12,15,16,17,18,176,101) then d.price_unit * d.quantity else 0 end as others
FROM account_invoice a
LEFT JOIN hospbill_hmo_partner b ON a.hmo_id = b.id
LEFT JOIN res_partner c ON b.name = c.id
LEFT JOIN account_invoice_line d ON a.id = d.invoice_id
LEFT JOIN res_partner e ON a.partner_id = e.id
LEFT JOIN account_period f ON a.soa_period_id = f.id
LEFT JOIN medical_insurance g ON a.partner_id = g.name AND g.company = b.name
LEFT JOIN product_product h ON d.product_id = h.id
LEFT JOIN product_template i ON i.id = h.product_tmpl_id
WHERE a.hmo_id > 0;