select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed,
soa_line.category as cat, soa_line.sub_category as sub_cat,
concat( trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, '\[[^)]+\]', '', 'g')),
    case when soa_line.dv_physician_id != null then concat('[',dv_phy.name,']')
         when soa_line.surgeon_id != null then concat('[',surgeon.name,']')
         when soa_line.anesthesiologist_id != null then concat('[',anesthesiologist.name,']')
    else '' end
) as particulars,
case when soa_line_inv.quantity >= 0 then soa_line_inv.quantity else 0 end as quantity_used,
case when soa_line_inv.quantity < 0 then soa_line_inv.quantity else 0 end as quantity_returned,
soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount,
disc_ref.name as discount_name,
soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg,
soa_line_inv.price_subtotal - (
    case when soa_line.phic_amt is null then 0.0 else soa_line.phic_amt end + 
    case when soa_line.hmo_amt is null then 0.0 else soa_line.hmo_amt end) as patient_chg,
soa_line_inv.price_subtotal as subtotal,
phic.number as phic_number, phic_member.name as phic_member,
hmo.number as hmo_number, hmo_member.name as hmo_member, hmo_coy.name as hmo_coy
from hospbill_inpac_soa soa
left join medical_inpatient_registration inpac_reg on soa.patient_case_id = inpac_reg.id
    left join medical_hospital_bed bed_ref on inpac_reg.bed = bed_ref.id
        left join product_product as bed on bed.id = bed_ref.name
left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id
left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id
    left join medical_physician phy_dv on soa_line.dv_physician_id = phy_dv.id
        left join res_partner dv_phy on phy_dv.name = dv_phy.id
    left join medical_physician phy_sur on soa_line.surgeon_id = phy_sur.id
        left join res_partner surgeon on phy_sur.name = surgeon.id
    left join medical_physician phy_anes on soa_line.anesthesiologist_id = phy_anes.id
        left join res_partner anesthesiologist on phy_anes.name = anesthesiologist.id
left join hospbill_discounts disc_ref on soa.disc_id = disc_ref.id
left join medical_insurance phic on soa.phic_member_id = phic.id
    left join res_partner phic_member on phic.name = phic_member.id
left join medical_insurance hmo on soa.hmo_member_id = hmo.id
    left join res_partner hmo_member on hmo.name = hmo_member.id
    left join res_partner hmo_coy on hmo.company = hmo_coy.id
where soa.id = 3
