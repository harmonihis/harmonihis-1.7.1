﻿select d.name_template as product_name, count(a.id) as total_orders, 
sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, 
sum((c.price_unit * c.quantity) - c.discount) as total 
from hospbill_hmo_opd_soa_invoices a 
left join account_invoice b on b.id = a.invoice_id
left join account_invoice_line c on c.invoice_id = b.id 
left join product_product d on d.id = c.product_id 
left join product_template e on e.id = d.product_tmpl_id 
left join hospbill_hmo_opd_soa f on f.id = a.name
where e.categ_id = 11 
and f.period_id = 5
group by product_name order by product_name