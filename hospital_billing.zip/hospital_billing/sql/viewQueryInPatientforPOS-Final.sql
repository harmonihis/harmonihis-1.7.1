﻿SELECT
(case when g.id is null then a.patient else a.patient + g.id end) as id, 
a.patient as patient_id, c.id as partner_id, c.name as patient_name, 
('['||a.name||'] '||c.name||' ('||e.name_template||')') as patient_info,
a.state, a.name as case_no, 
a.admission_reason as pathology_id, c1.name as pathology, 
a.bed as bed_id, d.name as bed_product_id, e.name_template as bed_product_name,
a.hospitalization_date, (now() - a.hospitalization_date) as days,
f.name as pos_no, f.date_order, j.name as product_category,
i.name as product, g.qty as qty, g.price_unit as sell_price, g.price_ded as discount, 
(g.price_unit * g.qty) as sub_total, (g.price_unit * g.qty) - g.price_ded as total, 
(case when g.product_id in (
  select phic1.product_id from hospbill_phic_covered_prods phic1
  left join hospbill_phic_pathology_covered_prods phic2 on phic2.id = phic1.name
  where phic2.pathology_id = a.admission_reason)
then (g.price_unit * g.qty) else 0 end) as phic_charge, 
(case when g.product_id not in (
  select phic1.product_id from hospbill_phic_covered_prods phic1
  left join hospbill_phic_pathology_covered_prods phic2 on phic2.id = phic1.name
  where phic2.pathology_id = a.admission_reason)
then ((g.price_unit * g.qty) - g.price_ded) else 0 end) as non_phic_charge
from medical_inpatient_registration a
left join medical_patient b on b.id = a.patient
left join res_partner c on c.id = b.name
left join medical_pathology c1 on c1.id = a.admission_reason
left join medical_hospital_bed d on d.id = a.bed
left join product_product e on e.id = d.name
left join pos_order f on f.partner_id = c.id and (f.date_order >= a.hospitalization_date::date and f.date_order <= now()::date)
left join pos_order_line g on g.order_id = f.id
left join product_product h on h.id = g.product_id
left join product_template i on i.id = h.product_tmpl_id
left join product_category j on j.id = i.categ_id
where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
and i.categ_id in (select drugmeds_cat.categ_id from hospbill_phic_drugsmeds_cat drugmeds_cat)
order by partner_id