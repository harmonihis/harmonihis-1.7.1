﻿SELECT a.id id, b.internal_number invoice_number, b.partner_id partner_id, b.date_invoice date_invoice, 
d.name product_service, e.name product_service_cat, a.quantity qty, a.price_unit unit_price, a.discount disc_pct,
(a.price_subtotal * (a.discount/100)) disc_amt,a.price_subtotal subtotal
FROM account_invoice_line a
LEFT JOIN account_invoice b ON b.id = a.invoice_id
LEFT JOIN product_product c ON c.id = a.product_id
LEFT JOIN product_template d ON d.id = c.product_tmpl_id
LEFT JOIN product_category e ON e.id = d.categ_id
WHERE d.categ_id in (select categ_id from hospbill_phic_roomboard_cat)