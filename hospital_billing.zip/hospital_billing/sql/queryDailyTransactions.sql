﻿select a.id, a.default_code, b.name as product_name,

(select sum(a1.qty)
from pos_order_line a1 
left join pos_order b1 on b1.id = a1.order_id 
where a1.product_id = a.id 
and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft'
and (b1.date_order  >= '2011-08-01 00:00:00' and b1.date_order <= '2011-08-01 23:59:59') 
) as cash_total_orders,
(select sum(a1.price_unit * a1.qty)
from pos_order_line a1 
left join pos_order b1 on b1.id = a1.order_id 
where a1.product_id = a.id 
and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft'
and (b1.date_order  >= '2011-08-01 00:00:00' and b1.date_order <= '2011-08-01 23:59:59') 
) as cash_sub_total,
(select sum((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end))
from pos_order_line a1 
left join pos_order b1 on b1.id = a1.order_id 
where a1.product_id = a.id 
and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft'
and (b1.date_order  >= '2011-08-01 00:00:00' and b1.date_order <= '2011-08-01 23:59:59') 
) as cash_total_discount,
(select sum((a1.price_unit * a1.qty) - (((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end))))
from pos_order_line a1 
left join pos_order b1 on b1.id = a1.order_id 
where a1.product_id = a.id 
and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft'
and (b1.date_order  >= '2011-08-01 00:00:00' and b1.date_order <= '2011-08-01 23:59:59') 
) as cash_total_amt,

(select sum(b2.quantity) 
from account_invoice a2
left join account_invoice_line b2 on b2.invoice_id = a2.id 
where b2.product_id = a.id 
and a2.hmo_id > 0 
and (a2.date_invoice  >= '2011-08-01' and a2.date_invoice <= '2011-08-01')
) as hmo_total_orders,
(select sum(b2.price_unit * b2.quantity)
from account_invoice a2
left join account_invoice_line b2 on b2.invoice_id = a2.id 
where b2.product_id = a.id 
and a2.hmo_id > 0 
and (a2.date_invoice  >= '2011-08-01' and a2.date_invoice <= '2011-08-01')
) as hmo_sub_total,
(select sum(b2.discount)
from account_invoice a2
left join account_invoice_line b2 on b2.invoice_id = a2.id 
where b2.product_id = a.id 
and a2.hmo_id > 0 
and (a2.date_invoice  >= '2011-08-01' and a2.date_invoice <= '2011-08-01')
) as hmo_total_discount,
(select sum((b2.price_unit * b2.quantity) - b2.discount)
from account_invoice a2
left join account_invoice_line b2 on b2.invoice_id = a2.id 
where b2.product_id = a.id 
and a2.hmo_id > 0 
and (a2.date_invoice  >= '2011-08-01' and a2.date_invoice <= '2011-08-01')
) as hmo_total_amt

from product_product a 
left join product_template b on b.id = a.product_tmpl_id 
where b.categ_id = 11 
/*and (
(select sum((b2.price_unit * b2.quantity) - b2.discount)
  from account_invoice a2
  left join account_invoice_line b2 on b2.invoice_id = a2.id 
  where b2.product_id = a.id 
  and a2.hmo_id > 0 
  and (a2.date_invoice  >= '2011-08-01' and a2.date_invoice <= '2011-08-01')
) > 0 or
(select sum((a1.price_unit * a1.qty) - (((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end))))
from pos_order_line a1 
left join pos_order b1 on b1.id = a1.order_id 
where a1.product_id = a.id 
and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft'
and (b1.date_order  >= '2011-08-01 00:00:00' and b1.date_order <= '2011-08-01 23:59:59') 
) > 0)*/
order by product_name

