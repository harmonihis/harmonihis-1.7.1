﻿select a.id as id, a.ref as reference, a.name as name, a.lastname as middlename, c.number as pin, 
c.company as insurance_id, d.name as insurance_coy, b.dob as birthdate, (now() - b.dob) as age, 
b.sex, b.dod as deathdate
from res_partner a
left join medical_patient b on b.name = a.id
left join medical_insurance c on c.name = a.id
left join res_partner d on d.id = c.company
where c.company > 0
order by id