﻿SELECT a.id, a.hmo_id, b.name AS hmo_partner_id, c.name AS hmo_partner, 
a.period_id, f.name AS period, d.invoice_id, j.number AS hmo_idnumber, 
a.number AS invoice_number, a.partner_id, a.date_invoice, e.name AS patient_name, 
d.price_unit * d.quantity::numeric AS amount, d.name AS invoice_line, 
g.primary_care_doctor AS physician_id, i.name AS physician_name
FROM account_invoice a
left join hospbill_hmo_partner b ON a.hmo_id = b.id
left join res_partner c on b.name = c.id
left join account_invoice_line d on a.id = d.invoice_id
left join res_partner e on a.partner_id = e.id
left join account_period f on a.soa_period_id = f.id
left join medical_patient g ON a.partner_id = g.name
left join medical_physician h ON g.primary_care_doctor = h.id
left join res_partner i ON h.name = i.id
left join medical_insurance j ON a.partner_id = j.name AND j.company = b.name
where hmo_id > 0
