﻿SELECT
a.patient as id, c.id as partner_id, c.name as patient_name, 
('['||a.name||'] '||c.name||' ('||e.name_template||')') as patient_info,
a.state, a.name as case_no, 
a.admission_reason as pathology_id, f.name as pathology, f.casetype_id,
a.bed as bed_id, d.name as bed_product_id, 
e.name_template as bed_product_name,
a.hospitalization_date, (now() - a.hospitalization_date) as days,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_b.partner_id = c.id
) as total,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	left join product_product rb_c on rb_c.id = rb_a.product_id
	left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
	left join product_category rb_e on rb_e.id = rb_d.categ_id
	left join hospbill_phic_roomboard_cat rb_f on rb_f.categ_id = rb_e.id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
) as room_board,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	left join product_product rb_c on rb_c.id = rb_a.product_id
	left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
	left join product_category rb_e on rb_e.id = rb_d.categ_id
	left join hospbill_phic_drugsmeds_cat rb_f on rb_f.categ_id = rb_e.id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
) as drug_meds,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	left join product_product rb_c on rb_c.id = rb_a.product_id
	left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
	left join product_category rb_e on rb_e.id = rb_d.categ_id
	left join hospbill_phic_xraylabsupp_cat rb_f on rb_f.categ_id = rb_e.id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
) as xray_lab_supp,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	left join product_product rb_c on rb_c.id = rb_a.product_id
	left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
	left join product_category rb_e on rb_e.id = rb_d.categ_id
	left join hospbill_phic_pfgp_cat rb_f on rb_f.categ_id = rb_e.id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
) as pf_general,
(select 
	sum(rb_a.price_subtotal) 
	from account_invoice_line rb_a
	left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
	left join product_product rb_c on rb_c.id = rb_a.product_id
	left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
	left join product_category rb_e on rb_e.id = rb_d.categ_id
	left join hospbill_phic_pfsp_cat rb_f on rb_f.categ_id = rb_e.id
	where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
	and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
) as pf_spec
from medical_inpatient_registration a
left join medical_patient b on b.id = a.patient
left join res_partner c on c.id = b.name
left join medical_hospital_bed d on d.id = a.bed
left join product_product e on e.id = d.name
left join medical_pathology f on f.id = a.admission_reason
where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
order by partner_id