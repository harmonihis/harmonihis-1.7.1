# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class inpatient_charges_summary_report(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(inpatient_charges_summary_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'time': time,
            'consultation_summary': self.__consultation_summary_report__,
            'total_consultation': self.__consultation_summary_total__,
            'xray_summary': self.__xray_summary_report__,
            'total_xray': self.__xray_summary_total__,
            'lab_summary': self.__lab_summary_report__,
            'total_lab': self.__lab_summary_total__,
            'others_summary': self.__others_summary_report__,
            'total_others': self.__others_summary_total__,
            'grand_total': self.__grand_summary_total__,
            'getperiod': self._get_period,
            'getperiod2':self._get_period2,
        })

    def __consultation_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select e.name as product_name, count(b.id) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id  " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where (b.hmo_id is null or b.hmo_id <= 0) " \
                        "and e.categ_id = 11 " \
                        "and ((b.date_invoice  >= %s and b.date_invoice <= %s) or (b.create_date  >= %s and b.create_date <= %s)) " \
                        "group by product_name order by product_name" \
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __consultation_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and e.categ_id = 11 " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __xray_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select e.name as product_name, sum(c.quantity) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 46 or e.categ_id = 174) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                        "group by product_name order by product_name" \
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __xray_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 46 or e.categ_id = 174) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        return res
    
    def __lab_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select e.name as product_name, sum(c.quantity) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 45 or e.categ_id = 172) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                        "group by product_name order by product_name" \
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __lab_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 45 or e.categ_id = 172) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __others_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select e.name as product_name, sum(c.quantity) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id <> 11 and e.categ_id <> 45 and e.categ_id <> 46 and e.categ_id <> 172 and e.categ_id <> 174) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                        "group by product_name order by product_name" \
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __others_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id <> 11 and e.categ_id <> 45 and e.categ_id <> 46 and e.categ_id <> 172 and e.categ_id <> 174) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __grand_summary_total__(self,form):    
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "where b.hmo_id > 0 " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def _get_period(self, form):
        return form['date_start']

    def _get_period2(self,form):
        return form['date_end']
        
report_sxw.report_sxw('report.hospbill.inpatient_charges_summary_report', 'account.invoice', 'addons/hospital_billing/report/inpatient_charges_summary_report.rml', parser=inpatient_charges_summary_report, header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
