# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class hmo_opd_soa_report_gen(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(hmo_opd_soa_report_gen, self).__init__(cr, uid, name, context=context)
        self.total = 0.0
        self.localcontext.update({
            'time': time,
            'hmo_opd_soa': self.__hmo_opd_soa_report__,
            'soa_total': self.__hmo_opd_soa__total__,
            'soa_hmo_name': self.__hmo_opd_soa_hmo_name__,
            'soa_hmo_period': self.__hmo_opd_soa_period__,
        })

    def __hmo_opd_soa_report__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        data = {}
        self.cr.execute ("select a.hmo_partner as hmo_name, a.period as period, a.hmo_idnumber as hmo_id, " \
                        "a.date_invoice as date_inv, a.patient_name as patient_name, " \
                        "a.amount as amount, a.invoice_line as details, a.physician_name as physician  " \
                        "from hospbill_hmo_opd_soa_report as a " \
                        "where a.hmo_id = %s and a.period_id = %s" \
                        "order by a.date_invoice, a.patient_name" \
                    ,(hmo,period))
        data = self.cr.dictfetchall()
        return data
    
    def __hmo_opd_soa_hmo_name__(self,form):
        hmo = form['hmo_id']
        res1=[]
        self.cr.execute ("select a.name as hmoname from res_partner a, hospbill_hmo_partner b "\
                        "where (a.id = b.name) and b.id = " + str(hmo))
     
        res1=self.cr.fetchone()[0] or 'NONE'
        return res1

    def __hmo_opd_soa_period__(self,form):
        period = form['rep_period']
        res2=[]
        self.cr.execute ("select name as period from account_period "\
                        "where id = " + str(period))
                        
        res2=self.cr.fetchone()[0] or 'NONE'
        return res2
    
    def __hmo_opd_soa__total__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        res=[]
        self.cr.execute ("select sum(a.amount) as grand_total  " \
                        "from hospbill_hmo_opd_soa_report as a " \
                        "where a.period_id = %s and a.hmo_id = %s" \
                    ,(period,hmo))
                    
        res=self.cr.fetchone()[0] or 0.0
        return res
            
report_sxw.report_sxw('report.hospbill.hmo_opd_soa_report_gen', 'hospbill.hmo_opd_soa_report', 'addons/hospital_billing/report/hmo_opd_soa_report_gen.rml', parser=hmo_opd_soa_report_gen,header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: