# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields, osv
import tools

class hmo_opd_soa_report (osv.osv):
    _name = "hospbill.hmo_opd_soa_report"
    _description = "HMO OPD Statement of Account"
    _auto = False
    _rec_name = 'hmo_id'
    _columns = {
        'hmo_id': fields.many2one('hospbill.hmo_partner', 'HMO ID', readonly=True),
        'hmo_partner': fields.char('HMO', size=128, readonly=True),
        'period_id': fields.many2one('account.period', 'Period ID', readonly=True),
        'period': fields.char('Period', size=20, readonly=True),
        'invoice_number': fields.char('Invoice Number', size=30, readonly=True),
        'date_invoice': fields.date('Date', readonly=True),
        'patient_name': fields.char('Name', size=128, readonly=True),
        'hmo_idnumber': fields.char('ID Number', size=64, readonly=True),
        'invoice_line': fields.char('Details', size=128, readonly=True),
        'amount': fields.float('Amount', readonly=True),
        'physician_name': fields.char('Physician', size=128, readonly=True),
    }
    _order = 'date_invoice, patient_name'
    
    def init(self, cr):
        tools.drop_view_if_exists(cr, 'hospbill_hmo_opd_soa_report')
        cr.execute("""
            create or replace view hospbill_hmo_opd_soa_report as (
                select a.id as id, a.hmo_id as hmo_id, b.name as hmo_partner_id, c.name as hmo_partner,
                a.period_id as period_id, d.name as period,
                e.invoice_id as invoice_id, l.number as hmo_idnumber,
                f.number as invoice_number, f.partner_id as partner_id, f.date_invoice as date_invoice,
                g.name as patient_name, (h.price_unit * cast(h.quantity as numeric)) as amount, h.name as invoice_line,
                i.primary_care_doctor as physician_id, k.name as physician_name
                from hospbill_hmo_opd_soa a
                left join hospbill_hmo_partner b on a.hmo_id = b.id
                left join res_partner c on b.name = c.id
                left join account_period d on a.period_id = d.id
                left join hospbill_hmo_opd_soa_invoices e on a.id = e.name
                left join account_invoice f on e.invoice_id = f.id
                left join res_partner g on f.partner_id = g.id
                left join account_invoice_line h on f.id = h.invoice_id
                left join medical_patient i on f.partner_id = i.name
                left join medical_physician j on i.primary_care_doctor = j.id
                left join res_partner k on j.name = k.id
                left join medical_insurance l on f.partner_id = l.name and l.company = b.name
            )
        """)
hmo_opd_soa_report()

