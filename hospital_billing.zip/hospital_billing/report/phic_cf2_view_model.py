# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields, osv
import tools

class phic_cf2_view_model (osv.osv):
    _name = "hospbill.phic_cf2"
    _description = "PHIC CF2 View Model"
    _auto = False
    #_rec_name = 'reference'
    _columns = {
        'reference': fields.char('Reference', size=128, readonly=True),
        'name': fields.char('Patient Name', size=256, readonly=True),
        'middlename': fields.char('Middle Name', size=128, readonly=True),
        'pin': fields.integer('PIN', readonly=True),
        'insurance_id': fields.integer('Insurance ID', readonly=True),
        'insurance_coy': fields.char('Insurance', size=256, readonly=True),
        'birthdate': fields.date('Date of Birth', readonly=True),
        'age': fields.char('Age', size=256, readonly=True),
        'deathdate': fields.date('Date of Death', readonly=True),
    }
    _order = 'reference'
    
    def init(self, cr):
        tools.drop_view_if_exists(cr, 'hospbill_phic_cf2_view')
        cr.execute("""
            create or replace view hospbill_phic_cf2_view as (
                select a.id as id, a.ref as reference, a.name as name, a.lastname as middlename, c.number as pin, 
                c.company as insurance_id, d.name as insurance_coy, b.dob as birthdate, (now() - b.dob) as age, 
                b.sex, b.dod as deathdate
                from res_partner a
                left join medical_patient b on b.name = a.id
                left join medical_insurance c on c.name = a.id
                left join res_partner d on d.id = c.company
                where c.company > 0
                order by id
            )""")

phic_cf2_view_model()
