# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields, osv
import tools

class hmo_opd_soa_report_summary_model (osv.osv):
    _name = "hospbill.hmo_opd_soa_report_summary"
    _description = "HMO OPD Statement of Account Summary"
    _auto = False
    _rec_name = 'hmo_id'
    _columns = {
        'hmo_id': fields.many2one('hospbill.hmo_partner', 'HMO ID', readonly=True),
        'hmo_partner': fields.char('HMO', size=128, readonly=True),
        'period_id': fields.many2one('account.period', 'Period ID', readonly=True),
        'soa_period_id': fields.many2one('account.period', 'SOA Period ID', readonly=True),
        'period': fields.char('Period', size=20, readonly=True),
        'invoice_number': fields.char('Invoice Number', size=30, readonly=True),
        'date_invoice': fields.date('Date', readonly=True),
        'patient_name': fields.char('Name', size=128, readonly=True),
        'hmo_idnumber': fields.char('ID Number', size=64, readonly=True),
        'invoice_line': fields.char('Details', size=128, readonly=True),
        'product_id': fields.many2one('product.product', 'Product ID', readonly=True),
        'categ_id': fields.many2one('product.category', 'Product Category ID', readonly=True),
        'amount': fields.float('Amount', readonly=True),
        'pf': fields.float('Professional Fee', readonly=True),
        'lab': fields.float('Laboratory/ X-Ray', readonly=True),
        'meds': fields.float('Medicines', readonly=True),
        'others': fields.float('Others', readonly=True),
    }
    _order = 'date_invoice, patient_name'
    
    def init(self, cr):
        tools.drop_view_if_exists(cr, 'hospbill_hmo_opd_soa_report_summary')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_hmo_opd_soa_report_summary AS (
                SELECT a.id, a.hmo_id, b.name AS hmo_partner_id, c.name AS hmo_partner, a.period_id, a.soa_period_id, 
                f.name AS period, d.invoice_id, g.number AS hmo_idnumber, a.number AS invoice_number, a.partner_id, 
                a.date_invoice, e.name AS patient_name, d.price_unit * d.quantity::numeric AS amount, 
                d.name AS invoice_line, d.product_id, i.categ_id, 
                CASE
                    WHEN i.categ_id = 11 THEN d.price_unit::double precision * d.quantity
                    ELSE 0::double precision
                END AS pf, 
                CASE
                    WHEN i.categ_id = 45 OR i.categ_id = 46 OR i.categ_id = 172 OR i.categ_id = 174 THEN d.price_unit::double precision * d.quantity
                    ELSE 0::double precision
                END AS lab, 
                CASE
                    WHEN i.categ_id <> ALL (ARRAY[172, 45, 174, 46, 195, 196, 70, 199, 200, 195, 196, 99, 6, 7, 5, 19, 21, 64, 68, 166, 197, 198, 187, 9, 11, 12, 15, 16, 17, 18, 176, 101]) THEN d.price_unit::double precision * d.quantity
                    ELSE 0::double precision
                END AS meds, 
                CASE
                    WHEN i.categ_id = ANY (ARRAY[195, 196, 70, 199, 200, 195, 196, 99, 6, 7, 5, 19, 21, 64, 68, 166, 197, 198, 187, 9, 12, 15, 16, 17, 18, 176, 101]) THEN d.price_unit::double precision * d.quantity
                    ELSE 0::double precision
                END AS others
                FROM account_invoice a
                LEFT JOIN hospbill_hmo_partner b ON a.hmo_id = b.id
                LEFT JOIN res_partner c ON b.name = c.id
                LEFT JOIN account_invoice_line d ON a.id = d.invoice_id
                LEFT JOIN res_partner e ON a.partner_id = e.id
                LEFT JOIN account_period f ON a.soa_period_id = f.id
                LEFT JOIN medical_insurance g ON a.partner_id = g.name AND g.company = b.name
                LEFT JOIN product_product h ON d.product_id = h.id
                LEFT JOIN product_template i ON i.id = h.product_tmpl_id
                WHERE a.hmo_id > 0 and a.state <> 'draft'
            )
        """)
hmo_opd_soa_report_summary_model()

