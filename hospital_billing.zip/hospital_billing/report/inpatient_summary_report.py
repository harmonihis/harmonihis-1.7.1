# -*- coding: utf-8 -*-
#		 Hospital Billing Copyright (c) 2011 by Edwin N. Gonzales

#    Copyright (C) 2011 by Edwin N. Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields,osv
import tools

class current_inpatient_summary_report(osv.osv):
    """ Hospital Billing Current In-Patient Summary Report """
    _name = "hospbill.current_inpatient_summary.report"
    _auto = False
    _description = "Current In-Patient Summary Report"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_name': fields.char('Patient', size=128, readonly=True),
        'patient_info': fields.char('Patient Info', size=256, readonly=True),
        'case_no': fields.char('Case Number', size=128, readonly=True),
        'bed_product_name' : fields.char ('Room/Bed', size=128, readonly=True),
        'hospitalization_date': fields.date('Date Admitted', readonly=True),
        'days': fields.char('Length of Stay', size=64, readonly=True),
        'total': fields.float('Total', readonly=True),
        'room_board': fields.float('Room and Board', readonly=True),
        'drug_meds': fields.float('Drugs and Medicines', readonly=True),
        'xray_lab_supp': fields.float('X-Ray/Lab/Supplies', readonly=True),
        'operating_room': fields.float('Operating Room', readonly=True),
        'pf_general': fields.float('Doctors Fee (Gen. Practitioner)', readonly=True),
        'pf_spec': fields.float('Doctors Fee (Specialist)', readonly=True),
    }

    _order = 'patient_name'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_current_inpatient_summary_report')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_current_inpatient_summary_report AS (
                SELECT
                a.patient as id, c.id as partner_id, 
                (c.name||' '||case when c.lastname is null then '' else c.lastname end) as patient_name, 
                ('['||a.name||'] '||c.name||case when c.lastname is null then '' else c.lastname end||' ('||e.name_template||')') as patient_info,
                a.state, a.name as case_no, 
                a.admission_reason as pathology_id, f.name as pathology, f.casetype_id,
                a.bed as bed_id, d.name as bed_product_id, 
                e.name_template as bed_product_name,
                a.hospitalization_date, (now() - a.hospitalization_date) as days,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_b.partner_id = c.id
                ) as total,
                (select 
                sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_roomboard_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
                ) as room_board,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_drugsmeds_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
                ) as drug_meds,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_xraylabsupp_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
                ) as xray_lab_supp,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_operatingroom_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.categ_id > 0 and rb_b.partner_id = c.id
                ) as operating_room,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_pfgp_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
                ) as pf_general,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    left join hospbill_phic_pfsp_cat rb_f on rb_f.categ_id = rb_e.id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_f.name = f.casetype_id and rb_b.partner_id = c.id
                ) as pf_spec
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join medical_hospital_bed d on d.id = a.bed
                left join product_product e on e.id = d.name
                left join medical_pathology f on f.id = a.admission_reason
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                order by partner_id
            )""")

current_inpatient_summary_report()

class current_inpatient_summary_report2(osv.osv):
    """ Hospital Billing Current In-Patient Summary Report (Non-PHIC) """
    _name = "hospbill.current_inpatient_summary.report_nonphic"
    _auto = False
    _description = "Current In-Patient Summary Report (Non-PHIC)"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_name': fields.char('Patient', size=128, readonly=True),
        'patient_info': fields.char('Patient Info', size=256, readonly=True),
        'case_no': fields.char('Case Number', size=128, readonly=True),
        'bed_product_name' : fields.char ('Room/Bed', size=128, readonly=True),
        'hospitalization_date': fields.date('Date Admitted', readonly=True),
        'days': fields.char('Length of Stay', size=64, readonly=True),
        'total': fields.float('Total', readonly=True),
        'room_board': fields.float('Room and Board', readonly=True),
        'drug_meds': fields.float('Drugs and Medicines', readonly=True),
        'xray_lab_supp': fields.float('X-Ray/Lab/Supplies', readonly=True),
        'operating_room': fields.float('Operating Room', readonly=True),
        'pf_general': fields.float('Doctors Fee (Gen. Practitioner)', readonly=True),
        'pf_spec': fields.float('Doctors Fee (Specialist)', readonly=True),
    }

    _order = 'patient_name'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_current_inpatient_summary_report_nonphic')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_current_inpatient_summary_report_nonphic AS (
                SELECT
                a.patient as id, c.id as partner_id, 
                (c.name||' '||case when c.lastname is null then '' else c.lastname end) as patient_name, 
                ('['||a.name||'] '||c.name||case when c.lastname is null then '' else c.lastname end||' ('||e.name_template||')') as patient_info,
                a.state, a.name as case_no, 
                a.admission_reason as pathology_id, f.name as pathology, f.casetype_id,
                a.bed as bed_id, d.name as bed_product_id, 
                e.name_template as bed_product_name,
                a.hospitalization_date, (now() - a.hospitalization_date) as days,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_b.partner_id = c.id
                ) as total,
                (select 
                sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_roomboard_cat)
                    and rb_b.partner_id = c.id
                ) as room_board,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_drugsmeds_cat)
                    and rb_b.partner_id = c.id
                ) as drug_meds,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_xraylabsupp_cat)
                    and rb_b.partner_id = c.id
                ) as xray_lab_supp,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_operatingroom_cat)
                    and rb_b.partner_id = c.id
                ) as operating_room,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_pfgp_cat)
                    and rb_b.partner_id = c.id
                ) as pf_general,
                (select 
                    sum((rb_a.price_unit * rb_a.quantity) - ((rb_a.price_unit * rb_a.quantity)*(rb_a.discount/100))) 
                    from account_invoice_line rb_a
                    left join account_invoice rb_b on rb_b.id = rb_a.invoice_id
                    left join product_product rb_c on rb_c.id = rb_a.product_id
                    left join product_template rb_d on rb_d.id = rb_c.product_tmpl_id
                    left join product_category rb_e on rb_e.id = rb_d.categ_id
                    where (rb_b.date_invoice >= a.hospitalization_date::date and rb_b.date_invoice <= now()::date) 
                    and rb_e.id in (select distinct(categ_id) from hospbill_phic_pfsp_cat)
                    and rb_b.partner_id = c.id
                ) as pf_spec
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join medical_hospital_bed d on d.id = a.bed
                left join product_product e on e.id = d.name
                left join medical_pathology f on f.id = a.admission_reason
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                order by partner_id
            )""")

current_inpatient_summary_report2()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
