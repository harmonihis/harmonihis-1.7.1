# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class cash_summary_report(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(cash_summary_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'time': time,
            'consultation_summary': self.__consultation_summary_report__,
            'total_consultation': self.__consultation_summary_total__,
            'xray_summary': self.__xray_summary_report__,
            'total_xray': self.__xray_summary_total__,
            'lab_summary': self.__lab_summary_report__,
            'total_lab': self.__lab_summary_total__,
            'others_summary': self.__others_summary_report__,
            'total_others': self.__others_summary_total__,
            'discount_total': self.__discount_total__,
            'grand_total': self.__grand_summary_total__,
            'getperiod': self._get_period,
            'getperiod2':self._get_period2,
        })

    def __consultation_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select d.name as product_name, sum(a.qty) as total_orders, " \
                        "sum(a.price_unit * a.qty) as sub_total, sum((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)) as total_discount, " \
                        "sum(((a.price_unit * a.qty) - ((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end))) * .12) as total_tax, " \
                        "sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and d.categ_id = 11 and (b.date_order  >= %s and b.date_order <= %s) " \
                        "group by product_name having sum(a.qty) > 0 order by product_name"   \
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __consultation_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and d.categ_id = 11 and (b.date_order  >= %s and b.date_order <= %s) " \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __xray_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select d.name as product_name, " \
                        "sum(a.qty) as total_orders, " \
                        "sum(a.price_unit * a.qty) as sub_total, sum((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)) as total_discount, " \
                        "sum(((a.price_unit * a.qty) - ((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end))) * .12) as total_tax, " \
                        "sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id = 46 or d.categ_id = 174) and (b.date_order  >= %s " \
                        "and b.date_order <= %s) " \
                        "group by product_name having sum(a.qty) > 0 order by d.name"\
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __xray_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id = 46 or d.categ_id = 174) and (b.date_order  >= %s " \
                        "and b.date_order <= %s) " \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __lab_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select d.name as product_name, " \
                        "sum(a.qty) as total_orders, " \
                        "sum(a.price_unit * a.qty) as sub_total, sum((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)) as total_discount, " \
                        "sum(((a.price_unit * a.qty) - ((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end))) * .12) as total_tax, " \
                        "sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id = 45 or d.categ_id = 172) and " \
                        "(b.date_order  >= %s and b.date_order <= %s) " \
                        "group by product_name having sum(a.qty) > 0 order by d.name"\
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __lab_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id = 45 or d.categ_id = 172) and (b.date_order  >= %s " \
                        "and b.date_order <= %s) " \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res
    
    def __others_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        data = {}
        self.cr.execute ("select d.name as product_name, sum(a.qty) as total_orders, " \
                        "sum(a.price_unit * a.qty) as sub_total, sum((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)) as total_discount, " \
                        "sum(((a.price_unit * a.qty) - ((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end))) * .12) as total_tax, " \
                        "sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        #"left join product_category e on e.id = d.categ_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id <> 11 and d.categ_id <> 45 and d.categ_id <> 46 and d.categ_id <> 172 and d.categ_id <> 174) " \
                        "and (b.date_order  >= %s and b.date_order <= %s) " \
                        "group by product_name having sum(a.qty) > 0 order by d.name"\
                    ,(dt1,dt2))
        data = self.cr.dictfetchall()
        return data

    def __others_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id <> 11 and d.categ_id <> 45 and d.categ_id <> 46 and d.categ_id <> 172 and d.categ_id <> 174) " \
                        "and (b.date_order  >= %s and b.date_order <= %s) " \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __discount_total__(self,form):    
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)) as total_discount " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (b.date_order  >= %s and b.date_order <= %s)" \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __grand_summary_total__(self,form):    
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (b.date_order  >= %s and b.date_order <= %s)" \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def _get_period(self, form):
        return form['date_start']

    def _get_period2(self,form):
        return form['date_end']

report_sxw.report_sxw('report.hospbill.cash_summary_report', 'pos.order', 'addons/hospital_billing/report/cash_summary_report.rml', parser=cash_summary_report, header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
