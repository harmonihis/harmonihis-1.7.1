# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class date_radiology_summary_report(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(date_radiology_summary_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'time': time,
            'radiology_summary': self.__radiology_summary_report__,
            'total_cash_radiology': self.__cash_radiology_summary_total__,
            'total_hmo_radiology': self.__hmo_radiology_summary_total__,
            'getperiod': self._get_period,
            'getperiod2':self._get_period2,
        })

    def __radiology_summary_report__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        dt1a = str(dt1)
        dt2a = str(dt2)
        data = {}
        self.cr.execute ("select a.id, a.default_code, b.name as product_name, " \
                        "(select sum(a1.qty) from pos_order_line a1 " \
                        "left join pos_order b1 on b1.id = a1.order_id " \
                        "where a1.product_id = a.id and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft' " \
                        "and (b1.date_order  >= '"+ str(dt1) +"' and b1.date_order <= '"+ str(dt2) +"')) as cash_total_orders, " \
                        "(select sum(a1.price_unit * a1.qty) from pos_order_line a1 " \
                        "left join pos_order b1 on b1.id = a1.order_id " \
                        "where a1.product_id = a.id and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft' " \
                        "and (b1.date_order  >= '"+ str(dt1) +"' and b1.date_order <= '"+ str(dt2) +"')) as cash_sub_total, " \
                        "(select sum((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end)) from pos_order_line a1 " \
                        "left join pos_order b1 on b1.id = a1.order_id " \
                        "where a1.product_id = a.id and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft' " \
                        "and (b1.date_order  >= '"+ str(dt1) +"' and b1.date_order <= '"+ str(dt2) +"')) as cash_total_discount, " \
                        "(select sum((a1.price_unit * a1.qty) - (((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end)))) from pos_order_line a1 " \
                        "left join pos_order b1 on b1.id = a1.order_id " \
                        "where a1.product_id = a.id and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft' " \
                        "and (b1.date_order  >= '"+ str(dt1) +"' and b1.date_order <= '"+ str(dt2) +"')) as cash_total_amt, " \
                        "(select sum(b2.quantity) from account_invoice a2 " \
                        "left join account_invoice_line b2 on b2.invoice_id = a2.id " \
                        "where b2.product_id = a.id and a2.hmo_id > 0 " \
                        "and (a2.date_invoice  >= '"+ dt1a[:10] +"' and a2.date_invoice <= '"+ dt2a[:10] +"')) as hmo_total_orders, " \
                        "(select sum(b2.price_unit * b2.quantity) from account_invoice a2 " \
                        "left join account_invoice_line b2 on b2.invoice_id = a2.id " \
                        "where b2.product_id = a.id and a2.hmo_id > 0 " \
                        "and (a2.date_invoice  >= '"+ dt1a[:10] +"' and a2.date_invoice <= '"+ dt2a[:10] +"')) as hmo_sub_total, " \
                        "(select sum(b2.discount) from account_invoice a2 " \
                        "left join account_invoice_line b2 on b2.invoice_id = a2.id " \
                        "where b2.product_id = a.id and a2.hmo_id > 0 " \
                        "and (a2.date_invoice  >= '"+ dt1a[:10] +"' and a2.date_invoice <= '"+ dt2a[:10] +"')) as hmo_total_discount, " \
                        "(select sum((b2.price_unit * b2.quantity) - b2.discount) from account_invoice a2 " \
                        "left join account_invoice_line b2 on b2.invoice_id = a2.id " \
                        "where b2.product_id = a.id and a2.hmo_id > 0 " \
                        "and (a2.date_invoice  >= '"+ dt1a[:10] +"' and a2.date_invoice <= '"+ dt2a[:10] +"')) as hmo_total_amt " \
                        "from product_product a left join product_template b on b.id = a.product_tmpl_id " \
                        "where (b.categ_id = 46 or b.categ_id = 174) " \
                        #"and ((select sum((b2.price_unit * b2.quantity) - b2.discount) " \
                        #"      from account_invoice a2 left join account_invoice_line b2 on b2.invoice_id = a2.id " \
                        #"      where b2.product_id = a.id and a2.hmo_id > 0 " \
                        #"      and (a2.date_invoice  >= '"+ dt1a[:10] +"' and a2.date_invoice <= '"+ dt2a[:10] +"')) > 0 or " \
                        #"     (select sum((a1.price_unit * a1.qty) - (((a1.price_unit * a1.qty) * (case when a1.qty <> 0 then (a1.discount / 100) else 0 end)))) " \
                        #"      from pos_order_line a1 left join pos_order b1 on b1.id = a1.order_id " \
                        #"      where a1.product_id = a.id and (b1.invoice_id = 0 or b1.invoice_id is null) and b1.state <> 'draft' " \
                        #"      and (b1.date_order  >= '"+ str(dt1) +"' and b1.date_order <= '"+ str(dt2) +"')) > 0) " \
                        "order by product_name "
                        )
        data = self.cr.dictfetchall()
        return data

    def __hmo_radiology_summary_total__(self,form):
        dt1 = str(form['date_start'])
        dt2 = str(form['date_end'])
        dt1 = dt1[:10]
        dt2 = dt2[:10]
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 46 or e.categ_id = 174) " \
                        "and (b.date_invoice  >= %s and b.date_invoice <= %s) " \
                    ,(dt1,dt2))
        res=self.cr.fetchone()[0] or 0.0
        #res=0.0
        return res

    def __cash_radiology_summary_total__(self,form):
        dt1 = form['date_start']
        dt2 = form['date_end']
        res=[]
        self.cr.execute ("select sum((a.price_unit * a.qty) - (((a.price_unit * a.qty) * (case when a.qty <> 0 then (a.discount / 100) else 0 end)))) as total " \
                        "from pos_order_line a " \
                        "left join pos_order b on b.id = a.order_id " \
                        "left join product_product c on c.id = a.product_id " \
                        "left join product_template d on d.id = c.product_tmpl_id " \
                        "where (b.invoice_id = 0 or b.invoice_id is null) and b.state <> 'draft' and (d.categ_id = 46 or d.categ_id = 174) and (b.date_order  >= %s and b.date_order <= %s) " \
                    ,(dt1,dt2))                    
        res=self.cr.fetchone()[0] or 0.0
        #res=0.0
        return res

    def _get_period(self, form):
        return form['date_start']

    def _get_period2(self,form):
        return form['date_end']
        
report_sxw.report_sxw('report.hospbill.date_radiology_summary_report', 'product.product', 'addons/hospital_billing/report/date_radiology_summary_report.rml', parser=date_radiology_summary_report, header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
