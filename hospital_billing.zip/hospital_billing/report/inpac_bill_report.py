# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw
import string
#from osv import fields, osv

class inpac_bill_report(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(inpac_bill_report, self).__init__(cr, uid, name, context=context)
        self.total = 0.0
        self.localcontext.update({
            'time': time,
            'string': string,
            'soa_roomboard': self.get_soa_roomboard,
            'soa_drugsmeds': self.get_soa_drugsmeds,
            'soa_drugsmeds_group': self.get_soa_drugsmeds_group,
            'soa_xray_lab_supp_other': self.get_soa_xray_lab_supp_oth,
            'soa_xray': self.get_soa_xray,
            'soa_xray_group': self.get_soa_xray_group,
            'soa_lab': self.get_soa_lab,
            'soa_lab_group': self.get_soa_lab_group,
            'soa_supp': self.get_soa_supp,
            'soa_supp_group': self.get_soa_supp_group,
            'soa_oth': self.get_soa_oth,
            'soa_oth_group': self.get_soa_oth_group,
            'soa_operatingroom': self.get_soa_operatingroom,
            'soa_pf': self.get_soa_pf,
            'soa_others': self.get_soa_others,
            'soa_others_group': self.get_soa_others_group,
            'total_bill': self.get_totalbill,
            'total_bill_nopf': self.get_totalbill_nopf,
            'total_disc': self.get_discval,
            'total_due': self.get_due,
            'advance_payments': self.get_advance_payments,
            'patient_address': self.get_patient_address,
            'patient_curr_room': self.get_patient_curr_room,
        })
        self.context = context
        self._node = None

    def get_soa_roomboard(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '01-room-board' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_drugsmeds(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '02-drugs-meds' " \
                        "order by phic_chg desc" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_drugsmeds_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '02-drugs-meds' " \
                        "group by particulars, price_unit, discount " \
                        "having sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) != 0 " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_xray(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '01-radiology' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_xray_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '01-radiology' " \
                        "group by particulars, price_unit, discount " \
                        "having sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) != 0 " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_lab(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '02-laboratory' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_lab_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '02-laboratory' " \
                        "group by particulars, price_unit, discount " \
                        "having sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) != 0 " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_supp(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '03-supplies' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_supp_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '03-supplies' " \
                        "group by particulars, price_unit, discount " \
                        "having sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) != 0 " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_oth(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '04-others' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_oth_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' and soa_line.sub_category = '04-others' " \
                        "group by particulars, price_unit, discount " \
                        "having sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) != 0 " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_xray_lab_supp_oth(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '03-xray-lab-supp-oth' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data
    
    def get_soa_operatingroom(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = '04-operating-room' " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data
    
    def get_soa_others(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) "\
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when soa_line.apply_disc is true then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id " \
                        "left join res_partner partner on partner.id = inpac_reg.name " \
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id " \
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = 'none' " 
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data
    
    def get_soa_others_group(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) " \
                        "as particulars, " \
                        "soa_line_inv.price_unit as price_unit, " \
                        "soa_line_inv.discount as discount, " \
                        "sum(case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end) as quantity_used, " \
                        "sum(case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end) as quantity_returned, " \
                        "sum(soa_line.phic_amt) as phic_chg, " \
                        "sum(soa_line.hmo_amt) as hmo_chg, " \
                        "sum(soa_line.discval) as discval, " \
                        "sum(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) as total_chg, " \
                        "sum(case when soa_line.apply_disc is true then soa_line.discval else 0 end) as discount_val, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "   ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end))) " \
                        "as patient_chg " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\
                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and soa_line.category = 'none' " \
                        "group by particulars, price_unit, discount " \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data

    def get_soa_pf(self, form):
        #raise osv.except_osv(('Debug !'), ("Value: " + str(form['id'])))
        soa_id = form['id']
        data = {}
        self.cr.execute ("select soa.id as id, soa.name as bill_no, inpac_reg.name as case_no, bed.name_template as bed, soa_line.category as cat, " \
                        "case when soa_line.sub_category = 'none' then ' ' else soa_line.sub_category end as sub_cat, " \
                        "trim(leading ' ' from REGEXP_REPLACE(soa_line_inv.name, E'\[[[:alnum:]-]+\]', '', 'g')) || " \
                        "case when soa_line.dv_physician_id is not null then ' [Dr. ' || phy_dv.name || ']' " \
                        "   when soa_line.surgeon_id is not null then ' [Dr. ' || surgeon.name || ']' " \
                        "   when soa_line.anesthesiologist_id is not null then ' [Dr. ' || anesthesiologist.name || ']' " \
                        "else '' end " \
                        "as particulars, " \
                        "case when soa_inv.type = 'out_invoice' then soa_line_inv.quantity else 0 end as quantity_used, " \
                        "case when soa_inv.type = 'out_refund' then soa_line_inv.quantity else 0 end as quantity_returned, " \
                        "soa_line_inv.price_unit as price_unit, soa_line_inv.discount as discount, " \
                        "disc_ref.name as discount_name, " \
                        "soa_line.phic_amt as phic_chg, soa_line.hmo_amt as hmo_chg, " \
                        "soa_line.discval as discval, " \
                        "case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end as total_chg, "\
                        "case when (soa_line.apply_disc is true or soa_line.discval > 0) then soa_line.discval else 0 end as discount_val, "\
                        "(case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "    (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "    (case when soa_line.discval is null then 0 else soa_line.discval end)) " \
                        "as patient_chg, " \
                        "soa_line.apply_disc as apply_disc, "\
                        "partner.phic_no as phic_number, partner.phic_sponsor_name as phic_member, "\
                        "hmo_member.hmo_no as hmo_number, hmo_member.whole_name as hmo_member, hmo_coy.name as hmo_coy, "\
                        "to_char(soa_inv.date_invoice, 'mm/dd') as inv_date "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id "\
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id "\
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id "\

                        "left join hr_employee dv_phy on soa_line.dv_physician_id = dv_phy.id "\
                        "left join resource_resource phy_dv on phy_dv.id = dv_phy.resource_id "\
                        "left join hr_employee surgeon_phy on soa_line.surgeon_id = surgeon_phy.id "\
                        "left join resource_resource surgeon on surgeon.id = surgeon_phy.resource_id "\
                        "left join hr_employee anes_phy on soa_line.anesthesiologist_id = anes_phy.id "\
                        "left join resource_resource anesthesiologist on anesthesiologist.id = anes_phy.resource_id "\

                        "left join his_discounts disc_ref on soa.disc_id = disc_ref.id "\
                        "left join res_partner partner on partner.id = inpac_reg.name "\
                        "left join res_partner hmo_member on partner.hmo_principal = hmo_member.id "\
                        "left join res_partner hmo_coy on hmo_member.hmo_id = hmo_coy.id "\
                        "where soa.id = " + str(soa_id) + " and (soa_line.category = '05-pf-visit-gp' or soa_line.category = '06-pf-visit-sp' or soa_line.category = '07-pf-surgery' or soa_line.category = '08-pf-anesthesiology')" \
                        #"order by cat, sub_cat" \
                    )
        data = self.cr.dictfetchall() or False
        return data
    
    def get_totalbill_nopf(self, form):
        soa_id = form['id']
        self.cr.execute("select sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end)) as total_charge, " \
                        "sum(case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) as total_phic, " \
                        "sum(case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) as total_hmo, " \
                        "sum(case when soa_line.discval is null then 0 else soa_line.discval end) as total_disc, " \
                        "sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end)) - (" \
                        "  sum(case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "  sum(case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "  sum(case when soa_line.discval is null then 0 else soa_line.discval end) " \
                        ") as total_patientchg " \
                        "from hospbill_inpac_soa soa " \
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id " \
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id " \
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id " \
                        "where soa.id = " + str(soa_id) + " and (soa_line.category <> '05-pf-visit-gp' and soa_line.category <> '06-pf-visit-sp' and soa_line.category <> '07-pf-surgery' and soa_line.category <> '08-pf-anesthesiology')"
                        )
        data = self.cr.dictfetchall() or False
        return data

    def get_totalbill(self, form):
        soa_id = form['id']
        self.cr.execute("select sum((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end)) as total_charge, " \
                        "sum(case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) as total_phic, " \
                        "sum(case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) as total_hmo, " \
                        "sum(case when soa_line.discval is null then 0 else soa_line.discval end) as total_disc " \
                        "from hospbill_inpac_soa soa " \
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id " \
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id " \
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id " \
                        "where soa.id = " + str(soa_id) 
                        )
        data = self.cr.dictfetchall() or False
        return data

    def get_discval(self, form):
        soa_id = form['id']
        res=[]
        self.cr.execute("select sum(case when soa_line.discval is null then 0 else soa_line.discval end) as total_disc " \
                        "from hospbill_inpac_soa soa " \
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id " \
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id " \
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id " \
                        "where soa_line.apply_disc is true and soa.id =" + str(soa_id) 
                        )
        res=self.cr.fetchone()[0] or 0.0
        #"where soa_inv.type <> 'out_refund' and soa_line.apply_disc is true and soa.id =" + str(soa_id) 
        return res

    def get_due(self, form):
        soa_id = form['id']
        res=[]
        self.cr.execute("select sum(((case when soa_inv.type = 'out_refund' then (soa_line_inv.price_unit * soa_line_inv.quantity)*-1 else (soa_line_inv.price_unit * soa_line_inv.quantity) end) - " \
                        "  ((case when soa_line.phic_amt is null then 0 else soa_line.phic_amt end) + " \
                        "   (case when soa_line.hmo_amt is null then 0 else soa_line.hmo_amt end) + " \
                        "   (case when soa_line.discval is null then 0 else soa_line.discval end)))) " \
                        "as total_due " \
                        "from hospbill_inpac_soa soa " \
                        "left join hospbill_inpac_soa_lines soa_line on soa_line.name = soa.id " \
                        "left join account_invoice_line soa_line_inv on soa_line.invoice_line_id = soa_line_inv.id " \
                        "left join account_invoice soa_inv on soa_line_inv.invoice_id = soa_inv.id " \
                        "where soa.id = " + str(soa_id) 
                        )
        res=self.cr.fetchone()[0] or 0.0
        return res

    def get_patient_address(self, form):
        soa_id = form['id']
        res=[]
        self.cr.execute("select case when partner.street is null then '' else partner.street || ', ' end || " \
                        "case when partner.street2 is null then '' else partner.street2 || ', ' end || " \
                        "case when partner.city is null then '' else partner.city || ', ' end || " \
                        "case when partner.state_id is null then '' else address_state.name end " \
                        "as patient_address " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join res_partner partner on inpac_reg.name = partner.id " \
                        "left join res_country_state address_state on partner.state_id = address_state.id " \
                        "where soa.id = " + str(soa_id) 
                        )
        res=self.cr.fetchone()[0] or ' '
        return res
        
    def get_patient_curr_room(self, form):
        soa_id = form['id']
        res=[]
        self.cr.execute("select bed.name_template as bed "\
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join his_room_transfer room_trans on room_trans.admission_id = inpac_reg.id and room_trans.date_out is null "\
                        "left join his_bed bed_ref on room_trans.bed_no = bed_ref.id  "\
                        "left join product_product as bed on bed.id = bed_ref.name "\
                        "where soa.id = " + str(soa_id) 
                        )
        res=self.cr.fetchone()[0] or ''
        return res
        
    def get_advance_payments(self, form):
        soa_id = form['id']
        res=[]
        self.cr.execute("select voucher.date as date_paid, voucher.reference as reference, voucher.amount as amt_paid " \
                        "from hospbill_inpac_soa soa " \
                        "left join his_admission inpac_reg on soa.patient_case_id = inpac_reg.id "\
                        "left join res_partner partner on inpac_reg.name = partner.id " \
                        "left join account_voucher voucher on partner.id = voucher.partner_id " \
                        #"left join account_voucher_line voucher_line on voucher.id = voucher_line.voucher_id " \
                        #"where ((voucher.id is not null and voucher_line.id is null) or voucher.name = 'A') and " \
                        "where (voucher.id is not null and voucher.name = 'A') and " \
                        "(voucher.date >= inpac_reg.date_admitted and voucher.date <= " \
                        "  (case when inpac_reg.date_discharged is null then now() else inpac_reg.date_discharged end)) " \
                        "and soa.id = " + str(soa_id) 
                        )
        data = self.cr.dictfetchall() or False
        return data
    
report_sxw.report_sxw('report.hospbill.inpac_soa.bill', 'hospbill.inpac_soa', 'addons/hospital_billing/report/inpac_bill_report.rml', parser=inpac_bill_report, header='False')
report_sxw.report_sxw('report.hospbill.inpac_soa.bill2', 'hospbill.inpac_soa', 'addons/hospital_billing/report/inpac_bill_summ_report.rml', parser=inpac_bill_report, header='False')
report_sxw.report_sxw('report.hospbill.phic.cf2', 'hospbill.inpac_soa', 'addons/hospital_billing/report/phic_cf2.rml', parser=inpac_bill_report, header='False')
report_sxw.report_sxw('report.hospbill.phic.cf2.2', 'hospbill.inpac_soa', 'addons/hospital_billing/report/phic_cf2_2.rml', parser=inpac_bill_report, header='False')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
