# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time

from osv import osv
from osv import fields


class inpatient_charges_summary_report(osv.osv_memory):
    _name = 'hospbill.inpatient_charges_summary_report'
    _description = 'Generate In-Patient Charges Summary Report'

    def print_report(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        datas = {'ids': context.get('active_ids', [])}
        res = self.read(cr, uid, ids, ['date_start', 'date_end'], context=context)
        res = res and res[0] or {}
        datas['form'] = res
        if res.get('id',False):
            datas['ids']=[res['id']]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'hospbill.inpatient_charges_summary_report',
            'datas': datas,
        }

    _columns = {
        'date_start': fields.datetime('Start Date', required=True),
        'date_end': fields.datetime('End Date', required=True),
    }

    _defaults = {
        'date_start': lambda *a: time.strftime('%Y-%m-%d 00:00:00'),
        'date_end': lambda *a: time.strftime('%Y-%m-%d 23:59:00'),
    }
    
inpatient_charges_summary_report()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

