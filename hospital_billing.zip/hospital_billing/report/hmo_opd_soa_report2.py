# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields, osv
import tools

class hmo_opd_soa_report2 (osv.osv):
    _name = "hospbill.hmo_opd_soa_report2"
    _description = "HMO OPD Statement of Account"
    _auto = False
    _rec_name = 'hmo_id'
    _columns = {
        'hmo_id': fields.many2one('hospbill.hmo_partner', 'HMO ID', readonly=True),
        'hmo_partner': fields.char('HMO', size=128, readonly=True),
        'period_id': fields.many2one('account.period', 'Period ID', readonly=True),
        'soa_period_id': fields.many2one('account.period', 'SOA Period ID', readonly=True),
        'period': fields.char('Period', size=20, readonly=True),
        'invoice_number': fields.char('Invoice Number', size=30, readonly=True),
        'date_invoice': fields.date('Date', readonly=True),
        'patient_name': fields.char('Name', size=128, readonly=True),
        'hmo_idnumber': fields.char('ID Number', size=64, readonly=True),
        'invoice_line': fields.char('Details', size=128, readonly=True),
        'amount': fields.float('Amount', readonly=True),
        'physician_name': fields.char('Physician', size=128, readonly=True),
    }
    _order = 'date_invoice, patient_name'
    
    def init(self, cr):
        tools.drop_view_if_exists(cr, 'hospbill_hmo_opd_soa_report2')
        cr.execute("""
            create or replace view hospbill_hmo_opd_soa_report2 as (
                SELECT a.id, a.hmo_id, b.name AS hmo_partner_id, c.name AS hmo_partner, 
                a.period_id, a.soa_period_id, f.name AS period, d.invoice_id, j.number AS hmo_idnumber, 
                a.number AS invoice_number, a.partner_id, a.date_invoice, e.name AS patient_name, 
                d.price_unit * d.quantity::numeric AS amount, d.name AS invoice_line, 
                g.primary_care_doctor AS physician_id, i.name AS physician_name
                FROM account_invoice a
                left join hospbill_hmo_partner b ON a.hmo_id = b.id
                left join res_partner c on b.name = c.id
                left join account_invoice_line d on a.id = d.invoice_id
                left join res_partner e on a.partner_id = e.id
                left join account_period f on a.soa_period_id = f.id
                left join medical_patient g ON a.partner_id = g.name
                left join medical_physician h ON g.primary_care_doctor = h.id
                left join res_partner i ON h.name = i.id
                left join medical_insurance j ON a.partner_id = j.name AND j.company = b.name
                where hmo_id > 0
            )
        """)
hmo_opd_soa_report2()

