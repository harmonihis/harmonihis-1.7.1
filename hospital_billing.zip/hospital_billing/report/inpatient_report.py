# -*- coding: utf-8 -*-
#		 Hospital Billing Copyright (c) 2011 by Edwin N. Gonzales

#    Copyright (C) 2011 by Edwin N. Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

from osv import fields,osv
import tools

class current_inpatient_report(osv.osv):
    """ Hospital Billing Current In-Patient Report """
    _name = "hospbill.current_inpatient.report"
    _auto = False
    _description = "Current In-Patient Report"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_name': fields.char('Patient', size=128, readonly=True),
        'patient_info': fields.char('Patient Info', size=256, readonly=True),
        'case_no': fields.char('Case Number', size=128, readonly=True),
        'bed_product_name' : fields.char ('Room/Bed', size=128, readonly=True),
        'hospitalization_date': fields.date('Date Admitted', readonly=True),
        'days': fields.char('Length of Stay', size=64, readonly=True),
        'invoice_no': fields.char('Invoice Number', size=64, readonly=True),
        'date_invoice': fields.date('Invoice Date', readonly=True),
        'product_category': fields.char('Category', size=128, readonly=True),
        'product_service': fields.char('Product/Service', size=128, readonly=True),
        'price_subtotal': fields.float('Sub-Total', readonly=True),
        'phic_covered': fields.boolean('PHIC Covered'),
        'hmo_covered': fields.boolean('HMO Covered'),
    }

    _order = 'patient_name'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_current_inpatient_report')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_current_inpatient_report AS (
                SELECT
                (case when g.id is null then a.patient else a.patient + g.id end) as id, 
                a.patient as patient_id, c.id as partner_id, 
                (c.name||' '||case when c.lastname is null then '' else c.lastname end) as patient_name, 
                ('['||a.name||'] '||c.name||case when c.lastname is null then '' else c.lastname end||' ('||e.name_template||')') as patient_info,
                a.state, a.name as case_no, a.bed as bed_id, d.name as bed_product_id, 
                e.name_template as bed_product_name, a.hospitalization_date, 
                (now() - a.hospitalization_date) as days,
                f.number as invoice_no, f.date_invoice, j.name as product_category,
                g.name as product_service, 
                (g.price_unit * g.quantity) - ((g.price_unit * g.quantity)*(g.discount/100)) as price_subtotal, 
                g.phic_covered, g.hmo_covered
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join medical_hospital_bed d on d.id = a.bed
                left join product_product e on e.id = d.name
                left join account_invoice f on f.partner_id = c.id and (f.date_invoice >= a.hospitalization_date::date and f.date_invoice <= now()::date)
                left join account_invoice_line g on g.invoice_id = f.id
                left join product_product h on h.id = g.product_id
                left join product_template i on i.id = h.product_tmpl_id
                left join product_category j on j.id = i.categ_id
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                order by partner_id
            )""")

current_inpatient_report()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
