# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class hmo_opd_soa_report_summary(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(hmo_opd_soa_report_summary, self).__init__(cr, uid, name, context=context)
        self.total = 0.0
        self.localcontext.update({
            'time': time,
            'hmo_opd_soa_summary': self.__hmo_opd_soa_summary_report__,
            'soa_summary_total_pf': self.__hmo_opd_soa_summary_total_pf__,
            'soa_summary_total_lab': self.__hmo_opd_soa_summary_total_lab__,
            'soa_summary_total_meds': self.__hmo_opd_soa_summary_total_meds__,
            'soa_summary_total_oth': self.__hmo_opd_soa_summary_total_oth__,
            'soa_summary_hmo_name': self.__hmo_opd_soa_summary_hmo_name__,
            'soa_summary_hmo_period': self.__hmo_opd_soa_summary_period__,
        })

    def __hmo_opd_soa_summary_report__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        data = {}
        self.cr.execute ("select a.patient_name as patient_name, " \
                        "sum(a.pf) as pf, sum(a.lab) as lab, sum(a.meds) as meds, sum(a.others) as others  " \
                        "from hospbill_hmo_opd_soa_report_summary as a " \
                        "where a.hmo_id = %s and a.soa_period_id = %s " \
                        "group by a.patient_name " \
                        "order by a.patient_name" \
                    ,(hmo,period))
        data = self.cr.dictfetchall()
        return data
    
    def __hmo_opd_soa_summary_hmo_name__(self,form):
        hmo = form['hmo_id']
        res1=[]
        self.cr.execute ("select a.name as hmoname from res_partner a, hospbill_hmo_partner b "\
                        "where (a.id = b.name) and b.id = " + str(hmo))
     
        res1=self.cr.fetchone()[0] or 'NONE'
        return res1

    def __hmo_opd_soa_summary_period__(self,form):
        period = form['rep_period']
        res2=[]
        self.cr.execute ("select name as period from account_period "\
                        "where id = " + str(period))
                        
        res2=self.cr.fetchone()[0] or 'NONE'
        return res2
    
    def __hmo_opd_soa_summary_total_pf__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        res=[]
        self.cr.execute ("select sum(a.pf) as grand_total  " \
                        "from hospbill_hmo_opd_soa_report_summary as a " \
                        "where a.soa_period_id = %s and a.hmo_id = %s" \
                    ,(period,hmo))
                    
        res=self.cr.fetchone()[0] or 0.0
        return res
            
    def __hmo_opd_soa_summary_total_lab__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        res=[]
        self.cr.execute ("select sum(a.lab) as grand_total  " \
                        "from hospbill_hmo_opd_soa_report_summary as a " \
                        "where a.soa_period_id = %s and a.hmo_id = %s" \
                    ,(period,hmo))
                    
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __hmo_opd_soa_summary_total_meds__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        res=[]
        self.cr.execute ("select sum(a.meds) as grand_total  " \
                        "from hospbill_hmo_opd_soa_report_summary as a " \
                        "where a.soa_period_id = %s and a.hmo_id = %s" \
                    ,(period,hmo))
                    
        res=self.cr.fetchone()[0] or 0.0
        return res
    
    def __hmo_opd_soa_summary_total_oth__(self,form):
        period = form['rep_period']
        hmo = form['hmo_id']
        res=[]
        self.cr.execute ("select sum(a.others) as grand_total  " \
                        "from hospbill_hmo_opd_soa_report_summary as a " \
                        "where a.soa_period_id = %s and a.hmo_id = %s" \
                    ,(period,hmo))
                    
        res=self.cr.fetchone()[0] or 0.0
        return res

report_sxw.report_sxw('report.hospbill.hmo_opd_soa_report_summary', 'hospbill.hmo_opd_soa_report_summary', 'addons/hospital_billing/report/hmo_opd_soa_report_summary.rml', parser=hmo_opd_soa_report_summary,header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: