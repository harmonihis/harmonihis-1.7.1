# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
from report import report_sxw

class hmo_opd_summary_report2(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(hmo_opd_summary_report2, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'time': time,
            'consultation_summary': self.__consultation_summary_report__,
            'total_consultation': self.__consultation_summary_total__,
            'xray_summary': self.__xray_summary_report__,
            'total_xray': self.__xray_summary_total__,
            'lab_summary': self.__lab_summary_report__,
            'total_lab': self.__lab_summary_total__,
            'others_summary': self.__others_summary_report__,
            'total_others': self.__others_summary_total__,
            'grand_total': self.__grand_summary_total__,
            'hmo_opd_summary_period': self.__hmo_opd_summary_period__,
        })

    def __consultation_summary_report__(self,form):
        period = form['rep_period']
        data = {}
        self.cr.execute ("select e.name as product_name, count(b.id) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id  " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and e.categ_id = 11 " \
                        "and b.soa_period_id = " + str(period) + " " \
                        "group by product_name order by product_name")
        data = self.cr.dictfetchall()
        return data

    def __consultation_summary_total__(self,form):
        period = form['rep_period']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and e.categ_id = 11 " \
                        "and b.soa_period_id = "+ str(period))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __xray_summary_report__(self,form):
        period = form['rep_period']
        data = {}
        self.cr.execute ("select e.name as product_name, sum(c.quantity) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 46 or e.categ_id = 174) " \
                        "and b.soa_period_id = " + str(period) + " " \
                        "group by product_name order by product_name")
        data = self.cr.dictfetchall()
        return data

    def __xray_summary_total__(self,form):
        period = form['rep_period']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 46 or e.categ_id = 174) " \
                        "and b.soa_period_id = " + str(period))
        res=self.cr.fetchone()[0] or 0.0
        return res
    
    def __lab_summary_report__(self,form):
        period = form['rep_period']
        data = {}
        self.cr.execute ("select e.name as product_name, sum(c.quantity) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 45 or e.categ_id = 172) " \
                        "and b.soa_period_id = " + str(period) + " " \
                        "group by product_name order by product_name")
        data = self.cr.dictfetchall()
        return data

    def __lab_summary_total__(self,form):
        period = form['rep_period']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id = 45 or e.categ_id = 172) " \
                        "and b.soa_period_id = " + str(period))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __others_summary_report__(self,form):
        period = form['rep_period']
        data = {}
        self.cr.execute ("select f.name as category, count(b.id) as total_orders, " \
                        "sum(c.price_unit * c.quantity) as sub_total, sum(c.discount) as total_discount, " \
                        "sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "left join product_category f on f.id = e.categ_id " \
                        "where b.hmo_id > 0 and (e.categ_id <> 11 and e.categ_id <> 45 and e.categ_id <> 46 and e.categ_id <> 172 and e.categ_id <> 174) " \
                        "and b.soa_period_id = " + str(period) + " " \
                        "group by category order by category")
        data = self.cr.dictfetchall()
        return data

    def __others_summary_total__(self,form):
        period = form['rep_period']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "left join product_product d on d.id = c.product_id " \
                        "left join product_template e on e.id = d.product_tmpl_id " \
                        "where b.hmo_id > 0 and (e.categ_id <> 11 and e.categ_id <> 45 and e.categ_id <> 46 and e.categ_id <> 172 and e.categ_id <> 174) " \
                        "and b.soa_period_id = " + str(period))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __grand_summary_total__(self,form):    
        period = form['rep_period']
        res=[]
        self.cr.execute ("select sum((c.price_unit * c.quantity) - c.discount) as total " \
                        "from account_invoice b " \
                        "left join account_invoice_line c on c.invoice_id = b.id " \
                        "where b.hmo_id > 0 and b.soa_period_id = " + str(period))
        res=self.cr.fetchone()[0] or 0.0
        return res

    def __hmo_opd_summary_period__(self,form):
        period = form['rep_period']
        res2=[]
        self.cr.execute ("select name as period from account_period "\
                        "where id = " + str(period))
                        
        res2=self.cr.fetchone()[0] or 'NONE'
        return res2
        
report_sxw.report_sxw('report.hospbill.hmo_opd_summary_report2', 'account.invoice', 'addons/hospital_billing/report/hmo_opd_summary_report.rml', parser=hmo_opd_summary_report2, header='Internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
