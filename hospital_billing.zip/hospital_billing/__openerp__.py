# -*- encoding: utf-8 -*-
{

    'name' : 'Hospital Billing System',  
    'version' : '0.22',
    'author' : 'Edwin N. Gonzales',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['base','account','product','hospital_mgmt','his_admission','his_icd10_code','his_hmo_partner','his_discountlist'],
    'description' : """

About Hospital Billing System
-------------
Hospital Billing System is designed to support the billing requirements of hospitals in the Philippines. It is based on the Medical Module and supports the following requirements:

1. Philhealth claims 
2. HMO
3. Billing
4. Invoicing

""",
    "website" : "http://www.fossxtreme.com",
    "init_xml" : [],
    "demo_xml" : [],

    "update_xml" : ["hospbill_inpac_bill_report.xml","wizard/inpac_get_invoice_line.xml","hospbill_hmo_billing_view.xml", "hospbill_phic_config_view.xml","hospbill_inpatient_billing_view.xml","hospbill_sequence.xml","data/casetypes.xml","data/operating_room.xml","data/phic_partner.xml"],
    
    "active": False 
}

#"hospbill_hmo_billing_view.xml", "hospbill_phic_config_view.xml","hospbill_hmo_config_view.xml","hospbill_inpatient_billing_view.xml", "hospbill_report.xml","hospbill_inpac_bill_report.xml","hospbill_sequence.xml","wizard/inpac_get_invoice_line.xml","report/inpatient_report_view.xml","report/inpatient_report_view2.xml","report/hmo_opd_soa_report_gen2.xml","report/hmo_opd_summary_report2.xml","report/hmo_opd_soa_report_summary.xml","report/cash_summary_report.xml","report/hmo_summary_report.xml","report/inpatient_charges_summary_report.xml","report/date_prof_fee_summary_report.xml","report/date_radiology_summary_report.xml","data/casetypes.xml","data/operating_room.xml","data/phic_partner.xml","security/hospbill_security.xml","security/ir.model.access.csv","board_inpatient_view.xml","report/hmo_opd_soa_report_view2.xml"
#,"board_inpatient_view.xml","report/hmo_opd_soa_report_view2.xml"
#,"security/hospbill_security.xml","security/ir.model.access.csv"
