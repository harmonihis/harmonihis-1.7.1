# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


import time
from mx import DateTime
import datetime
from osv import fields, osv
import tools
from tools.translate import _

#DEBUG MODE -- DELETE ME !
# import pdb

class account_invoice_line_mods(osv.osv):
    _name = "account.invoice.line"
    _inherit = "account.invoice.line"
    _columns = {
        'phic_covered' : fields.boolean('Philhealth Covered'),
        'hmo_covered' : fields.boolean('HMO Covered'),
    }

account_invoice_line_mods()

class medical_physician_mods(osv.osv):
    _name = "medical.physician"
    _inherit = "medical.physician"
    _columns = {
        'surgeon_class' : fields.many2one ('hospbill.phic_surgery','Surgeon Classification'),
        'phic_accred_no' : fields.char('PHIC Number', size=30),
    }

medical_physician_mods()

class inpac_soa_patient_list(osv.osv):
    _name = "hospbill.inpac_soa_patient_list_view"
    _auto = False
    _description = "In-Patient Statement of Account List of Patients"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_id': fields.integer('Patient ID', readonly=True),
        'partner_id': fields.integer('Partner ID', readonly=True),
        'patient_name': fields.char('Patient Name', size=256, readonly=True),
        'name': fields.char('Patient Info', size=256, readonly=True),
        'case_no': fields.char('Case Number', size=128, readonly=True),
        'bed_product_name' : fields.char ('Room/Bed', size=128, readonly=True),
        'hospitalization_date': fields.date('Date Admitted', readonly=True),
        'days': fields.char('Length of Stay', size=64, readonly=True),
    }

    _order = 'id'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_inpac_soa_patient_list_view')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_inpac_soa_patient_list_view AS (
                SELECT
                a.id as id, a.patient as patient_id, c.id as partner_id, c.name as patient_name, 
                ('['||a.name||'] '||c.name||' ('||e.name_template||')') as name,
                a.state, a.name as case_no, a.bed as bed_id, d.name as bed_product_id, e.name_template as bed_product_name,
                a.hospitalization_date, (now() - a.hospitalization_date) as days
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join medical_hospital_bed d on d.id = a.bed
                left join product_product e on e.id = d.name
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                order by id
            )""")

inpac_soa_patient_list()

class inpac_soa_lines_ref(osv.osv):
    _name = "hospbill.inpac_soa_lines_ref_view"
    _auto = False
    _description = "In-Patient Statement of Account Item Reference"

    _columns = {
        'id': fields.integer('ID', readonly=True),
        'patient_id': fields.integer('Patient', readonly=True),
        'partner_id': fields.integer('Partner', readonly=True),
        'invoice_no': fields.char('Invoice Number', size=64, readonly=True),
        'date_invoice': fields.date('Invoice Date', readonly=True),
        'product_category': fields.char('Category', size=128, readonly=True),
        'name': fields.char('Product/Service', size=256, readonly=True),
        'price_subtotal': fields.float('Sub-Total', readonly=True),
        'phic_covered': fields.boolean('PHIC Covered'),
        'hmo_covered': fields.boolean('HMO Covered'),
    }

    _order = 'id'
    
    def init(self, cr):

        tools.drop_view_if_exists(cr, 'hospbill_inpac_soa_lines_ref_view')
        cr.execute("""
            CREATE OR REPLACE VIEW hospbill_inpac_soa_lines_ref_view AS (
                SELECT
                g.id as id, a.patient as patient_id, c.id as partner_id,
                f.number as invoice_no, f.date_invoice, j.name as product_category, g.name as name, 
                (g.price_unit * g.quantity) - ((g.price_unit * g.quantity)*(g.discount/100)) as price_subtotal, 
                g.phic_covered, g.hmo_covered
                from medical_inpatient_registration a
                left join medical_patient b on b.id = a.patient
                left join res_partner c on c.id = b.name
                left join account_invoice f on f.partner_id = c.id and (f.date_invoice >= a.hospitalization_date::date and f.date_invoice <= now()::date)
                left join account_invoice_line g on g.invoice_id = f.id
                left join product_product h on h.id = g.product_id
                left join product_template i on i.id = h.product_tmpl_id
                left join product_category j on j.id = i.categ_id
                where a.patient > 0 and a.state='hospitalized' and ((now() - a.hospitalization_date) > '0')
                and g.id is not null
                order by partner_id
            )""")

inpac_soa_lines_ref()

class inpac_soa (osv.osv):
    _name = "hospbill.inpac_soa"
    _description = "In-patient Statement of Account"
    _columns = {
        'name' : fields.integer ('Bill Number',required="1",states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'date_processed': fields.date('Date Processed', select=True, readonly=True),
        'patient_case_id' : fields.many2one ('medical.inpatient.registration', 'Case No.', required=True, states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'diagnosis': fields.related ('patient_case_id','admission_reason','name',type="char", size="256",string="Diagnosis",store=False, readonly=True),
        'phic_casetype': fields.related ('patient_case_id','admission_reason','casetype_id','name',type="char", size="8",string="PHIC Case Type",store=False, readonly=True),
        'phic_package': fields.related ('patient_case_id','admission_reason','package_id','name',type="char", size="50",string="PHIC Package",store=False, readonly=True),
        'icd': fields.related ('patient_case_id','admission_reason','code',type="char", size="64",string="ICD Code",store=False, readonly=True),
        'pricelist_id' : fields.many2one ('product.pricelist', 'Price List', required=True,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'inpac_soa_invoices' : fields.one2many ('hospbill.inpac_soa_lines', 'name', 'In-Patient SOA Invoice Lines' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'note': fields.text('Note' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'phic_charge': fields.boolean('Claiming PHIC?' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'hmo_charge': fields.boolean('Claiming HMO?' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'phic_member_id' : fields.many2one ('medical.insurance', 'PHIC Member ID', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'phic_member': fields.related ('phic_member_id','name','name',type="char", size="256",string="PHIC Member Name",store=False, readonly=True),
        'hmo_member_id' : fields.many2one ('medical.insurance', 'HMO Member ID', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'hmo_member': fields.related ('hmo_member_id','name','name',type="char", size="256",string="HMO Member Name",store=False, readonly=True),
        'disc_id' : fields.many2one ('hospbill.discounts', 'Discount', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'state': fields.selection([
            ('draft','Draft'),
            ('process','Processed'),
            ('cancel','Cancelled')
            ],'State', select=True, readonly=True),
    }

    _sql_constraints = [
        ('bill_uniq', 'unique (name)', 'The Bill Number should be unique.')
    ]

    _defaults = {
        'name': lambda obj, cr, uid, context: obj.pool.get('ir.sequence').get(cr, uid, 'hospbill.inpac_soa'),
        'pricelist_id' : 1,
        'state': 'draft',
    }

    def button_phic_compute(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        soa_rec = self.browse(cr, uid, ids)[0]
        soa_lines_rec = self.pool.get('hospbill.inpac_soa_lines')
        operating_room_ref_obj = self.pool.get('hospbill.phic_operatingroom_amt')
        if soa_rec.phic_charge:
            diagnosis_id = soa_rec.patient_case_id.admission_reason
            if diagnosis_id:
                #PHIC Specific vars
                casetype_id = soa_rec.patient_case_id.admission_reason.casetype_id.id
                package_id = soa_rec.patient_case_id.admission_reason.package_id.id
                #Room and Board vars
                roomboard_amt = soa_rec.patient_case_id.admission_reason.casetype_id.roomboard
                roomboard_maxdays = soa_rec.patient_case_id.admission_reason.casetype_id.roomboard_maxdays
                #X-Ray, Lab, and Others vars
                xraylaboth_maxamt = soa_rec.patient_case_id.admission_reason.casetype_id.xraylabsupp
                #Professional Fee (Dailt Visits) vars
                pfgpperday = soa_rec.patient_case_id.admission_reason.casetype_id.pfgpperday
                pfgpmax = soa_rec.patient_case_id.admission_reason.casetype_id.pfgpmax
                pfspperday = soa_rec.patient_case_id.admission_reason.casetype_id.pfspperday
                pfspmax = soa_rec.patient_case_id.admission_reason.casetype_id.pfspmax
                #Invoice Line
                inv_lines_rec = soa_rec.inpac_soa_invoices
                #if package_id: #Process PHIC Package
                #    pass
                if casetype_id: #Process PHIC Case Type
                    #Get the highest RVU and compute the Surgeon PF
                    highest_rvu = 0
                    highest_rvu_id = 0
                    pfsurgery = 0
                    pfanesthesiologist = 0
                    for inv_line_rvu in inv_lines_rec:
                        if inv_line_rvu.phic_covered and inv_line_rvu.category == '07-pf-surgery':
                            if inv_line_rvu.phic_rvu > highest_rvu:
                                highest_rvu = inv_line_rvu.phic_rvu
                                highest_rvu_id = inv_line_rvu.id
                                #Compute PF (Surgeon and Anesthesiologist)
                                if inv_line_rvu.surgeon_id > 0:
                                    if inv_line_rvu.surgeon_id.surgeon_class > 0:
                                        pfsurgery_pcf = inv_line_rvu.surgeon_id.surgeon_class.surgeon_pcf
                                        pfsurgery_max_amt = inv_line_rvu.surgeon_id.surgeon_class.surgeon_max
                                        pfanesthe_pct = inv_line_rvu.surgeon_id.surgeon_class.anesthe_pct
                                        pfanesthe_max_amt = inv_line_rvu.surgeon_id.surgeon_class.anesthe_max
                                        computed_amt1 = int(highest_rvu) * int(pfsurgery_pcf)
                                        if computed_amt1 > pfsurgery_max_amt:
                                            pfsurgery = pfsurgery_max_amt
                                        else:
                                            pfsurgery = computed_amt1
                                        
                                        computed_amt2 = pfsurgery * (pfanesthe_pct/100)
                                        if computed_amt2 > pfanesthe_max_amt:
                                            pfanesthesiologist = pfanesthe_max_amt
                                        else:
                                            pfanesthesiologist = computed_amt2
                                        #raise osv.except_osv(('Error!'), ("Values - Total: " + str(computed_amt1) + " | RVU: " + str(highest_rvu) + " | PCF: " + str(pfsurgery_pcf) ))
                    or_pcf = 0
                    or_min_amt = 0
                    or_max_amt = 0
                    if highest_rvu > 0:
                        operating_room_ids = operating_room_ref_obj.search(cr,uid, [
                                            ('rvu_min','<=',highest_rvu),
                                            ('rvu_max','>=',highest_rvu)])
                        if operating_room_ids:
                            or_ref_data = {}
                            or_ref_data = operating_room_ref_obj.browse(cr, uid, operating_room_ids, context=context)
                            or_ref = or_ref_data[0]
                            or_pcf = or_ref.pcf
                            or_min_amt = or_ref.min_amt
                            or_max_amt = or_ref.max_amt
                    
                    #Start processing the invoice lines
                    inv_line_ctr = 0
                    inv_line_nomatch = 0
                    roomboard_ctr = 0
                    roomboard_sw = 0
                    xraylaboth_amtctr = 0
                    pfgpamt_ctr = 0
                    pfgp_sw = 0
                    pfspamt_ctr = 0
                    pfsp_sw = 0
                    for inv_line in inv_lines_rec:
                        inv_line_ctr += 1
                        #Check if invoice line is set for PHIC
                        if inv_line.phic_covered:
                            #Check if invoice line is Room and Board
                            if inv_line.category == '01-room-board':
                                roomboard_ctr += inv_line.quantity
                                if roomboard_ctr <= roomboard_maxdays:
                                    if inv_line.price_unit > roomboard_amt:
                                        amt = roomboard_amt * inv_line.quantity
                                    else:
                                        amt = inv_line.price_subtotal
                                else:
                                    if roomboard_sw == 0:
                                        roomboard_sw = 1
                                        excessdays = roomboard_ctr - roomboard_maxdays
                                        if inv_line.price_unit > roomboard_amt:
                                            amt = roomboard_amt * (inv_line.quantity - excessdays)
                                        else:
                                            amt = inv_line.price_unit * (inv_line.quantity - excessdays)
                                    else:
                                        amt = 0
                                
                                #Check if invoice line is Drugs and Medicines
                            elif inv_line.category == '02-drugs-meds':
                                #Todo: Check if total drugs and meds exceeds limit based on case type
                                amt = inv_line.price_subtotal
                                    
                            #Check if invoice line is X-Ray, Lab, Supplies, and Others
                            elif inv_line.category == '03-xray-lab-supp-oth':
                                xraylaboth_amtctr += inv_line.price_subtotal
                                if xraylaboth_amtctr <= xraylaboth_maxamt:
                                    amt = inv_line.price_subtotal
                                else:
                                    amt = 0
                                    xraylaboth_amtctr -= inv_line.price_subtotal
                                
                            #Check if invoice line is Operating Room Charges
                            elif inv_line.category == '04-operating-room':
                                if highest_rvu <= 0: #No RVU found so we charge to patient
                                    amt = 0
                                else:
                                    if or_min_amt == or_max_amt:
                                        amt = or_max_amt
                                    else:
                                        rvu_pcf_val = int(highest_rvu) * int(or_pcf)
                                        if rvu_pcf_val <= or_min_amt:
                                            amt = or_min_amt
                                        elif rvu_pcf_val >= or_max_amt:
                                            amt = or_max_amt
                                        else:
                                            amt = rvu_pcf_val
                            #Check if invoice line is PF Gen. Practitioner (Daily Visit)
                            elif inv_line.category == '05-pf-visit-gp':
                                if inv_line.price_unit > pfgpperday:
                                    pfgpamt = pfgpperday * inv_line.quantity
                                else:
                                    pfgpamt = inv_line.price_subtotal

                                pfgpamt_ctr += pfgpamt
                                if pfgpamt_ctr <= pfgpmax:
                                    amt = pfgpamt
                                else:
                                    if pfgp_sw == 0:
                                        pfgp_sw = 1
                                        excesspfgp = pfgpamt_ctr - pfgpamt
                                        amt = pfgpmax - excesspfgp
                                    else:
                                        amt = 0

                            #Check if invoice line is PF Specialist (Daily Visit)
                            elif inv_line.category == '06-pf-visit-sp':
                                if inv_line.price_unit > pfspperday:
                                    pfspamt = pfspperday * inv_line.quantity
                                else:
                                    pfspamt = inv_line.price_subtotal

                                pfspamt_ctr += pfspamt
                                if pfspamt_ctr <= pfspmax:
                                    amt = pfspamt
                                else:
                                    if pfsp_sw == 0:
                                        pfsp_sw = 1
                                        excesspfsp = pfspamt_ctr - pfspamt
                                        amt = pfspmax - excesspfsp
                                    else:
                                        amt = 0

                            #Check if invoice line is Surgery Prof. Fee
                            elif inv_line.category == '07-pf-surgery':
                                if pfsurgery <= 0: #No Surgeon PF found so we charge to patient
                                    amt = 0
                                else:
                                    if inv_line.id == highest_rvu_id:
                                        amt = pfsurgery
                                    else:
                                        amt = 0

                            #Check if invoice line is Ansthesiology Prof. Fee
                            elif inv_line.category == '08-pf-anesthesiology':
                                if pfanesthesiologist <= 0: #No Anesthesiology PF found so we charge to patient
                                    amt = 0
                                else:
                                    if inv_line.id == highest_rvu_id:
                                        amt = pfanesthesiologist
                                    else:
                                        amt = 0
                            else:
                                inv_line_nomatch += 1
                                amt = 0
                        else:
                            inv_line_nomatch += 1
                            amt =0

                        #Update SOA Lines
                        try:
                            soa_lines_rec.write(cr, uid, [inv_line.id], {'phic_amt' : amt})
                        except:
                            raise osv.except_osv(('Error!'), ("Cannot update SOA lines (Value: " + str(inv_line.price_subtotal) + ")" ))

                    #No record processed for PHIC charge        
                    if inv_line_ctr == inv_line_nomatch:
                        raise osv.except_osv(('Error !'), ("No invoice line was processed for PHIC claim. " + str(inv_line_ctr) + " invoice lines evaluated."))
                    """else:
                        warning = {'title': ('Success!'),
                                'message': ('Done processing PHIC charges.')}
                        return {'warning': warning, 'nodestroy':True}"""
                else:
                    raise osv.except_osv(('Error !'), ("Patient's diagnosis is not yet classified based on the PHIC case type or package."))
            else:
                raise osv.except_osv(('Error !'), ("No diagnosis was encoded for this patient's case."))
        else:
            raise osv.except_osv(('Error !'), ("Patient's case is not charged to PHIC."))
        return True

    def get_bill_cat(self, cr, uid, product_id, product_cat_id, context=None):
        cat = 'none'
        subcat= 'none'
        if not product_id or not product_cat_id:
            return False
        #Check if product/service is Room and Board
        roomboard_cat_obj = self.pool.get('hospbill.phic_roomboard_cat')
        roomboard_cat_ids = roomboard_cat_obj.search(cr,uid, [
                        ('categ_id','=',product_cat_id)])
        if roomboard_cat_ids:
            cat = '01-room-board'
            subcat = 'none'
        else:
            #Check if product/service is Drugs and Medicines
            drugsmeds_cat_obj = self.pool.get('hospbill.phic_drugsmeds_cat')
            drugsmeds_cat_ids = drugsmeds_cat_obj.search(cr,uid, [
                            ('categ_id','=',product_cat_id)])
            if drugsmeds_cat_ids:
                cat = '02-drugs-meds'
                subcat = 'none'
            else:
                #Check if product/service is X-Ray, Lab, Supplies, and Others
                xraylabsupp_cat_obj = self.pool.get('hospbill.phic_xraylabsupp_cat')
                xraylabsupp_cat_ids = xraylabsupp_cat_obj.search(cr,uid, [
                                ('categ_id','=',product_cat_id)])
                if xraylabsupp_cat_ids:
                    cat = '03-xray-lab-supp-oth'
                    xraylabsupp_data = xraylabsupp_cat_obj.browse(cr, uid, xraylabsupp_cat_ids, context=None)
                    xraylabsupp = xraylabsupp_data[0]
                    if xraylabsupp.sub_categ == 'r':
                        subcat = '01-radiology'
                    elif xraylabsupp.sub_categ == 'l':
                        subcat = '02-laboratory'
                    elif xraylabsupp.sub_categ == 's':
                        subcat = '03-supplies'
                    elif xraylabsupp.sub_categ == 'o':
                        subcat = '04-others'
                    else:
                        subcat = 'none'
                else:
                    #Check if product/service is Operating Room Charges
                    operatingroom_cat_obj = self.pool.get('hospbill.phic_operatingroom_cat')
                    operatingroom_cat_ids = operatingroom_cat_obj.search(cr,uid, [
                                    ('categ_id','=',product_cat_id)])
                    if operatingroom_cat_ids:
                        cat = '04-operating-room'
                        subcat = 'none'
                    else:
                        #Check if product/service is PF Gen. Practitioner (Daily Visit)
                        pfgp_cat_obj = self.pool.get('hospbill.phic_pfgp_cat')
                        pfgp_cat_ids = pfgp_cat_obj.search(cr,uid, [
                                        ('categ_id','=',product_cat_id)])
                        if pfgp_cat_ids:
                            cat = '05-pf-visit-gp'
                            subcat = 'none'
                        else:
                            #Check if product/service is PF Specialist (Daily Visit)
                            pfsp_cat_obj = self.pool.get('hospbill.phic_pfsp_cat')
                            pfsp_cat_ids = pfsp_cat_obj.search(cr,uid, [
                                            ('categ_id','=',product_cat_id)])
                            if pfsp_cat_ids:
                                cat = '06-pf-visit-sp'
                                subcat = 'none'
                            else:
                                #Check if product/service is Surgery Prof. Fee
                                surgery_cat_obj = self.pool.get('hospbill.phic_surgery_cat')
                                surgery_cat_ids = surgery_cat_obj.search(cr,uid, [
                                                ('categ_id','=',product_cat_id)])
                                if surgery_cat_ids:
                                    cat = '07-pf-surgery'
                                    subcat = 'none'
                                else:
                                    #Check if product/service is Anesthesiology Prof. Fee
                                    anesthesiology_cat_obj = self.pool.get('hospbill.phic_anesthesiology_cat')
                                    anesthesiology_cat_ids = anesthesiology_cat_obj.search(cr,uid, [
                                                    ('categ_id','=',product_cat_id)])
                                    if anesthesiology_cat_ids:
                                        cat = '08-pf-anesthesiology'
                                        subcat = 'none'
                                            
        return cat, subcat

inpac_soa ()

class inpac_soa_lines (osv.osv):
    def _compute_patient_charge(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = line.price_subtotal - line.phic_amt - line.hmo_amt
            res[line.id] = val
        return res

    _name = "hospbill.inpac_soa_lines"
    _description = "In-patient Statement of Account Details"
    _columns = {
        'name' : fields.many2one ('hospbill.inpac_soa', 'SOA', readonly=True, ondelete='restrict'),
        'invoice_line_id' : fields.many2one ('account.invoice.line', 'Invoice Line', readonly=True, ondelete='restrict'),
        'partner_id': fields.related ('invoice_line_id','invoice_id','partner_id',type="integer",string="Partner ID",store=False, readonly=True),
        'invoice_number': fields.related ('invoice_line_id','invoice_id','number',type="char",string="Invoice Number",store=False, readonly=True),
        'invoice_date': fields.related ('invoice_line_id','invoice_id','date_invoice',type="date",string="Date",store=False, readonly=True),
        'invoice_state': fields.related ('invoice_line_id','invoice_id','state',type="char",string="Invoice State",store=False, readonly=True),
        'quantity': fields.related ('invoice_line_id','quantity',type="float",string="QTY",store=False, readonly=True),
        'price_unit': fields.related ('invoice_line_id','price_unit',type="float",string="Unit Cost",store=False, readonly=True),
        'discount': fields.related ('invoice_line_id','discount',type="float",string="Discount(%)",store=False, readonly=True),
        'price_subtotal': fields.related ('invoice_line_id','price_subtotal',type="float",string="Sub-Total",store=False, readonly=True),
        'phic_covered': fields.related ('invoice_line_id','phic_covered',type="boolean",string="PHIC Covered",store=False),
        'hmo_covered': fields.related ('invoice_line_id','hmo_covered',type="boolean",string="HMO Covered",store=False),
        'apply_disc': fields.boolean (string="Apply Discount?"),
        'phic_amt': fields.float ('PHIC Charge', readonly=True),
        'hmo_amt': fields.float ('HMO Charge', readonly=True),
        'patient_amt': fields.function(_compute_patient_charge, method=True, type="float", string='Patient Charge', readonly=True),
        'category': fields.selection([
            ('none','None'),
            ('01-room-board','Room and Board'),
            ('02-drugs-meds','Drugs and Medicines'),
            ('03-xray-lab-supp-oth','X-Ray, Lab, Supplies, and Others'),
            ('04-operating-room','Operating Room Fee'),
            ('05-pf-visit-gp','PF-Daily Visits(Gen. Practitioner)'),
            ('06-pf-visit-sp','PF-Daily Visits(Specialist)'),
            ('07-pf-surgery','PF-Surgeon'),
            ('08-pf-anesthesiology','PF-Anesthesiologist'),
            ],'Category'),
        'sub_category': fields.selection([
            ('none',''),
            ('01-radiology','Radiology'),
            ('02-laboratory','Laboratory'),
            ('03-supplies','Supplies'),
            ('04-others','Others'),
            ],'Sub-Category'),
        'phic_rvs_code': fields.related ('invoice_line_id','product_id','default_code',type="char",size=64,string="RVS Code",store=False, readonly=True),
        'phic_rvu': fields.related ('invoice_line_id','product_id','phic_rvu',type="integer",string="PHIC RVU",store=False, readonly=True),
        'surgeon_id' : fields.many2one ('medical.physician', 'Surgeon', ondelete='restrict', domain=[('surgeon_class','!=',None)]),
        'anesthesiologist_id' : fields.many2one ('medical.physician', 'Anesthesiologist', ondelete='restrict'),        
        'dv_physician_id' : fields.many2one ('medical.physician', 'Physician', ondelete='restrict', domain=[('surgeon_class','!=',None)]),
    }

    _sql_constraints = [
        ('invoice_line_id_unique', 'unique (invoice_line_id)', 'The Invoice Line should be unique.')
    ]

    _defaults = {
        'category': 'none',
        'sub_category': 'none',
    }
    
    _order = "category, sub_category, id"

inpac_soa_lines ()
