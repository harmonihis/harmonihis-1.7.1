# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


import time
from mx import DateTime
import datetime
from osv import fields, osv
from tools.translate import _

#DEBUG MODE -- DELETE ME !
# import pdb

class phic_rvs_system (osv.osv):
    _name = "hospbill.phic_rvs_system"
    _description = "PHIC Relative Value Scale System"
    _columns = {
        'name' : fields.char ('System',size=50), 
    }
       
phic_rvs_system ()

class phic_rvs (osv.osv):
    def name_get(self, cr, uid, ids, context=None):
        result= []
        if not all(ids):
            return result
        for row in self.browse(cr, uid, ids, context=context):
            name = '[' + str(row.code) + '] '+ str(row.name) + ' (RVU: ' + str(row.rvu) + ')'
            result.append((row.id,name))
        return result

    _name = "hospbill.phic_rvs"
    _description = "PHIC Relative Value Scale"
    _columns = {
        'system' : fields.many2one ('hospbill.phic_rvs_system', 'System'),
        'code' : fields.char ('Code', size=10),
        'name' : fields.char ('Descriptive Terms',size=250), 
        'rvu' : fields.integer ('RVU'),
    }
    
    _order = "code"
    
phic_rvs ()


