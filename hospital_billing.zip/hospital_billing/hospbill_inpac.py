# coding=utf-8

#    Copyright (C) 2011  Edwin Gonzales

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.


import time
#from mx import DateTime
#from dateutil.relativedelta import relativedelta
from datetime import datetime
import netsvc
from osv import fields, osv
import tools
from tools.translate import _
from tools import DEFAULT_SERVER_DATE_FORMAT
import decimal_precision as dp

#DEBUG MODE -- DELETE ME !
# import pdb

class account_invoice_line_mods(osv.osv):
    _name = "account.invoice.line"
    _inherit = "account.invoice.line"
    _columns = {
        'phic_covered' : fields.boolean('Philhealth Covered'),
        'hmo_covered' : fields.boolean('HMO Covered'),
    }

account_invoice_line_mods()

class medical_physician_mods(osv.osv):
    _name = "hr.employee"
    _inherit = "hr.employee"
    _columns = {
        'surgeon_class' : fields.many2one ('hospbill.phic_surgery','Surgeon Classification'),
        'phic_accred_no' : fields.char('PHIC Number', size=30),
    }

medical_physician_mods()

class inpac_soa (osv.osv):
    _name = "hospbill.inpac_soa"
    _description = "In-patient Statement of Account"
    _columns = {
        'name' : fields.char ('Bill Number',required=True,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}, size=20),
        'date_processed': fields.date('Date Processed', select=True, readonly=True),
        'patient_case_id' : fields.many2one ('his.admission', 'Patient Admission', required=True, states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'diagnosis': fields.related ('patient_case_id','final_diag_icd','name',type="char", size="256",string="Diagnosis",store=False, readonly=True),
        'phic_casetype': fields.related ('patient_case_id','final_diag_icd','casetype_id','name',type="char", size="8",string="PHIC Case Type",store=False, readonly=True),
        'phic_package': fields.related ('patient_case_id','final_diag_icd','package_id','name',type="char", size="50",string="PHIC Package",store=False, readonly=True),
        'icd': fields.related ('patient_case_id','final_diag_icd','code',type="char", size="64",string="ICD Code",store=False, readonly=True),
        'pricelist_id' : fields.many2one ('product.pricelist', 'Price List', required=True,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'inpac_soa_invoices' : fields.one2many ('hospbill.inpac_soa_lines', 'name', 'In-Patient SOA Invoice Lines' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'inpac_pf_invoices' : fields.one2many ('hospbill.pf_invoice', 'name', 'In-Patient OR & PF Lines' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'inpac_rmbd_invoices' : fields.one2many ('hospbill.roomboard_invoice', 'name', 'In-Patient Room and Board Lines' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'note': fields.text('Note' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),

        'phic_charge': fields.boolean('Claiming PHIC?' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'hmo_charge': fields.boolean('Claiming HMO?' ,states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),

        'phic_member_type': fields.related ('patient_case_id','name','phic', type="char", size="15",string="Membership Type",store=False, readonly=True),
        'phic_id': fields.related ('patient_case_id','name','phic_no', type="char", size="20",string="PHIC ID",store=False, readonly=True),
        'phic_member_id': fields.related ('patient_case_id','name','phic_sponsor_name','phic_no', type="char", size=20, string="PHIC Sponsor ID",store=False, readonly=True),
        'phic_member': fields.related ('patient_case_id','name','phic_sponsor_name','whole_name', type="char", size=256, string="PHIC Sponsor Name",store=False, readonly=True),

        #'phic_member_id' : fields.many2one ('medical.insurance', 'PHIC Member ID', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        #'phic_member': fields.related ('phic_member_id','name','name',type="char", size="256",string="PHIC Member Name",store=False, readonly=True),

        'hmo_member_type': fields.related ('patient_case_id','name','hmo',type="char", size="15",string="Membership Type",store=False, readonly=True),
        'hmo_id': fields.related ('patient_case_id','name','hmo_no', type="char", size="20",string="HMO ID",store=False, readonly=True),
        'hmo_coy_id': fields.related ('patient_case_id','name','hmo_id','id', type="integer", string="HMO Company ID",store=False, readonly=True),
        'hmo_coy_name': fields.related ('patient_case_id','name','hmo_id','whole_name', type="char", size=100, string="HMO Company Name",store=False, readonly=True),
        'hmo_member_coy_name': fields.related ('patient_case_id','name','hmo_principal','hmo_id','whole_name', type="char", size=100, string="HMO Company Name (Sponsor)",store=False, readonly=True),
        'hmo_member_id': fields.related ('patient_case_id','name','hmo_principal','hmo_no', type="char", size=20 ,string="HMO ID (Sponsor)",store=False, readonly=True),
        'hmo_member': fields.related ('patient_case_id','name','hmo_principal','whole_name', type="char", size=256, string="HMO Sponsor Name",store=False, readonly=True),

        #'hmo_member_id' : fields.many2one ('medical.insurance', 'HMO Member ID', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        #'hmo_member': fields.related ('hmo_member_id','name','name',type="char", size="256",string="HMO Member Name",store=False, readonly=True),
        'disc_id' : fields.many2one ('his.discounts', 'Discount', states={'process':[('readonly',True)], 'cancel':[('readonly',True)]}),
        'opd': fields.boolean('Out Patient'),
        'state': fields.selection([
            ('draft','Draft'),
            ('process','Processed'),
            ('cancel','Cancelled')
            ],'State', select=True, readonly=True),
    }
    
    _order = "name desc"

    _sql_constraints = [
        ('bill_uniq', 'unique (name)', 'The Bill Number should be unique.'),
        ('patient_case_uniq', 'unique (patient_case_id)', "A SOA is already created for this patient's case")
    ]

    _defaults = {
        'name': lambda obj, cr, uid, context: obj.pool.get('ir.sequence').get(cr, uid, 'hospbill.inpac_soa'),
        'pricelist_id' : 1,
        'state': 'draft',
    }

    def onchange_admission_id(self, cr, uid, ids, patient_case_id, context=None):
        admission_state = self.pool.get('his.admission').browse(cr, uid, patient_case_id).state
        #raise osv.except_osv(('Debug!'), ("Value %s") % (admission_state))
        if admission_state == 'Outpatient':
            result = {'value':{'opd':True}}
        else:
            result = {'value':{'opd':False}}
        return result
        
    def onchange_hmo_charge(self, cr, uid, ids, context=None):
        if context is None:
            context = {}

        soalines_obj = self.pool.get('hospbill.inpac_soa_lines')
        invoicelines_obj = self.pool.get('account.invoice.line')
        
        soa_ids = self.browse(cr, uid, ids) or False
        if soa_ids:
            if soa_ids[0].hmo_charge == False:
                newval = True
            else:
                newval = False
            soa_id = soa_ids[0].id
            soa_line_ids = soalines_obj.search(cr, uid, [('name','=',soa_id)])
            if soa_line_ids:
                soa_lines = soalines_obj.browse(cr, uid, soa_line_ids)
                for soa_line in soa_lines:
                    invoicelines_obj.write(cr, uid, soa_line.invoice_line_id.id, {'hmo_covered': newval})
                    #soalines_obj.write(cr, uid, soa_line.id, {'hmo_covered': newval})
        return True
    
    def button_phic_compute(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        soa_rec = self.browse(cr, uid, ids)[0]
        soa_lines_rec = self.pool.get('hospbill.inpac_soa_lines')
        operating_room_ref_obj = self.pool.get('hospbill.phic_operatingroom_amt')
        if soa_rec.phic_charge:
            diagnosis_id = soa_rec.patient_case_id.final_diag_icd
            if diagnosis_id:
                #PHIC Specific vars
                casetype_id = soa_rec.patient_case_id.final_diag_icd.casetype_id.id
                package_id = soa_rec.patient_case_id.final_diag_icd.package_id.id
                #Room and Board vars
                roomboard_amt = soa_rec.patient_case_id.final_diag_icd.casetype_id.roomboard
                roomboard_maxdays = soa_rec.patient_case_id.final_diag_icd.casetype_id.roomboard_maxdays
                #Drugs and Medicines
                drugsmeds_maxamt = soa_rec.patient_case_id.final_diag_icd.casetype_id.drugmed
                #X-Ray, Lab, and Others vars
                xraylaboth_maxamt = soa_rec.patient_case_id.final_diag_icd.casetype_id.xraylabsupp
                #Professional Fee (Daily Visits) vars
                pfgpperday = soa_rec.patient_case_id.final_diag_icd.casetype_id.pfgpperday
                pfgpmax = soa_rec.patient_case_id.final_diag_icd.casetype_id.pfgpmax
                pfspperday = soa_rec.patient_case_id.final_diag_icd.casetype_id.pfspperday
                pfspmax = soa_rec.patient_case_id.final_diag_icd.casetype_id.pfspmax
                #Invoice Line
                inv_lines_rec = soa_rec.inpac_soa_invoices
                if package_id and package_id != 0: #Process PHIC Package
                    #Start processing the invoice lines
                    inv_line_ctr = 0
                    for inv_line in inv_lines_rec:
                        inv_line_ctr += 1
                        #Check if invoice line is set for PHIC
                        if inv_line.phic_covered:
                            inv_id = inv_line.invoice_line_id
                            amt = (inv_line.price_unit * inv_line.quantity) - inv_line.discval
                        else:
                            amt = 0
                            
                        #Update SOA Lines
                        try:
                            soa_lines_rec.write(cr, uid, [inv_line.id], {'phic_amt' : amt})
                        except:
                            raise osv.except_osv(('Error!'), ("Cannot update SOA lines (Value: " + str(inv_line.price_subtotal) + ")" ))

                elif casetype_id: #Process PHIC Case Type
                    #Get the RVUs
                    pf_surgery_rvus = {}
                    pf_surgeries = {}
                    pf_anesthesiologists = {}
                    pf_surgery_ids = {}
                    pf_anesthesiology_ids = {}
                    or_ids = {}
                    for inv_line_rvu in inv_lines_rec:
                        #raise osv.except_osv(('Debug!'), ("Values: " + inv_line_rvu.invoice_id))
                        inv_id = inv_line_rvu.invoice_line_id
                        rvu = inv_line_rvu.phic_rvu
                        if inv_line_rvu.phic_covered and inv_line_rvu.category == '07-pf-surgery':
                            pf_surgery_rvus[inv_id] = rvu
                            pf_surgery_ids[inv_id] =  inv_line_rvu.id
                            if inv_line_rvu.surgeon_id:
                                if rvu >= inv_line_rvu.surgeon_id.surgeon_class.range1_rvu_min and rvu <= inv_line_rvu.surgeon_id.surgeon_class.range1_rvu_max:
                                    pfsurgery_pcf = inv_line_rvu.surgeon_id.surgeon_class.surgeon_pcf
                                    pfsurgery_max_amt = inv_line_rvu.surgeon_id.surgeon_class.surgeon_max
                                else:
                                    pfsurgery_pcf = inv_line_rvu.surgeon_id.surgeon_class.surgeon_pcf2
                                    pfsurgery_max_amt = inv_line_rvu.surgeon_id.surgeon_class.surgeon_max2
                                    
                                computed_amt = int(rvu) * int(pfsurgery_pcf)
                                if pfsurgery_max_amt > 0 and computed_amt > pfsurgery_max_amt:
                                    pf_surgeries[inv_id] = pfsurgery_max_amt
                                else:
                                    pf_surgeries[inv_id] = computed_amt
                            else:
                                pf_surgeries[inv_id] = 0
                                
                        elif inv_line_rvu.phic_covered and inv_line_rvu.category == '08-pf-anesthesiology':
                            pf_anesthesiology_ids[inv_id] = inv_line_rvu.id
                            #pf_anesthesiology_rvus[inv_id] = rvu

                            if inv_line_rvu.anesthesiologist_id:
                                if rvu >= inv_line_rvu.anesthesiologist_id.surgeon_class.range1_rvu_min and rvu <= inv_line_rvu.anesthesiologist_id.surgeon_class.range1_rvu_max:
                                    pfanesthe_pct = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_pct
                                    pfanesthe_max_amt = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_max
                                    pfanesthe_ref = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref
                                else:
                                    pfanesthe_pct = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_pct2
                                    pfanesthe_max_amt = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_max2
                                    pfanesthe_ref = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref2
                                if pfanesthe_ref == 1:
                                    pfanesthe_pcf = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref.surgeon_pcf
                                    pfanesthe_surgeon_max_amt = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref.surgeon_max
                                else:
                                    pfanesthe_pcf = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref.surgeon_pcf2
                                    pfanesthe_surgeon_max_amt = inv_line_rvu.anesthesiologist_id.surgeon_class.anesthe_ref.surgeon_max2

                                computed_amt = int(rvu) * int(pfanesthe_pcf)
                                if pfanesthe_surgeon_max_amt > 0 and computed_amt > pfanesthe_surgeon_max_amt:
                                    computed_amt = pfanesthe_surgeon_max_amt * (float(pfanesthe_pct)/100.00)
                                else:
                                    computed_amt = computed_amt * (float(pfanesthe_pct)/100.00)
                                
                                if pfanesthe_max_amt > 0 and computed_amt > pfanesthe_max_amt:
                                    pf_anesthesiologists[inv_id] = pfanesthe_max_amt
                                else:
                                    pf_anesthesiologists[inv_id] = computed_amt
                            else:
                                pf_anesthesiologists[inv_id] = 0

                        elif inv_line_rvu.phic_covered and inv_line_rvu.category == '04-operating-room':
                            or_ids[inv_id] = inv_line_rvu.id
                                                
                    #Start processing the invoice lines
                    inv_line_ctr = 0
                    inv_line_nomatch = 0
                    roomboard_ctr = 0
                    roomboard_sw = 0
                    drugsmeds_amtctr = 0
                    xraylaboth_amtctr = 0
                    pfgpamt_ctr = 0
                    pfgp_sw = 0
                    pfspamt_ctr = 0
                    pfsp_sw = 0
                    for inv_line in inv_lines_rec:
                        #Operating Room variables
                        or_pcf = 0
                        or_min_amt = 0
                        or_max_amt = 0

                        inv_line_ctr += 1
                        #Check if invoice line is set for PHIC
                        if inv_line.phic_covered:
                            inv_id = inv_line.invoice_line_id
                            #Check if invoice line is Room and Board
                            if inv_line.category == '01-room-board':
                                roomboard_ctr += inv_line.quantity
                                if roomboard_ctr <= roomboard_maxdays:
                                    if inv_line.price_unit > roomboard_amt:
                                        amt = roomboard_amt * inv_line.quantity
                                    else:
                                        #amt = inv_line.price_subtotal
                                        amt = inv_line.price_unit * inv_line.quantity
                                else:
                                    if roomboard_sw == 0:
                                        roomboard_sw = 1
                                        excessdays = roomboard_ctr - roomboard_maxdays
                                        if inv_line.price_unit > roomboard_amt:
                                            amt = roomboard_amt * (inv_line.quantity - excessdays)
                                        else:
                                            amt = inv_line.price_unit * (inv_line.quantity - excessdays)
                                    else:
                                        amt = 0
                                
                                #Check if invoice line is Drugs and Medicines
                            elif inv_line.category == '02-drugs-meds':
                                #Todo: Check if total drugs and meds exceeds limit based on case type
                                if inv_line.invoice_type == 'out_refund':
                                    drugsmeds_amtctr -= ((inv_line.price_unit * inv_line.quantity) + inv_line.discval)
                                    #if drugsmeds_amtctr <= drugsmeds_maxamt:
                                    amt = (inv_line.price_unit * inv_line.quantity) + inv_line.discval
                                    amt = amt * -1
                                    #else:
                                    #    if drugsmeds_amtctr == drugsmeds_maxamt:
                                    #        amt = 0
                                    #    else:
                                    #        drugsmeds_amtctr -= ((inv_line.price_unit * inv_line.quantity) - inv_line.discval)
                                    #        amt = drugsmeds_maxamt + drugsmeds_amtctr
                                    #        drugsmeds_amtctr = drugsmeds_maxamt                                    
                                else:
                                    drugsmeds_amtctr += ((inv_line.price_unit * inv_line.quantity) - inv_line.discval)
                                    if drugsmeds_amtctr <= drugsmeds_maxamt:
                                        amt = (inv_line.price_unit * inv_line.quantity) - inv_line.discval
                                    else:
                                        if drugsmeds_amtctr == drugsmeds_maxamt:
                                            amt = 0
                                        else:
                                            drugsmeds_amtctr -= ((inv_line.price_unit * inv_line.quantity) - inv_line.discval)
                                            amt = drugsmeds_maxamt - drugsmeds_amtctr
                                            drugsmeds_amtctr = drugsmeds_maxamt
                                    
                            #Check if invoice line is X-Ray, Lab, Supplies, and Others
                            elif inv_line.category == '03-xray-lab-supp-oth':
                                #xraylaboth_amtctr += inv_line.price_subtotal
                                xraylaboth_amtctr += ((inv_line.price_unit * inv_line.quantity) - inv_line.discval)
                                if xraylaboth_amtctr <= xraylaboth_maxamt:
                                    #amt = inv_line.price_subtotal
                                    amt = (inv_line.price_unit * inv_line.quantity) - inv_line.discval
                                else:
                                    if xraylaboth_amtctr == xraylaboth_maxamt:
                                        amt = 0
                                    else:
                                        xraylaboth_amtctr -= ((inv_line.price_unit * inv_line.quantity) - inv_line.discval)
                                        amt = xraylaboth_maxamt - xraylaboth_amtctr
                                        xraylaboth_amtctr = xraylaboth_maxamt
                                
                            #Check if invoice line is Operating Room Charges
                            elif inv_line.category == '04-operating-room':
                                if inv_id in pf_surgery_rvus: # and not (pf_surgery_rvus[inv_id] is None):
                                    #raise osv.except_osv(('Debug!'), ("Values: " + str(inv_id) + " " + str(pf_surgery_rvus [inv_id]) + " " ))
                                    if inv_line.id == or_ids [inv_id]:
                                        rvu = pf_surgery_rvus [inv_id]
                                        operating_room_ids = operating_room_ref_obj.search(cr,uid, [
                                                            ('rvu_min','<=',rvu),
                                                            ('rvu_max','>=',rvu)])
                                        if operating_room_ids:
                                            or_ref_data = {}
                                            or_ref_data = operating_room_ref_obj.browse(cr, uid, operating_room_ids, context=context)
                                            or_ref = or_ref_data[0]
                                            or_pcf = or_ref.pcf
                                            or_min_amt = or_ref.min_amt
                                            or_max_amt = or_ref.max_amt
                                        if or_min_amt == or_max_amt:
                                            amt = or_max_amt
                                        else:
                                            rvu_pcf_val = int(rvu) * int(or_pcf)
                                            if rvu_pcf_val <= or_min_amt:
                                                amt = or_min_amt
                                            elif rvu_pcf_val >= or_max_amt:
                                                amt = or_max_amt
                                            else:
                                                amt = rvu_pcf_val
                                    else: #No Surgery Procedure found so we charge to patient
                                        amt = 0
                                else: #No Surgery procedure included in the PHIC claim
                                    amt = 0

                            #Check if invoice line is PF Gen. Practitioner (Daily Visit)
                            elif inv_line.category == '05-pf-visit-gp':
                                if inv_line.price_unit > pfgpperday:
                                    pfgpamt = pfgpperday * inv_line.quantity
                                else:
                                    #pfgpamt = inv_line.price_subtotal
                                    pfgpamt = inv_line.price_unit * inv_line.quantity

                                pfgpamt_ctr += pfgpamt
                                if pfgpamt_ctr <= pfgpmax:
                                    amt = pfgpamt
                                else:
                                    if pfgp_sw == 0:
                                        pfgp_sw = 1
                                        excesspfgp = pfgpamt_ctr - pfgpamt
                                        amt = pfgpmax - excesspfgp
                                    else:
                                        amt = 0

                            #Check if invoice line is PF Specialist (Daily Visit)
                            elif inv_line.category == '06-pf-visit-sp':
                                if inv_line.price_unit > pfspperday:
                                    pfspamt = pfspperday * inv_line.quantity
                                else:
                                    #pfspamt = inv_line.price_subtotal
                                    pfspamt = inv_line.price_unit * inv_line.quantity


                                pfspamt_ctr += pfspamt
                                if pfspamt_ctr <= pfspmax:
                                    amt = pfspamt
                                else:
                                    if pfsp_sw == 0:
                                        pfsp_sw = 1
                                        excesspfsp = pfspamt_ctr - pfspamt
                                        amt = pfspmax - excesspfsp
                                    else:
                                        amt = 0

                            #Check if invoice line is Surgery Prof. Fee
                            elif inv_line.category == '07-pf-surgery':
                                if inv_id in pf_surgeries:
                                    if inv_line.id == pf_surgery_ids [inv_id]:
                                        amt = pf_surgeries[inv_id]
                                    else: #No Surgeon PF found so we charge to patient
                                        amt = 0
                                else:
                                    amt = 0

                            #Check if invoice line is Ansthesiology Prof. Fee
                            elif inv_line.category == '08-pf-anesthesiology':
                                if inv_id in pf_anesthesiologists:
                                    if inv_line.id == pf_anesthesiology_ids [inv_id]:
                                        amt = pf_anesthesiologists[inv_id]
                                        #if inv_line.anesthesiologist_id:
                                        #    pfanesthe_pct = inv_line.anesthesiologist_id.surgeon_class.anesthe_pct
                                        #    pfanesthe_max_amt = inv_line.anesthesiologist_id.surgeon_class.anesthe_max
                                        #    computed_amt = pf_surgeries[inv_id] * (float(pfanesthe_pct)/100.00)
                                        #    if pfanesthe_max_amt > 0 and computed_amt > pfanesthe_max_amt:
                                        #        amt = pfanesthe_max_amt
                                        #    else:
                                        #        amt = computed_amt
                                        #else:
                                        #    amt = 0
                                    else: #No Surgeon PF found so we charge to patient
                                        amt = 0
                                else: 
                                    amt = 0

                            else:
                                inv_line_nomatch += 1
                                amt = 0
                        else:
                            inv_line_nomatch += 1
                            amt =0

                        #Check if the sub total is less than the computed PHIC Charge
                        #if inv_line.price_subtotal < amt:
                        if (inv_line.price_unit * inv_line.quantity) < amt:
                            amt = inv_line.price_unit * inv_line.quantity
                            
                        #Update SOA Lines
                        try:
                            soa_lines_rec.write(cr, uid, [inv_line.id], {'phic_amt' : amt})
                        except:
                            raise osv.except_osv(('Error!'), ("Cannot update SOA lines (Value: " + str(inv_line.price_subtotal) + ")" ))

                    #No record processed for PHIC charge        
                    if inv_line_ctr == inv_line_nomatch:
                        raise osv.except_osv(('Error !'), ("No invoice line was processed for PHIC claim. " + str(inv_line_ctr) + " invoice lines evaluated."))
                else:
                    raise osv.except_osv(('Error !'), ("Patient's diagnosis is not yet classified based on the PHIC case type or package."))
            else:
                raise osv.except_osv(('Error !'), ("No diagnosis was encoded for this patient's case."))
        else:
            raise osv.except_osv(('Error !'), ("Patient's case is not charged to PHIC."))
        return True

    def get_bill_cat(self, cr, uid, product_id, product_cat_id, context=None):
        cat = 'none'
        subcat= 'none'
        if not product_id or not product_cat_id:
            return False
        #Check if product/service is Room and Board
        roomboard_cat_obj = self.pool.get('hospbill.phic_roomboard_cat')
        roomboard_cat_ids = roomboard_cat_obj.search(cr,uid, [
                        ('categ_id','=',product_cat_id)])
        if roomboard_cat_ids:
            cat = '01-room-board'
            subcat = 'none'
        else:
            #Check if product/service is Drugs and Medicines
            drugsmeds_cat_obj = self.pool.get('hospbill.phic_drugsmeds_cat')
            drugsmeds_cat_ids = drugsmeds_cat_obj.search(cr,uid, [
                            ('categ_id','=',product_cat_id)])
            if drugsmeds_cat_ids:
                cat = '02-drugs-meds'
                subcat = 'none'
            else:
                #Check if product/service is X-Ray, Lab, Supplies, and Others
                xraylabsupp_cat_obj = self.pool.get('hospbill.phic_xraylabsupp_cat')
                xraylabsupp_cat_ids = xraylabsupp_cat_obj.search(cr,uid, [
                                ('categ_id','=',product_cat_id)])
                if xraylabsupp_cat_ids:
                    cat = '03-xray-lab-supp-oth'
                    xraylabsupp_data = xraylabsupp_cat_obj.browse(cr, uid, xraylabsupp_cat_ids, context=None)
                    xraylabsupp = xraylabsupp_data[0]
                    if xraylabsupp.sub_categ == 'r':
                        subcat = '01-radiology'
                    elif xraylabsupp.sub_categ == 'l':
                        subcat = '02-laboratory'
                    elif xraylabsupp.sub_categ == 's':
                        subcat = '03-supplies'
                    elif xraylabsupp.sub_categ == 'o':
                        subcat = '04-others'
                    else:
                        subcat = 'none'
                else:
                    #Check if product/service is Operating Room Charges
                    operatingroom_cat_obj = self.pool.get('hospbill.phic_operatingroom_cat')
                    operatingroom_cat_ids = operatingroom_cat_obj.search(cr,uid, [
                                    ('categ_id','=',product_cat_id)])
                    if operatingroom_cat_ids:
                        cat = '04-operating-room'
                        subcat = 'none'
                    else:
                        #Check if product/service is PF Gen. Practitioner (Daily Visit)
                        pfgp_cat_obj = self.pool.get('hospbill.phic_pfgp_cat')
                        pfgp_cat_ids = pfgp_cat_obj.search(cr,uid, [
                                        ('categ_id','=',product_cat_id)])
                        if pfgp_cat_ids:
                            cat = '05-pf-visit-gp'
                            subcat = 'none'
                        else:
                            #Check if product/service is PF Specialist (Daily Visit)
                            pfsp_cat_obj = self.pool.get('hospbill.phic_pfsp_cat')
                            pfsp_cat_ids = pfsp_cat_obj.search(cr,uid, [
                                            ('categ_id','=',product_cat_id)])
                            if pfsp_cat_ids:
                                cat = '06-pf-visit-sp'
                                subcat = 'none'
                            else:
                                #Check if product/service is Surgery Prof. Fee
                                surgery_cat_obj = self.pool.get('hospbill.phic_surgery_cat')
                                surgery_cat_ids = surgery_cat_obj.search(cr,uid, [
                                                ('categ_id','=',product_cat_id)])
                                if surgery_cat_ids:
                                    cat = '07-pf-surgery'
                                    subcat = 'none'
                                else:
                                    #Check if product/service is Anesthesiology Prof. Fee
                                    anesthesiology_cat_obj = self.pool.get('hospbill.phic_anesthesiology_cat')
                                    anesthesiology_cat_ids = anesthesiology_cat_obj.search(cr,uid, [
                                                    ('categ_id','=',product_cat_id)])
                                    if anesthesiology_cat_ids:
                                        cat = '08-pf-anesthesiology'
                                        subcat = 'none'
                                            
        return cat, subcat

    def button_apply_discount_sel(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        wf_service = netsvc.LocalService('workflow')

        discounts_obj = self.pool.get('hospbill.discounts')
        soalines_obj = self.pool.get('hospbill.inpac_soa_lines')
        invoicelines_obj = self.pool.get('account.invoice.line')
        
        soa_ids = self.browse(cr, uid, ids)
        if soa_ids[0]:
            hosp_disc = soa_ids[0].disc_id.pharma_pctg
        else:
            hosp_disc = 0.00
            
        soa_id = soa_ids[0].id
        soa_line_ids = soalines_obj.search(cr, uid, [('name','=',soa_id),('apply_disc','=',True)])
        if not soa_line_ids:
            raise osv.except_osv(('SOA Discount Processing'), ("No invoice lines selected for discount."))
        else:
            soa_lines = soalines_obj.browse(cr, uid, soa_line_ids)
            discount_val = 0
            for soa_line in soa_lines:
                if hosp_disc > 0:
                    #discount_val = ((soa_line.invoice_line_id.price_unit * soa_line.invoice_line_id.quantity) - (soa_line.phic_amt + soa_line.hmo_amt)) * (hosp_disc/100)
                    discount_val = ((soa_line.invoice_line_id.price_unit * soa_line.invoice_line_id.quantity)) * (hosp_disc/100)
                    if soa_line.invoice_type == 'out_refund':
                        discount_val *= -1
                else:
                    discount_val = 0
                invoicelines_obj.write(cr, uid, soa_line.invoice_line_id.id, {'discount': hosp_disc})
                soalines_obj.write(cr, uid, soa_line.id, {'discval': discount_val})
            
                #raise osv.except_osv(('Debug'), ("Value: %s") % soa_line.invoice_line_id.id,)
    
        return True

    def button_apply_discount_all(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        wf_service = netsvc.LocalService('workflow')

        discounts_obj = self.pool.get('hospbill.discounts')
        soalines_obj = self.pool.get('hospbill.inpac_soa_lines')
        invoicelines_obj = self.pool.get('account.invoice.line')
        
        soa_ids = self.browse(cr, uid, ids)
        if soa_ids[0]:
            hosp_disc = soa_ids[0].disc_id.pharma_pctg
        else:
            hosp_disc = 0.00
        
        soa_id = soa_ids[0].id
        soa_line_ids = soalines_obj.search(cr, uid, [('name','=',soa_id)])
        if not soa_line_ids:
            raise osv.except_osv(('SOA Discount Processing'), ("No invoice lines selected for discount."))
        else:
            soa_lines = soalines_obj.browse(cr, uid, soa_line_ids)
            discount_val = 0
            for soa_line in soa_lines:
                if hosp_disc > 0:
                    #discount_val = ((soa_line.invoice_line_id.price_unit * soa_line.invoice_line_id.quantity) - (soa_line.phic_amt + soa_line.hmo_amt)) * (hosp_disc/100)
                    discount_val = ((soa_line.invoice_line_id.price_unit * soa_line.invoice_line_id.quantity)) * (hosp_disc/100)
                    if soa_line.invoice_type == 'out_refund':
                        discount_val *= -1
                else:
                    discount_val = 0
                invoicelines_obj.write(cr, uid, soa_line.invoice_line_id.id, {'discount': hosp_disc, 'apply_disc': True})
                soalines_obj.write(cr, uid, soa_line.id, {'discval': discount_val})
                #raise osv.except_osv(('Debug'), ("Value: %s") % soa_line.invoice_line_id.id,)
    
        return True

    def button_gen_pf_invoices(self, cr, uid, ids, context=None):
        invoice_obj = self.pool.get('account.invoice')
        invoice_line_obj = self.pool.get('account.invoice.line')
        journal_obj = self.pool.get('hospbill.journal_ref')
        or_pf_obj = self.pool.get('hospbill.pf_invoice')
        inpac_soa_lines_obj = self.pool.get('hospbill.inpac_soa_lines')

        partner_obj = self.pool.get('res.partner')
        product_obj = self.pool.get('product.product')
        
        #Get the Prof. Fee journal_ref IDs
        prof_journalref_id = journal_obj.search(cr, uid,[('transtype','=','prfee')])
        if not prof_journalref_id:
            raise osv.except_osv(_("Invoice Processing"), _("Error! The required journal was not defined for Professional Fee type of transaction."))
        #Get the Prof. Fee Journal ID
        journal = journal_obj.browse(cr, uid, prof_journalref_id[0])
        prof_journal_id = journal.journal.id

        #Iterate through the Records encoded in the O.R./D.R. and Prof. Fee Charge Form
        soa = self.browse(cr, uid, ids, context=context)[0]
        partner_id = soa.patient_case_id.name.id
        #res = partner_obj.address_get(cr, uid, [partner_id], ['contact', 'invoice'])
        #address_contact_id = res['contact']
        #address_invoice_id = res['invoice']
        fiscal_position = soa.patient_case_id.name.property_account_position and soa.patient_case_id.name.property_account_position.id or False
        payment_term = soa.patient_case_id.name.property_payment_term and soa.patient_case_id.name.property_payment_term.id or False
        account_id = soa.patient_case_id.name.property_account_receivable and soa.patient_case_id.name.property_account_receivable.id or False
        origin = "In-Patient Case #: " + soa.patient_case_id.admission_no
        soa_id = soa.id
        #raise osv.except_osv(("Debug"),("Values: %s: %s: %s") % (fiscal_position, payment_term, account_id))

        invoice_data = {}
        invoice_data['partner_id'] = partner_id
        #invoice_data['address_contact_id'] = address_contact_id
        #invoice_data['address_invoice_id'] = address_invoice_id
        invoice_data['account_id'] = account_id
        invoice_data['fiscal_position'] = fiscal_position
        invoice_data['payment_term'] = payment_term
        invoice_data['origin'] = origin
        invoice_data['journal_id'] = prof_journal_id
        
        total_charges = 0
        for charge in soa.inpac_pf_invoices:
            #raise osv.except_osv(("Debug"),("Values: %s") % (charge.orfee_product_id.name))
            if not charge.invoice_id.id:
                total_charges += 1
                invoice_line_count = 0
                prods_data = {}

                #Create the invoice for the Professional Fee: Daily Visits
                if charge.daily_product_id:
                    invoice_line_count += 1
                    #Add the professional Fee (Daily Visits) info to the products array for posting to the customer invoice
                    dvphfee = product_obj.browse(cr, uid, charge.daily_product_id.id)
                    acct_id = dvphfee.product_tmpl_id.property_account_income.id
                    if not acct_id:
                        acct_id = dvphfee.categ_id.property_account_income_categ.id
                        if not acct_id:
                            raise osv.except_osv(_('Error !'),
                                _('There is no income account defined for this product: "%s" (id:%d)') % \
                                    (dvphfee.name, dvphfee.id,))

                    bill_cat, bill_sub_cat = self.get_bill_cat(cr, uid, dvphfee.id, dvphfee.categ_id.id)
                    discval = charge.daily_discount
                    phic_rvs_code = False
                    phic_rvu = False
                    dv_physician_id = charge.dv_physician_id.id
                    prods_data[dvphfee.id] = {'product_id':dvphfee.id,
                        'sequence': invoice_line_count,
                        'name':dvphfee.name,
                        'quantity':charge.daily_quantity,
                        'account_id':acct_id,
                        'price_unit':charge.daily_price_unit,
                        'category': bill_cat, 
                        'sub_category': bill_sub_cat, 
                        'discval': discval,
                        'phic_rvs_code': phic_rvs_code,
                        'phic_rvu': phic_rvu,
                        'surgeon_id': False,
                        'anesthesiologist_id': False,
                        'dv_physician_id': dv_physician_id,
                        'discount': 0,
                        'apply_disc': False}

                #Gather the invoice information 
                invoice_data['date_invoice'] = charge.inv_date
                if charge.orfee_product_id:
                    invoice_line_count += 1
                    #Add the OR/DR Fee info to the products array for posting to the customer invoice
                    ordrfee = product_obj.browse(cr, uid, charge.orfee_product_id.id)
                    acct_id = ordrfee.product_tmpl_id.property_account_income.id
                    if not acct_id:
                        acct_id = ordrfee.categ_id.property_account_income_categ.id
                        if not acct_id:
                            raise osv.except_osv(_('Error !'),
                                _('There is no income account defined for this product: "%s" (id:%d)') % \
                                    (ordrfee.name, ordrfee.id,))

                    bill_cat, bill_sub_cat = self.get_bill_cat(cr, uid, ordrfee.id, ordrfee.categ_id.id)
                    if charge.orfee_discount > 0:
                        discval = (charge.orfee_price_unit * charge.orfee_quantity) * (charge.orfee_discount/100)
                        apply_disc = True
                    else:
                        discval = 0
                        apply_disc = False
                    phic_rvs_code = charge.pf_procedure.code
                    phic_rvu = charge.pf_procedure.rvu
                    prods_data[ordrfee.id] = {'product_id':ordrfee.id,
                        'sequence': invoice_line_count,
                        'name':ordrfee.name,
                        'quantity':charge.orfee_quantity,
                        'account_id':acct_id,
                        'price_unit':charge.orfee_price_unit,
                        'category': bill_cat, 
                        'sub_category': bill_sub_cat, 
                        'discval': discval,
                        'phic_rvs_code': phic_rvs_code,
                        'phic_rvu': phic_rvu,
                        'surgeon_id': False,
                        'anesthesiologist_id': False,
                        'dv_physician_id': False,
                        'discount': charge.orfee_discount,
                        'apply_disc': apply_disc}

                #Create the invoice for the Professional Fee
                if charge.surgery_product_id:
                    invoice_line_count += 1
                    #Add the professional Fee (Surgery) info to the products array for posting to the customer invoice
                    proffee = product_obj.browse(cr, uid, charge.surgery_product_id.id)
                    acct_id = proffee.product_tmpl_id.property_account_income.id
                    if not acct_id:
                        acct_id = proffee.categ_id.property_account_income_categ.id
                        if not acct_id:
                            raise osv.except_osv(_('Error !'),
                                _('There is no income account defined for this product: "%s" (id:%d)') % \
                                    (proffee.name, proffee.id,))

                    bill_cat, bill_sub_cat = self.get_bill_cat(cr, uid, proffee.id, proffee.categ_id.id)
                    discval = charge.surgery_discount
                    phic_rvs_code = charge.pf_procedure.code
                    phic_rvu = charge.pf_procedure.rvu
                    surgeon_id = charge.surgeon_id.id
                    prods_data[proffee.id] = {'product_id':proffee.id,
                        'sequence': invoice_line_count,
                        'name':proffee.name,
                        'quantity':charge.surgery_quantity,
                        'account_id':acct_id,
                        'price_unit':charge.surgery_price_unit,
                        'category': bill_cat, 
                        'sub_category': bill_sub_cat, 
                        'discval': discval,
                        'phic_rvs_code': phic_rvs_code,
                        'phic_rvu': phic_rvu,
                        'surgeon_id': surgeon_id,
                        'anesthesiologist_id': False,
                        'dv_physician_id': False,
                        'discount': 0,
                        'apply_disc': False}

                if charge.anesthe_product_id:
                    invoice_line_count += 1
                    #Build the professional Fee (Anesthesiology) products array for posting to the customer invoice
                    proffee = product_obj.browse(cr, uid, charge.anesthe_product_id.id)
                    acct_id = proffee.product_tmpl_id.property_account_income.id
                    if not acct_id:
                        acct_id = proffee.categ_id.property_account_income_categ.id
                        if not acct_id:
                            raise osv.except_osv(_('Error !'),
                                _('There is no income account defined for this product: "%s" (id:%d)') % \
                                    (proffee.name, proffee.id,))
                                
                    bill_cat, bill_sub_cat = self.get_bill_cat(cr, uid, proffee.id, proffee.categ_id.id)
                    discval = charge.anesthe_discount
                    phic_rvs_code = charge.pf_procedure.code
                    phic_rvu = charge.pf_procedure.rvu
                    anesthesiologist_id = charge.anesthesiologist_id.id
                    prods_data[proffee.id] = {'product_id':proffee.id,
                        'sequence': invoice_line_count,
                        'name':proffee.name,
                        'quantity':charge.anesthe_quantity,
                        'account_id':acct_id,
                        'price_unit':charge.anesthe_price_unit,
                        'category': bill_cat, 
                        'sub_category': bill_sub_cat, 
                        'discval': discval,
                        'phic_rvs_code': phic_rvs_code,
                        'phic_rvu': phic_rvu,
                        'surgeon_id': False,
                        'anesthesiologist_id': anesthesiologist_id,
                        'dv_physician_id': False,
                        'discount': 0,
                        'apply_disc': False}

                #Create the Invoice
                if invoice_line_count > 0:
                    #raise osv.except_osv(("Debug"),("Values: %s") % (ordrfee_invoice_data))
                    try:
                        invoice_ids = invoice_obj.create(cr, uid, invoice_data)
                        #Call the Invoice Open Workflow
                        #data_inv = invoice_obj.read(cr, uid, ordrfee_invoice_ids, ['state'], context=context)
                        #if data_inv['state'] not in ('draft','proforma','proforma2'):
                        #raise wizard.except_wizard(_('Warning'), _("Selected Invoice(s) cannot be confirmed as they are not in 'Draft' or 'Pro-Forma' state!") )
                        #else:
                        #wf_service.trg_validate(uid, 'account.invoice', data_inv['id'], 'invoice_open', cr)
                    except: #Exception, e:
                        raise osv.except_osv(("Error!"),("Error creating the O.R./D.R. Fee invoice"))
                    else:
                        try:
                            updated_pf_id = or_pf_obj.write(cr, uid, charge.id, {'invoice_id': invoice_ids}, context=context)
                        except: #Exception, e:
                            raise osv.except_osv(("Error!"),("Cannot update the OR/DR and PF Record"))
                        else:
                            #Save the OR/DR Fee Invoice Lines
                            for prod_id, prod_data in prods_data.items():
                                #Put all invoice data to product_lines 
                                product_lines = {}
                                product_lines = {'invoice_id': invoice_ids, 
                                                'sequence': prod_data['sequence'],
                                                'product_id':prod_data['product_id'],
                                                'name':prod_data['name'],
                                                'quantity':prod_data['quantity'],
                                                'account_id':prod_data['account_id'],
                                                'price_unit':prod_data['price_unit'],
                                                'discount':prod_data['discount']}
                                try:
                                    invoice_line_id = invoice_line_obj.create(cr, uid, product_lines, context=None)
                                except: #Exception, e:
                                    raise osv.except_osv(("Error!"),("Error creating the invoice line(s)"))
                                else:
                                    #Put all SOA data to soa_lines
                                    soa_lines = {}
                                    soa_lines = {'name': soa_id, 
                                                'invoice_line_id': invoice_line_id, 
                                                'category': prod_data['category'], 
                                                'sub_category': prod_data['sub_category'], 
                                                'apply_disc': prod_data['apply_disc'],
                                                'discval': prod_data['discval'],
                                                'phic_rvs_code': prod_data['phic_rvs_code'],
                                                'phic_rvu': prod_data['phic_rvu'],
                                                'surgeon_id': prod_data['surgeon_id'],
                                                'anesthesiologist_id': prod_data['anesthesiologist_id'],
                                                'dv_physician_id': prod_data['dv_physician_id']}

                                    #Add Invoice to the SOA Lines
                                    try:
                                        soa_line_id = inpac_soa_lines_obj.create(cr, uid, soa_lines, context=None)
                                    except: #Exception, e:
                                        raise osv.except_osv(("Error!"),("Error adding the generated invoice(s) to the SOA. Data: %s") % soa_lines)

        if total_charges <= 0:
            raise osv.except_osv(("Error!"),("No action was executed because all charges are already invoiced and added to this SOA."))
            
    def button_gen_rmbd_line(self, cr, uid, ids, context=None):
        roomboard_obj = self.pool.get('hospbill.roomboard_invoice')
        roomtrans_obj = self.pool.get('his.room.transfer')
        #product_obj = self.pool.get('product.product')
        
        soa = self.browse(cr, uid, ids, context=context)[0]
        soa_id = soa.id
        #raise osv.except_osv(("Debug"),("Values: %s: %s: %s") % (fiscal_position, payment_term, account_id))

        #Get room and board entries
        entries = 0
        for roombrd in soa.patient_case_id.room_transfer_id:
            entries += 1
            roomboard_product_id = roombrd.bed_no.name.id
            beg_datetime = roombrd.date_in
            if roombrd.date_out:
                end_datetime = roombrd.date_out
            else:
                end_datetime = time.strftime('%Y-%m-%d %H:%M:%S')
                
            #Get the unit price
            #for prod in product_obj.browse(cr, uid, [roomboard_product_id], context=context):
            price = roombrd.bed_no.name.lst_price
            #Compute the days
            begdatetime = datetime.strptime(beg_datetime,'%Y-%m-%d %H:%M:%S')
            enddatetime = datetime.strptime(end_datetime,'%Y-%m-%d %H:%M:%S')
            timedelta = enddatetime - begdatetime
            days = float(timedelta.days)
            hours = float(timedelta.seconds / 3600.00)
            if hours > 1.0:
                if hours <= 12.0:
                    days = days + .5
                else:
                    days = days + 1.0
            #Compute sub-total
            subtotal = price * days

            #raise osv.except_osv(("Debug"),("Room/Bed: %s, Admission Date/Time: %s") % (roomboard_product_id, beg_datetime))
            #Save the new entry
            rmbd_line = {}
            rmbd_line = {'name': soa_id, 
                        'roomboard_product_id': roomboard_product_id,
                        'beg_datetime': beg_datetime,
                        'end_datetime': end_datetime,
                        'roomboard_price_unit': price,
                        'roomboard_quantity': days,
                        'roomboard_subtotal': subtotal}
            try:
                roomboard_line_id = roomboard_obj.create(cr, uid, rmbd_line, context=None)
            except: #Exception, e:
                raise osv.except_osv(("Error!"),("Error creating the room and board entry."))
        
        if entries == 0:
            raise osv.except_osv(("Error!"),("No room or bed was encoded for this patient."))


    def button_gen_rmbd_invoices(self, cr, uid, ids, context=None):
        invoice_obj = self.pool.get('account.invoice')
        invoice_line_obj = self.pool.get('account.invoice.line')
        journal_obj = self.pool.get('hospbill.journal_ref')
        rm_bd_obj = self.pool.get('hospbill.roomboard_invoice')
        inpac_soa_lines_obj = self.pool.get('hospbill.inpac_soa_lines')

        partner_obj = self.pool.get('res.partner')
        product_obj = self.pool.get('product.product')
        
        #Get the Room and Board journal_ref IDs
        prof_journalref_id = journal_obj.search(cr, uid,[('transtype','=','rmbfee')])
        if not prof_journalref_id:
            raise osv.except_osv(_("Invoice Processing"), _("Error! The required journal was not defined for Room and Board type of transaction."))
        #Get the Room and Board Journal ID
        journal = journal_obj.browse(cr, uid, prof_journalref_id[0])
        prof_journal_id = journal.journal.id

        #Iterate through the Records encoded in the Room and Board Charge Form
        soa = self.browse(cr, uid, ids, context=context)[0]
        partner_id = soa.patient_case_id.name.id
        #res = partner_obj.address_get(cr, uid, [partner_id], ['contact', 'invoice'])
        #address_contact_id = res['contact']
        #address_invoice_id = res['invoice']
        fiscal_position = soa.patient_case_id.name.property_account_position and soa.patient_case_id.name.property_account_position.id or False
        payment_term = soa.patient_case_id.name.property_payment_term and soa.patient_case_id.name.property_payment_term.id or False
        account_id = soa.patient_case_id.name.property_account_receivable and soa.patient_case_id.name.property_account_receivable.id or False
        origin = "In-Patient Case #: " + soa.patient_case_id.admission_no
        soa_id = soa.id
        #raise osv.except_osv(("Debug"),("Values: %s: %s: %s") % (fiscal_position, payment_term, account_id))

        invoice_data = {}
        invoice_data['partner_id'] = partner_id
        #invoice_data['address_contact_id'] = address_contact_id
        #invoice_data['address_invoice_id'] = address_invoice_id
        invoice_data['account_id'] = account_id
        invoice_data['fiscal_position'] = fiscal_position
        invoice_data['payment_term'] = payment_term
        invoice_data['origin'] = origin
        invoice_data['journal_id'] = prof_journal_id
        
        total_charges = 0
        for charge in soa.inpac_rmbd_invoices:
            #raise osv.except_osv(("Debug"),("Values: %s") % (charge.orfee_product_id.name))
            if not charge.invoice_id.id:
                total_charges += 1
                invoice_line_count = 0
                prods_data = {}
                invoice_data['date_invoice'] = charge.beg_datetime

                #Create the invoice for the Room and Board
                if charge.roomboard_product_id:
                    invoice_line_count += 1
                    #Add the Room and Board info to the products array for posting to the customer invoice
                    rmbdfee = product_obj.browse(cr, uid, charge.roomboard_product_id.id)
                    acct_id = rmbdfee.product_tmpl_id.property_account_income.id
                    if not acct_id:
                        acct_id = rmbdfee.categ_id.property_account_income_categ.id
                        if not acct_id:
                            raise osv.except_osv(_('Error !'),
                                _('There is no income account defined for this product: "%s" (id:%d)') % \
                                    (rmbdfee.name, rmbdfee.id,))

                    bill_cat, bill_sub_cat = self.get_bill_cat(cr, uid, rmbdfee.id, rmbdfee.categ_id.id)
                    if charge.roomboard_discount > 0:
                        discval = (charge.roomboard_price_unit * charge.roomboard_quantity) * (charge.roomboard_discount/100)
                        apply_disc = True
                    else:
                        discval = 0
                        apply_disc = False
                    prods_data[rmbdfee.id] = {'product_id':rmbdfee.id,
                        'sequence': invoice_line_count,
                        'name':rmbdfee.name,
                        'quantity':charge.roomboard_quantity,
                        'account_id':acct_id,
                        'price_unit':charge.roomboard_price_unit,
                        'category': bill_cat, 
                        'sub_category': bill_sub_cat, 
                        'discval': discval,
                        'discount': charge.roomboard_discount,
                        'apply_disc': apply_disc}

                #Create the Invoice
                if invoice_line_count > 0:
                    #raise osv.except_osv(("Debug"),("Values: %s") % (ordrfee_invoice_data))
                    try:
                        invoice_ids = invoice_obj.create(cr, uid, invoice_data)
                        #Call the Invoice Open Workflow
                        #data_inv = invoice_obj.read(cr, uid, ordrfee_invoice_ids, ['state'], context=context)
                        #if data_inv['state'] not in ('draft','proforma','proforma2'):
                        #raise wizard.except_wizard(_('Warning'), _("Selected Invoice(s) cannot be confirmed as they are not in 'Draft' or 'Pro-Forma' state!") )
                        #else:
                        #wf_service.trg_validate(uid, 'account.invoice', data_inv['id'], 'invoice_open', cr)
                    except: #Exception, e:
                        raise osv.except_osv(("Error!"),("Error creating the Room and Board invoice"))
                    else:
                        try:
                            updated_rmbd_id = rm_bd_obj.write(cr, uid, charge.id, {'invoice_id': invoice_ids}, context=context)
                        except: #Exception, e:
                            raise osv.except_osv(("Error!"),("Cannot update the Room and Board Record"))
                        else:
                            #Save the Room and Board Invoice Lines
                            for prod_id, prod_data in prods_data.items():
                                #Put all invoice data to product_lines 
                                product_lines = {}
                                product_lines = {'invoice_id': invoice_ids, 
                                                'sequence': prod_data['sequence'],
                                                'product_id':prod_data['product_id'],
                                                'name':prod_data['name'],
                                                'quantity':prod_data['quantity'],
                                                'account_id':prod_data['account_id'],
                                                'price_unit':prod_data['price_unit'],
                                                'discount':prod_data['discount']}
                                try:
                                    invoice_line_id = invoice_line_obj.create(cr, uid, product_lines, context=None)
                                except: #Exception, e:
                                    raise osv.except_osv(("Error!"),("Error creating the invoice line(s)"))
                                else:
                                    #Put all SOA data to soa_lines
                                    soa_lines = {}
                                    soa_lines = {'name': soa_id, 
                                                'invoice_line_id': invoice_line_id, 
                                                'category': prod_data['category'], 
                                                'sub_category': prod_data['sub_category'], 
                                                'apply_disc': prod_data['apply_disc'],
                                                'discval': prod_data['discval'],}

                                    #Add Invoice to the SOA Lines
                                    try:
                                        soa_line_id = inpac_soa_lines_obj.create(cr, uid, soa_lines, context=None)
                                    except: #Exception, e:
                                        raise osv.except_osv(("Error!"),("Error adding the generated invoice(s) to the SOA. Data: %s") % soa_lines)

        if total_charges <= 0:
            raise osv.except_osv(("Error!"),("No action was executed because all charges are already invoiced and added to this SOA."))

inpac_soa ()

class inpac_soa_lines (osv.osv):
    def _compute_patient_charge(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            #val = (line.price_subtotal - line.phic_amt - line.hmo_amt) - (line.discval)
            val = (line.price_subtotal - line.phic_amt - line.hmo_amt)
            res[line.id] = val
        return res

    def _compute_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.price_unit * line.quantity)
            if line.invoice_type == 'out_refund':
                if line.discval < 0:
                    val = val - (line.discval * -1)
                else:
                    val = val - line.discval
                val *= -1
            else:
                val = val - line.discval                
            res[line.id] = val
        return res

    _name = "hospbill.inpac_soa_lines"
    _description = "In-patient Statement of Account Details"
    _columns = {
        'name' : fields.many2one ('hospbill.inpac_soa', 'SOA', readonly=True, ondelete='cascade'),
        'invoice_line_id' : fields.many2one ('account.invoice.line', 'Invoice Line', readonly=True, ondelete='cascade'),
        'partner_id': fields.related ('invoice_line_id','invoice_id','partner_id','id',type="integer",string="Partner ID",store=False, readonly=True),
        'invoice_id': fields.related ('invoice_line_id','invoice_id',type="integer",string="Invoice ID",store=False, readonly=True),
        'invoice_number': fields.related ('invoice_line_id','invoice_id','number',type="char",string="Invoice Number",store=False, readonly=True),
        'invoice_date': fields.related ('invoice_line_id','invoice_id','date_invoice',type="date",string="Date",store=False, readonly=True),
        'invoice_state': fields.related ('invoice_line_id','invoice_id','state',type="char",string="Invoice State",store=False, readonly=True),
        'invoice_type': fields.related ('invoice_line_id','invoice_id','type',type="char",string="Invoice Type",store=False, readonly=True),
        'quantity': fields.related ('invoice_line_id','quantity',type="float",string="QTY",store=False, readonly=True),
        'price_unit': fields.related ('invoice_line_id','price_unit',type="float",string="Unit Cost",store=False, readonly=True),
        'discount': fields.related ('invoice_line_id','discount',type="float",string="Discount(%)",store=False, readonly=True),
        'discval': fields.float ('Discount Value'),
        #'price_subtotal': fields.related ('invoice_line_id','price_subtotal',type="float",string="Sub-Total",store=False, readonly=True),
        'price_subtotal': fields.function(_compute_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'phic_covered': fields.related ('invoice_line_id','phic_covered',type="boolean",string="PHIC Covered",store=False),
        'hmo_covered': fields.related ('invoice_line_id','hmo_covered',type="boolean",string="HMO Covered",store=False),
        'apply_disc': fields.boolean (string="Apply Discount?"),
        'phic_amt': fields.float ('PHIC Charge'),
        'hmo_amt': fields.float ('HMO Charge'),
        'patient_amt': fields.function(_compute_patient_charge, method=True, type="float", string='Patient Charge', readonly=True),
        'category': fields.selection([
            ('none','None'),
            ('01-room-board','Room and Board'),
            ('02-drugs-meds','Drugs and Medicines'),
            ('03-xray-lab-supp-oth','X-Ray, Lab, Supplies, and Others'),
            ('04-operating-room','Operating Room Fee'),
            ('05-pf-visit-gp','PF-Daily Visits(Gen. Practitioner)'),
            ('06-pf-visit-sp','PF-Daily Visits(Specialist)'),
            ('07-pf-surgery','PF-Surgeon'),
            ('08-pf-anesthesiology','PF-Anesthesiologist'),
            ],'Category'),
        'sub_category': fields.selection([
            ('none',''),
            ('01-radiology','Radiology'),
            ('02-laboratory','Laboratory'),
            ('03-supplies','Supplies'),
            ('04-others','Others'),
            ],'Sub-Category'),
        'phic_rvs_code': fields.char ("RVS Code", size=64, readonly=True),
        'phic_rvu': fields.integer ("PHIC RVU", readonly=True),
        'surgeon_id' : fields.many2one ('hr.employee', 'Surgeon', ondelete='restrict', domain=[('doctor','=',True)]),
        'anesthesiologist_id' : fields.many2one ('hr.employee', 'Anesthesiologist', ondelete='restrict', domain=[('doctor','=',True)]),        
        'dv_physician_id' : fields.many2one ('hr.employee', 'Physician', ondelete='restrict', domain=[('doctor','=',True)]),
    }

    _sql_constraints = [
        ('invoice_line_id_unique', 'unique (invoice_line_id)', 'The Invoice Line should be unique.')
    ]

    _defaults = {
        'category': 'none',
        'sub_category': 'none',
    }

    _order = "category, sub_category, id"

inpac_soa_lines ()

class pf_invoice (osv.osv):
    def _compute_orfee_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.orfee_price_unit * line.orfee_quantity) - ((line.orfee_price_unit * line.orfee_quantity) * (line.orfee_discount/100))
            res[line.id] = val
        return res

    def _compute_daily_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.daily_price_unit * line.daily_quantity) - line.daily_discount
            res[line.id] = val
        return res

    def _compute_surgery_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.surgery_price_unit * line.surgery_quantity) - line.surgery_discount
            res[line.id] = val
        return res

    def _compute_anesthe_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.anesthe_price_unit * line.anesthe_quantity) - line.anesthe_discount
            res[line.id] = val
        return res

    def onchange_orservice_id(self, cr, uid, ids, product_id, qty=0, context=None):
        context = context or {}
        if not product_id:
            return {}
        price = 0.0
        for prod in self.pool.get('product.product').browse(cr, uid, [product_id], context=context):
            price = prod.lst_price
            
        result = self.onchange_orservice_qty(cr, uid, ids, product_id, 0.0, qty, price, context=context)
        result['value']['orfee_price_unit'] = price
        return result

    def onchange_orservice_qty(self, cr, uid, ids, product, discount, qty, price_unit, context=None):
        result = {}
        if not product:
            return result

        #prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        price = price_unit * (1 - (discount or 0.0) / 100.0)
        total = price * qty
        result['orfee_subtotal'] = total
        return {'value': result}

    def onchange_daily_id(self, cr, uid, ids, product_id, qty=0, context=None):
        context = context or {}
        if not product_id:
            return {}
        price = 0.0
        for prod in self.pool.get('product.product').browse(cr, uid, [product_id], context=context):
            price = prod.lst_price
            
        result = self.onchange_daily_qty(cr, uid, ids, product_id, 0.0, qty, price, context=context)
        result['value']['daily_price_unit'] = price
        return result

    def onchange_daily_qty(self, cr, uid, ids, product, discount, qty, price_unit, context=None):
        result = {}
        if not product:
            return result

        #prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        #price = price_unit * (1 - (discount or 0.0) / 100.0)
        price = price_unit 
        total = (price * qty) - discount
        result['daily_subtotal'] = total
        return {'value': result}

    def onchange_surgery_id(self, cr, uid, ids, product_id, qty=0, context=None):
        context = context or {}
        if not product_id:
            return {}
        price = 0.0
        for prod in self.pool.get('product.product').browse(cr, uid, [product_id], context=context):
            price = prod.lst_price
            
        result = self.onchange_surgery_qty(cr, uid, ids, product_id, 0.0, qty, price, context=context)
        result['value']['surgery_price_unit'] = price
        return result

    def onchange_surgery_qty(self, cr, uid, ids, product, discount, qty, price_unit, context=None):
        result = {}
        if not product:
            return result

        #prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        #price = price_unit * (1 - (discount or 0.0) / 100.0)
        price = price_unit 
        total = (price * qty) - discount
        result['surgery_subtotal'] = total
        return {'value': result}

    def onchange_anesthe_id(self, cr, uid, ids, product_id, qty=0, context=None):
        context = context or {}
        if not product_id:
            return {}
        price = 0.0
        for prod in self.pool.get('product.product').browse(cr, uid, [product_id], context=context):
            price = prod.lst_price
            
        result = self.onchange_anesthe_qty(cr, uid, ids, product_id, 0.0, qty, price, context=context)
        result['value']['anesthe_price_unit'] = price
        return result

    def onchange_anesthe_qty(self, cr, uid, ids, product, discount, qty, price_unit, context=None):
        result = {}
        if not product:
            return result

        #prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        #price = price_unit * (1 - (discount or 0.0) / 100.0)
        price = price_unit
        total = (price * qty) - discount
        result['anesthe_subtotal'] = total
        return {'value': result}

    def _get_default_surgeon_serv(self, cr, uid, context=None):
        surgeon_service_id = self.pool.get('hospbill.def_surg_anes_serv').search(cr, uid, [('pf_type','=','surgeon')], context=context)
        if surgeon_service_id:
            def_surgeon_service_id = self.pool.get('hospbill.def_surg_anes_serv').browse(cr, uid, surgeon_service_id[0], context=context).pf_service.id
            return def_surgeon_service_id
        else:
            return None

    def _get_default_anesthe_serv(self, cr, uid, context=None):
        anesthesiologist_service_id = self.pool.get('hospbill.def_surg_anes_serv').search(cr, uid, [('pf_type','=','anesthesiologist')], context=context)
        if anesthesiologist_service_id:
            def_anesthesiologist_service_id = self.pool.get('hospbill.def_surg_anes_serv').browse(cr, uid, anesthesiologist_service_id[0], context=context).pf_service.id
            return def_anesthesiologist_service_id
        else:
            return None

    _name = "hospbill.pf_invoice"
    _description = "Professional Fee Invoices"
    _columns = {
        'name' : fields.many2one ('hospbill.inpac_soa', 'SOA', readonly=True, ondelete='restrict'),
        'inv_date' : fields.date ('Date', required=True),
        'invoice_id' : fields.many2one('account.invoice', 'Generated Invoice', ondelete='set null', readonly=True),
        'daily_product_id': fields.many2one('product.product', 'Daily Visit Service', ondelete='set null', domain="[('type','=','service')]"),
        'daily_quantity': fields.float('Number of Days'),
        'daily_price_unit': fields.float('Professional Fee', digits_compute= dp.get_precision('Account')),
        'daily_discount': fields.float('Total Discount', digits_compute= dp.get_precision('Account')),
        'daily_subtotal': fields.function(_compute_daily_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'dv_physician_id' : fields.many2one ('hr.employee', 'Physician', ondelete='restrict', domain=[('doctor','=',True)]),
        'orfee_product_id': fields.many2one('product.product', 'O.R./D.R. Service', ondelete='set null', domain="[('type','=','service')]"),
        'orfee_quantity': fields.float('Number of O.R. use'),
        'orfee_price_unit': fields.float('Operating Room Fee', digits_compute= dp.get_precision('Account')),
        'orfee_discount': fields.float('O.R. Discount (%)', digits_compute= dp.get_precision('Account')),
        'orfee_subtotal': fields.function(_compute_orfee_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'surgery_product_id': fields.many2one('product.product', 'Surgery Service', ondelete='set null', domain="[('type','=','service')]"),
        'surgery_quantity': fields.float('Number of operations'),
        'surgery_price_unit': fields.float('Professional Fee', digits_compute= dp.get_precision('Account')),
        'surgery_discount': fields.float('Total Discount', digits_compute= dp.get_precision('Account')),
        'surgery_subtotal': fields.function(_compute_surgery_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'surgeon_id' : fields.many2one ('hr.employee', 'Surgeon', ondelete='restrict', domain=[('doctor','=',True)]),
        'anesthe_product_id': fields.many2one('product.product', 'Anesthesiology Service', ondelete='set null', domain="[('type','=','service')]"),
        'anesthe_quantity': fields.float('Number of operations'),
        'anesthe_price_unit': fields.float('Anesthesiology Fee', digits_compute= dp.get_precision('Account')),
        'anesthe_discount': fields.float('Total Discount', digits_compute= dp.get_precision('Account')),
        'anesthe_subtotal': fields.function(_compute_anesthe_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'anesthesiologist_id' : fields.many2one ('hr.employee', 'Anesthesiologist', ondelete='restrict', domain=[('doctor','=',True)]),        
        'pf_procedure' : fields.many2one('hospbill.phic_rvs', 'RVS Code'),
        'state': fields.selection([('draft','Draft'),('invoiced','Invoiced'),('cancel','Cancelled')],'State', select=True, readonly=True),
    }

    _defaults = {
        'state': 'draft',
        'orfee_quantity': lambda *a: 1,
        'surgery_quantity': lambda *a: 1,
        'anesthe_quantity': lambda *a: 1,
        'inv_date' : lambda *a: time.strftime('%Y-%m-%d'),
        'surgery_product_id' : _get_default_surgeon_serv,
        'anesthe_product_id' : _get_default_anesthe_serv,
    }

pf_invoice ()

class roomboard_invoice (osv.osv):
    def _compute_roomboard_subtotal(self, cr, uid, ids, name, args, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            val = (line.roomboard_price_unit * line.roomboard_quantity) - ((line.roomboard_price_unit * line.roomboard_quantity) * (line.roomboard_discount/100))
            res[line.id] = val
        return res

    """def onchange_roomboard_id(self, cr, uid, ids, product_id, qty=0, context=None):
        context = context or {}
        if not product_id:
            return {}
        price = 0.0
        for prod in self.pool.get('product.product').browse(cr, uid, [product_id], context=context):
            price = prod.lst_price
            
        result = self.onchange_roomboard_qty(cr, uid, ids, product_id, 0.0, qty, price, context=context)
        result['value']['roomboard_price_unit'] = price
        return result

    def onchange_roomboard_qty(self, cr, uid, ids, product, discount, qty, price_unit, context=None):
        result = {}
        if not product:
            return result

        #prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        price = price_unit * (1 - (discount or 0.0) / 100.0)
        total = price * qty
        result['roomboard_subtotal'] = total
        return {'value': result}

    def onchange_datetime(self, cr, uid, ids, product_id, price, begdatetime, enddatetime, context=None):
        result = {}
        begdatetime = datetime.strptime(begdatetime,'%Y-%m-%d %H:%M:%S')
        enddatetime = datetime.strptime(enddatetime,'%Y-%m-%d %H:%M:%S')
        #delta = relativedelta(enddatetime, begdatetime)
        timedelta = enddatetime - begdatetime
        days = float(timedelta.days)
        hours = float(timedelta.seconds / 3600.00)
        if hours > 1.0:
            if hours <= 12.0:
                days = days + .5
            else:
                days = days + 1.0
        result = self.onchange_roomboard_qty(cr, uid, ids, product_id, 0.0, days, price, context=context)
        result['value']['roomboard_quantity'] = days
        return result"""

    _name = "hospbill.roomboard_invoice"
    _description = "Room and Board Invoices"
    _columns = {
        'name' : fields.many2one ('hospbill.inpac_soa', 'SOA', readonly=True, ondelete='restrict'),
        'invoice_id' : fields.many2one('account.invoice', 'Generated Invoice', ondelete='set null', readonly=True),
        'beg_datetime' : fields.datetime ('Beginning Date & Time', required=True),
        'end_datetime' : fields.datetime ('End Date & Time', required=True),
        'roomboard_product_id': fields.many2one('product.product', 'Room/Bed', required=True, ondelete='set null', domain="[('is_bed', '=', True)]"),
        'roomboard_quantity': fields.float('Number of Days'),
        'roomboard_price_unit': fields.float('Room/Bed Rate', digits_compute= dp.get_precision('Account')),
        'roomboard_discount': fields.float('Discount (%)', digits_compute= dp.get_precision('Account')),
        'roomboard_subtotal': fields.function(_compute_roomboard_subtotal, method=True, type="float", string='Sub-Total', readonly=True),
        'state': fields.selection([('draft','Draft'),('invoiced','Invoiced'),('cancel','Cancelled')],'State', select=True, readonly=True),
    }
    
    _order = "beg_datetime"

    _defaults = {
        'state': 'draft',
        'end_datetime' : lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }

roomboard_invoice ()
