from osv import fields, osv
from tools.translate import _

class his_social_services_class(osv.osv):
    _name = "his.social_services_class"
    _description = "Social Services Classification"
    _columns = {
        'name' : fields.char ('Classification', size=30, required="1"),
        'ssc_desc' : fields.char ('Description', size=60,),
        'pay' : fields.boolean ('Default Pay',),
        'charity' : fields.boolean ('Default Charity',),
        'with_credit' : fields.boolean ('With White Card Credit',),
        'group' : fields.selection ([('a','A'), ('b','B'), ('c','C'), ('d','D')],'Group'),
    }
 
his_social_services_class ()

