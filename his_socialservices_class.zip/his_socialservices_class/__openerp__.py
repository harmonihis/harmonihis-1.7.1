# -*- coding: utf-8 -*-
{

    'name' : 'Social Services Classification',  
    'version' : '3.0',
    'author' : 'vince',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['hospital_mgmt'],
    'description' : """

Social Services Classification

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["his_social_services.xml"],
    "active": False 
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
