{

    'name' : 'Philhealth Passbook Management',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['account', 'hospital_mgmt', 'point_of_sale'],
    'description' : """

Philhealth Passbook Management and Configuration

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["philhealth_package_view.xml", "philhealth_passbook_mgmt_view.xml", "philhealth_passbook_config_view.xml", "data/package_case.xml", "data/packages.xml"],
    #"update_xml" : ["philhealth_package_view.xml", "philhealth_passbook_mgmt_view.xml", "philhealth_passbook_config_view.xml"],
    "active": False 
}
