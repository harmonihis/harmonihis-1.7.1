import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class philhealth_package_category(osv.osv):

    _name = "philhealth.package.category"
    _description = "Philhealth Package Category"
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['name','pf_percentage'], context=context)
        res = []
        for record in reads:
            if record['pf_percentage'] == False:
                pf_percentage = ''
            else:
                pf_percentage = ' (' + str(record['pf_percentage']) + '%)'
            name = record['name'] + pf_percentage
            res.append((record['id'], name))
        return res
    
    _columns = {
        'name' : fields.char ('Package Case Name', size=100, required=True),
        'package_id' : fields.one2many ('philhealth.package', 'package_category_id', 'Package ID'),
        'pf_percentage' : fields.integer ('Doctor\'s PF(%)'),
    }

philhealth_package_category ()

class philhealth_package(osv.osv):

    _name = "philhealth.package"
    _description = "Philhealth Package"
    
    def _credit_limit(self, cr, uid, ids, field_list, arg, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            amount = line.amount
            package_category_id = line.package_category_id.id
            if package_category_id:
                package_category = self.pool.get('philhealth.package.category')
                pf_percentage = package_category.browse(cr, uid, package_category_id).pf_percentage
                credit_limit = (amount - ((float(pf_percentage) / 100) * amount))
            else:
                credit_limit = 0.00
            res[line.id] = credit_limit
        return res
    
    _columns = {
        'name' : fields.char ('Package Name', size=100, required=True),
        'amount' : fields.float ('Amount'),
        'package_category_id' : fields.many2one ('philhealth.package.category', 'Category', required=True),
        'credit_limit' : fields.function (_credit_limit, method=True, fnct_search=None, string="Credit Limit", type="float", store=True),
    }

philhealth_package ()
