import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class philhealth_passbook_config_drugs_and_medicine(osv.osv):

    _name = "philhealth.passbook.config.drugs.and.medicine"
    _description = "Philhealth Passbook Configuration for Drugs and Medicine"
        
    _columns = {
        'date' : fields.date ('Date', readonly=True),
        'amount_a' : fields.float ('A'),
        'amount_b' : fields.float ('B'),
        'amount_c' : fields.float ('C'),
        'amount_d' : fields.float ('D'),
    }
    
    _defaults = {
        'date': lambda * a: time.strftime('%Y-%m-%d'),
    }
    
    _order = "id desc"
philhealth_passbook_config_drugs_and_medicine ()

class philhealth_passbook_config_xray_labs(osv.osv):

    _name = "philhealth.passbook.config.xray.labs"
    _description = "Philhealth Passbook Config for X-ray, Labs and Others"
        
    _columns = {
        'date' : fields.date ('Date', readonly=True),
        'amount_a' : fields.float ('A'),
        'amount_b' : fields.float ('B'),
        'amount_c' : fields.float ('C'),
        'amount_d' : fields.float ('D'),
    }
    
    _defaults = {
        'date': lambda * a: time.strftime('%Y-%m-%d'),
    }
    
    _order = "id desc"
philhealth_passbook_config_xray_labs ()
