import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class philhealth_passbook_mgmt(osv.osv):

    _name = "philhealth.passbook"
    _description = "Philhealth Passbook"
    
    def _state(self, cr, uid, ids, field_list, arg, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            balance = line.balance_drugs_meds
            if balance == 0.00:
                _state = "Zero Credits"
                self.write(cr, uid, line.id, { 'active' : False })
            else:
                _state = "Active"
                #self.write(cr, uid, line.id, { 'active' : True })    
            res[line.id] = _state
        return res
        
    _columns = {
        'passbook_number' : fields.char ('Passbook No.', size=20, required="1"),
        'pos_order_line_id' : fields.one2many ('pos.order.line', 'philhealth_passbook_id', 'Drugs and Medicine'),
        'patient_lab_test_id' : fields.one2many ('his.patient.lab.test', 'philhealth_passbook_id', 'Laboratory Test'),
        'patient_rad_exam_id' : fields.one2many ('his.patient.rad.exam', 'philhealth_passbook_id', 'Radiology Exam'),
        'name' : fields.many2one ('res.partner', 'Patient Name', required="1"),
        'privilege' : fields.selection ([('Case Type','People Service'), ('Package','Package')],'Select Privilege'),
        'package_id' : fields.many2one ('philhealth.package', 'Package Name'),
        'class_type' : fields.many2one ('his.social_services_class', 'Social Service Classification'),
        'case_type' : fields.selection ([('a','A'), ('b','B'), ('c','C'), ('d','D')],'People Service'),
        'date_issued' : fields.date ('Date Issued', readonly=True),
        'amount_drugs_meds' : fields.float ('Credit Limit', readonly=True),
        'balance_drugs_meds' : fields.float ('Current Balance', readonly=True),
        'amount_xray_labs' : fields.float ('Credit Limit', readonly=True),
        'balance_xray_labs' : fields.float ('Current Balance', readonly=True),
        'amount_package' : fields.float ('Credit Limit', readonly=True),
        'balance_package' : fields.float ('Current Balance', readonly=True),
        #'state' : fields.function (_state, method=True, fnct_search=None, string="State", type="char", size=30),
        'active' : fields.boolean ('Active'),
    }
    
    def write(self, cr, uid, ids, vals, context=None):
        count_config_search = 0

        if vals.get('name'):
            patient_id = vals.get('name')
            count_config_search = self.search(cr, uid, [('name','=',patient_id),('active','=',True)], count=True)
        else:
            if context is None:
                context = {}
            #patient_data = self.read(cr, uid, ids, ['name'])[0]
            #patient_data = self.search(cr, uid, [('id','=',ids)])
            #raise osv.except_osv(_('Error :'), _("Code: %s.") %(ids))
            if type(ids) is dict or type(ids) is list:
                patient_id = self.browse(cr, uid, ids[0]).name.id
            else:
                patient_id = self.browse(cr, uid, ids).name.id
            
        
        patient_admission = self.pool.get('his.admission')
        admission_id = patient_admission.search(cr, uid, [('name','=',patient_id),('state','=','Admitted')])
        class_type = patient_admission.browse(cr, uid, admission_id[0]).class_type.id
        vals['class_type'] = class_type
        
        pos_line_total = 0.00
        
        pos_order_line = self.pool.get('pos.order.line')
        for pos_line in pos_order_line.search(cr, uid, [('philhealth_passbook_id','=',ids[0])]):
            pos_line_total += pos_order_line.browse(cr, uid, pos_line).price_subtotal_incl
                
        if vals.get('privilege') == None:
            privilege = self.browse(cr, uid, ids[0]).privilege
        else:
            privilege = vals.get('privilege')
        if privilege == "Case Type":
            drugmed_config = self.pool.get('philhealth.passbook.config.drugs.and.medicine')
            count_config_drugs_meds = drugmed_config.search(cr, uid, [('id','>',0)])
            sorted_id_drugs_meds = sorted(count_config_drugs_meds,reverse=True)
            all_amount_drugs_meds = drugmed_config.browse(cr, uid, sorted_id_drugs_meds[0])
                    
            xray_labs_config = self.pool.get('philhealth.passbook.config.xray.labs')
            count_config_xray_labs = xray_labs_config.search(cr, uid, [('id','>',0)])
            sorted_id_xray_labs = sorted(count_config_xray_labs,reverse=True)
            all_amount_xray_labs = xray_labs_config.browse(cr, uid, sorted_id_xray_labs[0])
            
            if vals.get('case_type'):
                if vals.get('case_type') == 'a':
                    c_type = 'A'
                    amount_drugs_meds = all_amount_drugs_meds.amount_a
                    amount_xray_labs = all_amount_xray_labs.amount_a
                elif vals.get('case_type') == 'b':
                    c_type = 'B'
                    amount_drugs_meds = all_amount_drugs_meds.amount_b
                    amount_xray_labs = all_amount_xray_labs.amount_b
                elif vals.get('case_type') == 'c':
                    c_type = 'C'
                    amount_drugs_meds = all_amount_drugs_meds.amount_c
                    amount_xray_labs = all_amount_xray_labs.amount_c
                elif vals.get('case_type') == 'd':
                    c_type = 'D'
                    amount_drugs_meds = all_amount_drugs_meds.amount_d
                    amount_xray_labs = all_amount_xray_labs.amount_d
                else:
                    c_type = False
                    amount_drugs_meds = 0.00
                    amount_xray_labs = 0.00
                    
                vals['amount_drugs_meds'] = amount_drugs_meds
                vals['balance_drugs_meds'] = amount_drugs_meds - pos_line_total
                vals['amount_xray_labs'] = amount_xray_labs
                vals['balance_xray_labs'] = amount_xray_labs
                vals['amount_package'] = 0.00
                vals['balance_package'] = 0.00
                
        elif privilege == "Package":
            if vals.get('package_id'):
                package_id = vals.get('package_id')
                philhealth_package = self.pool.get('philhealth.package')
                amount = philhealth_package.browse(cr, uid, package_id).credit_limit
                
                vals['amount_package'] = amount
                vals['balance_package'] = amount - pos_line_total
                vals['amount_drugs_meds'] = 0.00
                vals['balance_drugs_meds'] = 0.00
                vals['amount_xray_labs'] = 0.00
                vals['balance_xray_labs'] = 0.00
            else:
                amount = 0.00
        else:
            amount = 0.00
        
        if count_config_search > 0:
            raise osv.except_osv(_('Warning:'),_("Only one(1) active Philhealt Passbook is allowed for every admitted patient."))
        else:
            return super(philhealth_passbook_mgmt, self).write(cr, uid, ids, vals, context)
        
    def create(self, cr, uid, vals, context=None):
        patient_id = vals['name']
        
        patient_admission = self.pool.get('his.admission')
        admission_id = patient_admission.search(cr, uid, [('name','=',patient_id),('state','=','Admitted')])
        class_type = patient_admission.browse(cr, uid, admission_id[0]).class_type.id
        vals['class_type'] = class_type
        
        if vals.get('privilege') == "Case Type":
            drugmed_config = self.pool.get('philhealth.passbook.config.drugs.and.medicine')
            count_config_drugs_meds = drugmed_config.search(cr, uid, [('id','>',0)])
            sorted_id_drugs_meds = sorted(count_config_drugs_meds,reverse=True)
            all_amount_drugs_meds = drugmed_config.browse(cr, uid, sorted_id_drugs_meds[0])
            
            xray_labs_config = self.pool.get('philhealth.passbook.config.xray.labs')
            count_config_xray_labs = xray_labs_config.search(cr, uid, [('id','>',0)])
            sorted_id_xray_labs = sorted(count_config_xray_labs,reverse=True)
            all_amount_xray_labs = xray_labs_config.browse(cr, uid, sorted_id_xray_labs[0])
            
            if vals.get('case_type'):
                if vals.get('case_type') == 'a':
                    c_type = 'A'
                    amount_drugs_meds = all_amount_drugs_meds.amount_a
                    amount_xray_labs = all_amount_xray_labs.amount_a
                elif vals.get('case_type') == 'b':
                    c_type = 'B'
                    amount_drugs_meds = all_amount_drugs_meds.amount_b
                    amount_xray_labs = all_amount_xray_labs.amount_b
                elif vals.get('case_type') == 'c':
                    c_type = 'C'
                    amount_drugs_meds = all_amount_drugs_meds.amount_c
                    amount_xray_labs = all_amount_xray_labs.amount_c
                elif vals.get('case_type') == 'd':
                    c_type = 'D'
                    amount_drugs_meds = all_amount_drugs_meds.amount_d
                    amount_xray_labs = all_amount_xray_labs.amount_d
            else:
                c_type = False
                amount_drugs_meds = 0.00
            
            vals['amount_drugs_meds'] = amount_drugs_meds
            vals['balance_drugs_meds'] = amount_drugs_meds
            vals['amount_xray_labs'] = amount_xray_labs
            vals['balance_xray_labs'] = amount_xray_labs
            vals['amount_package'] = 0.00
            vals['balance_package'] = 0.00
            
        elif vals.get('privilege') == "Package":
            if vals.get('package_id'):
                package_id = vals.get('package_id')
                philhealth_package = self.pool.get('philhealth.package')
                amount = philhealth_package.browse(cr, uid, package_id).credit_limit
            else:
                amount = 0.00
            
            vals['amount_drugs_meds'] = 0.00
            vals['balance_drugs_meds'] = 0.00
            vals['amount_xray_labs'] = 0.00
            vals['balance_xray_labs'] = 0.00
            vals['amount_package'] = amount
            vals['balance_package'] = amount
        else:
            amount = 0.00
        
        count_config_search = self.search(cr, uid, [('name','=',patient_id),('active','=',True)], count=True)
        if count_config_search > 0:
            raise osv.except_osv(_('Warning:'),_("Only one(1) active Philhealt Passbook is allowed for every admitted patient."))
        else:
            return super(philhealth_passbook_mgmt, self).create(cr, uid, vals, context)
            
    def onchange_patient_name(self, cr, uid, ids, name):
        patient_admission = self.pool.get('his.admission')
        admission_id = patient_admission.search(cr, uid, [('name','=',name),('state','=','Admitted')])
        class_type = patient_admission.browse(cr, uid, admission_id[0]).class_type.id
        
        drugmed_config = self.pool.get('philhealth.passbook.config.drugs.and.medicine')
        count_config = drugmed_config.search(cr, uid, [('id','>',0)])
        sorted_id = sorted(count_config,reverse=True)
        all_amount = drugmed_config.browse(cr, uid, sorted_id[0])
        
        return {'value': {'class_type': class_type}}
    
    def onchange_privilege(self, cr, uid, ids, privilege):
        case_type = False
        package_id = False
        if privilege == 'Case Type':
            case_type = "a"
        elif privilege == 'Package':
            philhealth_package = self.pool.get('philhealth.package')
            philhealth_package_id = philhealth_package.search(cr, uid, [('id','>',0)])[0]
            package_id = philhealth_package_id
        return {'value': {'case_type': case_type, 'package_id': package_id}}
        
    def update_phic_passbook_balance(self, cr, uid, ids, partner_patient_id, philhealth_used, bal):
        philhealth_passbook_id = self.search(cr, uid, [('name','=',partner_patient_id), ('active', '=', 1)])
        philhealth_passbook = self.browse(cr, uid, philhealth_passbook_id[0], context=None)
        philhealth_privilege = philhealth_passbook.privilege
        if philhealth_privilege == 'Case Type':
            if bal == 'drugmed':
                philhealth_balance = philhealth_passbook.balance_drugs_meds - philhealth_used
                self.write(cr, uid, philhealth_passbook_id, { 'balance_drugs_meds' : philhealth_balance })
            elif bal == 'xlab':
                philhealth_balance = philhealth_passbook.balance_xray_labs - philhealth_used
                self.write(cr, uid, philhealth_passbook_id, { 'balance_xray_labs' : philhealth_balance })
        elif philhealth_privilege == 'Package':
            philhealth_balance = philhealth_passbook.balance_package - philhealth_used
            self.write(cr, uid, philhealth_passbook_id, { 'balance_package' : philhealth_balance })
        return philhealth_passbook_id[0]
        
    def get_phic_passbook_balance(self, cr, uid, partner_patient_id, phic_passbook, bal):
        philhealth_balance = 0.00
        philhealth_id = self.search(cr, uid, [('name', '=', partner_patient_id), ('active', '=', 1)])
        if philhealth_id and phic_passbook == True:
            philhealth_privilege = self.browse(cr, uid, philhealth_id[0], context=None).privilege
            if philhealth_privilege == 'Case Type':
                if bal == 'drugmed':
                    philhealth_balance = self.browse(cr, uid, philhealth_id[0], context=None).balance_drugs_meds
                elif bal == 'xlab':
                    philhealth_balance = self.browse(cr, uid, philhealth_id[0], context=None).balance_xray_labs
            elif philhealth_privilege == 'Package':
                philhealth_balance = self.browse(cr, uid, philhealth_id[0], context=None).balance_package
        return philhealth_balance
        
    def onchange_case_type(self, cr, uid, ids, package_id,case_type,privilege,name):
        c_type = False
        amount_drugs_meds = 0.00
        amount_xray_labs = 0.00
        amount = 0.00
        pos_line_total = 0.00
        
        if ids:
            pos_order_line = self.pool.get('pos.order.line')
            for pos_line in pos_order_line.search(cr, uid, [('philhealth_passbook_id','=',ids[0])]):
                pos_line_total += pos_order_line.browse(cr, uid, pos_line).price_subtotal_incl
        #raise osv.except_osv(_('Error :'), _("Code: %s.") %(pos_line_total))
        
        
        if privilege == "Case Type":
            drugmed_config = self.pool.get('philhealth.passbook.config.drugs.and.medicine')
            count_config_drugs_meds = drugmed_config.search(cr, uid, [('id','>',0)])
            sorted_id_drugs_meds = sorted(count_config_drugs_meds,reverse=True)
            all_amount_drugs_meds = drugmed_config.browse(cr, uid, sorted_id_drugs_meds[0])
            
            xray_labs_config = self.pool.get('philhealth.passbook.config.xray.labs')
            count_config_xray_labs = xray_labs_config.search(cr, uid, [('id','>',0)])
            sorted_id_xray_labs = sorted(count_config_xray_labs,reverse=True)
            all_amount_xray_labs = xray_labs_config.browse(cr, uid, sorted_id_xray_labs[0])
            
            if case_type == 'a':
                c_type = 'A'
                amount_drugs_meds = all_amount_drugs_meds.amount_a
                amount_xray_labs = all_amount_xray_labs.amount_a
            elif case_type == 'b':
                c_type = 'B'
                amount_drugs_meds = all_amount_drugs_meds.amount_b
                amount_xray_labs = all_amount_xray_labs.amount_b
            elif case_type == 'c':
                c_type = 'C'
                amount_drugs_meds = all_amount_drugs_meds.amount_c
                amount_xray_labs = all_amount_xray_labs.amount_c
            elif case_type == 'd':
                c_type = 'D'
                amount_drugs_meds = all_amount_drugs_meds.amount_d
                amount_xray_labs = all_amount_xray_labs.amount_d
           
        elif privilege == "Package":
            philhealth_package = self.pool.get('philhealth.package')
            amount = philhealth_package.browse(cr, uid, package_id).credit_limit
            
        else:
            amount = 0.00
        
        return {'value': {'name': name, 
                              'amount_drugs_meds': amount_drugs_meds, 
                              'balance_drugs_meds': amount_drugs_meds - pos_line_total, 
                              'amount_xray_labs': amount_xray_labs, 
                              'balance_xray_labs': amount_xray_labs,
                              'amount_package': amount,
                              'balance_package': amount - pos_line_total}}
 
    _defaults = {
        'date_issued': lambda * a: time.strftime('%Y-%m-%d'),
        'active': lambda * a: True,
    }

philhealth_passbook_mgmt ()

class res_partner_custom(osv.osv):

    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'philhealth_passbook' : fields.one2many ('philhealth.passbook', 'name', 'Patient Name'),
    }

res_partner_custom ()

class his_patient_lab_test_custom(osv.osv):

    _name = "his.patient.lab.test"
    _inherit = "his.patient.lab.test"
    _columns = {
        'philhealth_passbook_id' : fields.many2one ('philhealth.passbook', 'PhilHealth Passbook ID'),
    }

his_patient_lab_test_custom ()

class his_patient_rad_exam_custom(osv.osv):

    _name = "his.patient.rad.exam"
    _inherit = "his.patient.rad.exam"
    _columns = {
        'philhealth_passbook_id' : fields.many2one ('philhealth.passbook', 'PhilHealth Passbook ID'),
    }

his_patient_rad_exam_custom ()

class pos_order_line_custom(osv.osv):

    _name = "pos.order.line"
    _inherit = "pos.order.line"
    _columns = {
        'philhealth_passbook_id' : fields.many2one ('philhealth.passbook', 'PhilHealth Passbook ID'),
        'phic_covered' : fields.boolean ('PHIC Covered'),
    }
    
    def onchange_phic_covered(self, cr, uid, ids, phic_covered):
        result = {}
        philhealth_passbook = self.pool.get('philhealth.passbook')
        pos_order = self.pool.get('pos.order')
        
        pos_order_line = self.browse(cr, uid, ids[0])
        price_subtotal_incl = pos_order_line.price_subtotal_incl
        philhealth_passbook_id = pos_order_line.philhealth_passbook_id.id
        order_id = pos_order_line.order_id.id
        
        philhealth_passbook_balance = philhealth_passbook.browse(cr, uid, philhealth_passbook_id).balance_drugs_meds
        philhealth_used = pos_order.browse(cr, uid, order_id).philhealth_used
        
        if phic_covered == True:
            new_philhealth_passbook_balance = philhealth_passbook_balance - price_subtotal_incl
            new_philhealth_used = philhealth_used + price_subtotal_incl
            if new_philhealth_passbook_balance < 0:
                result['phic_covered'] = False
                return {'value':result, 'warning':{'message':'Warning \n\n Subtotal is greater than PHIC Current Balance.'}}
        else:
            new_philhealth_passbook_balance = philhealth_passbook_balance + price_subtotal_incl
            new_philhealth_used = philhealth_used - price_subtotal_incl
        
        #pos_order.write(cr, uid, order_id, { 'physician' : 'asd'})
        philhealth_passbook.write(cr, uid, philhealth_passbook_id, { 'balance_drugs_meds' : new_philhealth_passbook_balance})
        
        result = {'value':{'balance_drugs_meds':new_philhealth_passbook_balance}}
        return result
        
    _defaults = {
        'phic_covered': lambda * a: False,
    }

pos_order_line_custom ()

class his_social_services_class_custom(osv.osv):

    _name = "his.social_services_class"
    _inherit = "his.social_services_class"
    _columns = {
        'philhealth_passbook_id' : fields.one2many ('philhealth.passbook', 'class_type', 'PhilHealth Passbook ID'),
    }
his_social_services_class_custom ()

class philhealth_package_custom(osv.osv):

    _name = "philhealth.package"
    _inherit = "philhealth.package"
    _columns = {
        'philhealth_passbook_id' : fields.one2many ('philhealth.passbook', 'package_id', 'PhilHealth Passbook ID'),
    }
philhealth_package_custom ()
