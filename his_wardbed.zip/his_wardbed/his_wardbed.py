from osv import fields, osv
from tools.translate import _

class his_ward(osv.osv):
    _name = "his.ward"
    _description = "Ward"
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['name'], context=context)
        res = []
        for record in reads:
            if record['name'] == False:
                name = ''
            else:
                name = self.pool.get('product.category').browse(cr, uid, record['name'][0]).name
            res.append((record['id'], name))
        return res
        
    _columns = {
        'name': fields.many2one ('product.category','Ward Name', required="1", domain="[('bed', '=', 1), ('with_bed', '=', with_bed)]"),
        'with_bed' : fields.boolean ('With Bed/s'),
        'beds' : fields.one2many ('his.bed', 'bed_no', 'Bed No.'),
        'group' : fields.selection ([('DEMS','DEMS'), ('OB-AS','OB-AS')],'Group'),    
    }
    
    def onchange_with_bed(self, cr, uid, ids, with_bed):
        return {'value': {'name': False, 'group':False}}
        
his_ward ()

class product_category_custom(osv.osv):

    _name = "product.category"
    _inherit = "product.category"
    
    _columns = {
        'bed': fields.boolean ('Bed Category'),
        'with_bed': fields.boolean ('With Bed'),
    }
    
product_category_custom () 

class his_bed(osv.osv):

    _name = "his.bed"
    _description = "Bed"
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['name'], context=context)
        res = []
        for record in reads:
            if record['name'] == False:
                name = ''
            else:
                name = self.pool.get('product.product').browse(cr, uid, record['name'][0]).name_template
            res.append((record['id'], name))
        return res
        
    _columns = {
        'bed_no' : fields.many2one ('his.ward', 'Wards'),
        'ward_categ_id' : fields.integer ("Category ID"),
        'name': fields.many2one ('product.product','Bed Name', required="1", domain="[('product_tmpl_id.categ_id.id', '=', ward_categ_id)]"),
        'bed_desc' : fields.char ('Description' , size=250,),
        'bed_type' : fields.selection ([('Ward','Charity Ward'), ('Private','Private'), ('Semi-Private','Semi-Private'), ('ICU','ICU')],'Type'),
        'state' : fields.selection ([
                                          ('Occupied', 'Occupied'),
                                          ('Vacant', 'Vacant'),
                                          ('For Cleaning', 'For Cleaning'),
                                          ('Under Maintenance', 'Under Maintenance')
                                         ], 'State'),
        'notes': fields.text ('Notes' ,),
    }

    def onchange_bed_no(self, cr, uid, ids, bed_no):
        if bed_no:
            bed_id = self.pool.get('his.ward')
            categ_id = bed_id.browse(cr, uid, bed_no).name.id
        else:
            categ_id = False
        return {'value': {'ward_categ_id': categ_id}}
    
    _defaults = {
        'state' : 'Vacant',
        'bed_no' : lambda self, cr, uid, context : context['bed_no'] if context and 'bed_no' in context else None,
    }
   
    def wardbed_set_vaccant(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'state' : 'Vacant', 'notes' : ''})
        return True 
        
    def wardbed_for_cleaning(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'state' : 'For Cleaning', 'notes' : ''})
        return True
        
    def wardbed_set_undermaintenance(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'state' : 'Under Maintenance'})
        return True 

his_bed ()
