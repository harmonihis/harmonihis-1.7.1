# -*- coding: utf-8 -*-
{

    'name' : 'HIS Ward bed',  
    'version' : '3.0',
    'author' : 'vince',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['hospital_mgmt','product'],
    'description' : """

HIS Ward & Bed

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["his_wardbed.xml","his_wardbeds_management_view.xml"],
    "active": False 
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
