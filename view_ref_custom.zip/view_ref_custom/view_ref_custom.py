import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class view_ref_custom_class(osv.osv):
    
    _name = "res.partner"
    _inherit = "res.partner"

    def onchange_phic_no(self, cr, uid, ids, phic_no, context=None):
        if phic_no == '':
            phic = "None"
        else:
            phic = "Member"
        result = {'value':{'phic':phic}}
        return result
        
    def onchange_fname(self, cr, uid, ids, phic_no, context=None):
        result = {'value':{'gender':'FEMALE'}}
        return result
        
view_ref_custom_class ()
