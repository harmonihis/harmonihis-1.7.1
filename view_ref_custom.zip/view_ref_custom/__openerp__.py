{

    'name' : 'Default View Customization',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['account', 'point_of_sale', 'his_admission', 'his_pos_nurse_station', 'hr'],
    'description' : """

Default View Customization

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["view_ref_custom_view.xml"],
    "active": False 
}
