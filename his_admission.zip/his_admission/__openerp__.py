{

    'name' : 'Patient Admission',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['base', 'account', 'hospital_mgmt', 'point_of_sale', 'his_wardbed', 'his_clinics'],
    'description' : """

Patient Admission

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["his_admission_view.xml", "his_room_transfer_view.xml", "data/his_admission_sequence.xml", "data/his_admission_pricelist.xml", "his_admission_report.xml", "security/his_admission_security.xml"],
    "active": False 
}
