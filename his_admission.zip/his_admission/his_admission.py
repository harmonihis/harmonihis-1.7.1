import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class hr_employee_custom(osv.osv):

    _name = "hr.employee"
    _inherit = "hr.employee"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'physician_id', 'Patient Admission ID'),
        'doctor' : fields.boolean ('Doctor'),
    }

hr_employee_custom ()

class his_admission_class(osv.osv):

    _name = "his.admission"
    _description = "Patient Admission"
    
    def _get_address (self, cr, uid, ids, name_info, context=None):
        res_partner_address = self.pool.get('res.partner')
        res_partner_address_id = res_partner_address.search(cr, uid, [('id','=',name_info)])
        partner_address = res_partner_address.browse(cr, uid, res_partner_address_id[0])
        if partner_address.street == False:
            street = ''
        else:
            street = partner_address.street
        if partner_address.city == False:
            city = ''
        else:
            if partner_address.street == False:
                city = partner_address.city
            else:
                city = ', ' + partner_address.city
        if str(partner_address.state_id) == '':
            province = ''
        else:
            if partner_address.city == False:
                province = partner_address.state_id.name
            else:
                province = ', ' + partner_address.state_id.name
        if str(partner_address.country_id) == '':
            country = ''
        else:
            if str(partner_address.state_id) == '':
                country = partner_address.country_id.name
            else:
                country = ', ' + partner_address.country_id.name
        address_info = street + city + province + country
        return address_info
            
    def _emergency_address(self, cr, uid, ids, field_name, arg, context):
        emergency_address = {}
        for line in self.browse(cr, uid, ids ,context):
            if str(line.emergency) == '':
                emergency_address[line.id] = ''
            else:
                emergency_address[line.id] = self._get_address (cr, uid, ids, line.emergency.id)
        return emergency_address
        
    def _account_address(self, cr, uid, ids, field_name, arg, context):
        account_address = {}
        for line in self.browse(cr, uid, ids ,context):
            if str(line.account) == '':
                account_address[line.id] = ''
            else:
                account_address[line.id] = self._get_address (cr, uid, ids, line.account.id)
        return account_address
        
    def _furnished_address(self, cr, uid, ids, field_name, arg, context):
        furnished_address = {}
        for line in self.browse(cr, uid, ids ,context):
            if str(line.furnished) == '':
                furnished_address[line.id] = ''
            else:
                furnished_address[line.id] = self._get_address (cr, uid, ids, line.furnished.id)
        return furnished_address
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        my_reads = self.read(cr, uid, ids, ['name'], context=context)
        res = []
        for data in my_reads:
            res_partner_id = data['name'][0]
            
            record = self.pool.get('res.partner').read(cr, uid, res_partner_id, ['ref','name','fname','mname','birthdate'], context=context)
            
            if record['birthdate'] == False:
                bday = ''
            else:
                if record['ref'] == False:
                    bday = ''
                else:
                    dob = record['birthdate'].split('-')
                    bday = ' - ' + dob[1]  + '/' + dob[2] + '/' + dob[0]
            if record['fname'] == False:
                fname = ''
            else:
                fname = ', ' + record['fname']
            if record['mname'] == False:
                mname = ''
            else:
                mname = ' ' + record['mname']
            if record['ref'] == False:
                ref = ''
            else:
                ref = "[" + record['ref'] + "] "
            name = ref + record['name'] + fname + mname + bday
            res.append((data['id'], name))
        return res
        
    _columns = {
        'admission_no' : fields.char ('PIN', size=15, readonly=True),
        'name' : fields.many2one ('res.partner', 'Patient Name', required="1", domain=[('customer', '=', 1)]),
        'date_admitted' : fields.datetime ('Date of Admission'),
        'date_discharged' : fields.datetime ('Date Discharged'),
        'charity' : fields.boolean ('Charity Patient', readonly=True),
        'department_id' : fields.many2one ('hr.department', 'Department', readonly=True),
        'department_group' : fields.char ('Department Group', size=10),
        'clinic_id' : fields.many2one ('his.clinics','Clinic Assigned', domain="[('charity', '=', charity), ('department_id','=',department_id)]"),
        'brought_in_by' : fields.selection ([('Self','Self'), ('Police','Police'), ('Ambulance','Ambulance'), ('Others','Others')],'Brought in by'),
        'emergency' : fields.many2one ('res.partner', 'Name', domain=[('customer', '=', 1)]),
        'emergency_relation' : fields.char ('Relation to Patient', size=15),
        'emergency_address' : fields.function (_emergency_address, method=True, fnct_search=None, string="Address", type="char", size= 200,readonly=True),
        'emergency_phone' : fields.char ('Phone No.', size=15),
        'account' : fields.many2one ('res.partner', 'Name', domain=[('customer', '=', 1)]),
        'account_relation' : fields.char ('Relation to Patient', size=15),
        'account_address' : fields.function (_account_address, method=True, fnct_search=None, string="Address", type="char", size= 200,readonly=True),
        'account_phone' : fields.char ('Phone No.', size=15),
        'furnished' : fields.many2one ('res.partner', 'Name', domain=[('customer', '=', 1)]),
        'furnished_relation' : fields.char ('Relation to Patient', size=15),
        'furnished_address' : fields.function (_furnished_address, method=True, fnct_search=None, string="Address", type="char", size= 200,readonly=True),
        'furnished_phone' : fields.char ('Phone No.', size=15),
        'room_transfer_id' : fields.one2many ('his.room.transfer', 'admission_id', 'Room Assignment History'),
        'class_type' : fields.many2one ('his.social_services_class', 'Social Service Classification'),
        'disc_type' : fields.many2one ('his.discounts', 'Discount Type'),
        'hosp_plan' : fields.selection ([('Company','Company'), ('Insurance','Insurance'), ('Others','Others')],'Hospitalization Plan'),
        'physician_id' : fields.many2one ('hr.employee', 'Physician In-Charge', domain=[('doctor', '=', 1)]),
        'data_taken_by' : fields.many2one ('res.users', 'Data Taken By', readonly=True),
        'designation' : fields.many2one ('hr.job', 'Designation', readonly=True),
        'admission_impression' : fields.text ('Admission Impression'),
        'operation' : fields.text ('Operation(s)'),
        'final_diag' : fields.text ('Final Diagnosis'),
        'final_diag_icd' : fields.many2one ('medical.pathology', 'ICD Code'),
        'results' : fields.selection ([('Recovered','Recovered'), ('Improved','Improved'), ('Not Improved','Not Improved'), ('Died under 48 hours','Died under 48 hours'), ('Died at 48 hours or more','Died at 48 hours or more')],'Results'),
        'autopsy' : fields.boolean ('Autopsy'),
        'backlogs' : fields.boolean ('Backlogs'),
        'unlocked' : fields.boolean ('Unlocked'),
        'disposition' : fields.selection ([('Discharged','Discharged'), ('Transfered','Transfered'), ('Absconded','Absconded'), ('Left againts medical advice','Left againts medical advice'), ('Referred to OPD for follow up','Referred to OPD for follow up')],'Disposition'),
        'state' : fields.selection ([('New','New'), ('Draft','Draft'), ('Admitted','Admitted'), ('Discharged','Discharged'), ('Outpatient','Outpatient'), ('Cancelled','Cancelled')],'State', readonly=True),
        'status' : fields.selection ([('Not in Ward','Not in Ward'), ('Inpatient','Inpatient')],'Status', readonly=True),
        'for_transfer' : fields.selection ([('Unlocked','Unlocked'),('For Admission Transfer','For Admission Transfer')],'For Transfer', readonly=True),
        'pos_order_line' : fields.one2many ('pos.order.line', 'admission_id', 'Admission ID'),
    }
        
    def onchange_patient_name(self, cr, uid, ids, name, context=None):
        result = {}
        res_partner = self.pool.get('res.partner').browse(cr, uid, name)
        admission_id = self.search(cr, uid, [('name','=',name), ('state','=','Admitted')])
        if admission_id:
            admission = self.browse(cr, uid, admission_id[0])
            if admission.department_id.name:
                department_name = "\nDepartment: " + admission.department_id.name
            else:
                department_name = ''
            if admission.data_taken_by.name:
                taken_by= "\nby " + admission.data_taken_by.name
            else:
                taken_by = ''
            if admission.room_transfer_id[0].ward_no:
                ward_name = "\nWard: " + admission.room_transfer_id[0].ward_no.name.name
            else:
                ward_name = ''
            if admission.room_transfer_id[0].bed_no:
                bed_name = "\nRoom/Bed: " + admission.room_transfer_id[0].bed_no.name.name
            else:
                bed_name = ''
        admitted = res_partner.admitted
        if res_partner.whole_name:
            whole_name = "\nName: " + res_partner.whole_name
        else:
            whole_name = ''
        if res_partner.ref:
            ref = "Case No.: " + res_partner.ref
        else:
            ref = ''
        if admitted == True:
            warn_msg = "This patient is already admitted! \n\n" \
                        + ref + whole_name + department_name + ward_name + bed_name + taken_by
            result = {'value':{'name':''}, 'warning':{'title':'Warning', 'message':warn_msg}}
        return result
    
    def _get_relation (self, cr, uid, ids, name, emergency, context=None):
        res_partner = self.pool.get('res.partner')
        father = res_partner.search(cr, uid, [('id','=',name), ('father','=',emergency)])
        mother = res_partner.search(cr, uid, [('id','=',name), ('mother','=',emergency)])
        spouse = res_partner.search(cr, uid, [('id','=',name), ('spouse','=',emergency)])
        relation = False
        if father:
            relation = "Father"
        elif mother:
            relation = "Mother"
        elif spouse:
            relation = "Spouse"
        elif name == emergency:
            relation = "Self"
        return relation
        
    def onchange_emergency(self, cr, uid, ids, emergency, name, context=None):
        if name == False:
            #raise osv.except_osv(_('Warning :'), _("Patient: %s \n Emergency: %s") %(name,emergency))
            result = {'value':{'emergency':''}, 'warning':{'title':"Warning", 'message':"Warning! \n\n Patient Name is required."}}
        else:
            relation = self._get_relation(cr, uid, ids, name, emergency)
            result = {'value':{'emergency_relation':relation, 'furnished_relation':relation, 'furnished':emergency, 'account_relation':relation, 'account':emergency}}
        return result
        
    def onchange_date(self, cr, uid, ids, date_admitted, date_discharged, state, context=None):
        if date_admitted > date_discharged and state != "Outpatient":
            #raise osv.except_osv(_('Warning :'), _("Patient: %s \n Emergency: %s") %(name,emergency))
            if state != "Admitted":
                result = {'value':{'date_admitted':date_discharged, 'date_discharged':date_discharged}, 'warning':{'title':"Warning", 'message':"Warning! \n\n Date of Admission cannot be greater than Date Discharged."}}
            else:
                result = {'value':{'backlogs':True}}
        else:
            if state == "Outpatient":
                result = {'value':{'date_discharged':date_admitted, 'backlogs':True}}
            else:
                result = {'value':{'backlogs':True}}
        return result
    
    def onchange_account(self, cr, uid, ids, account, name, context=None):
        if name == False:
            #raise osv.except_osv(_('Warning :'), _("Patient: %s \n Emergency: %s") %(name,emergency))
            result = {'value':{'account':''}, 'warning':{'title':"Warning", 'message':"Warning! \n\n Patient Name is required."}}
        else:
            relation = self._get_relation(cr, uid, ids, name, account)
            result = {'value':{'account_relation':relation}}
        return result
        
    def onchange_furnished(self, cr, uid, ids, furnished, name, context=None):
        if name == False:
            result = {'value':{'furnished':''}, 'warning':{'title':"Warning", 'message':"Warning! \n\n Patient Name is required."}}
        else:
            relation = self._get_relation(cr, uid, ids, name, furnished)
            result = {'value':{'furnished_relation':relation}}
        return result
        
    def patient_admitted(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        patient_data = self.read(cr, uid, ids, ['name', 'charity','date_admitted','department_id','class_type'])[0]
        class_type_id = patient_data['class_type'][0]
        #class_type_group = self.pool.get('his.social_services_class').browse(cr, uid, class_type_id).group
        pricelist_id = self.pool.get('product.pricelist').search(cr, uid, [('pricelist_group','=','b')])[0]
        #raise osv.except_osv(_('Warning :'), _("%s") %(pricelist_id))
        patient_id = patient_data['name'][0]
        department_id = patient_data['department_id'][0]
        charity = patient_data['charity']
        date_admitted = patient_data['date_admitted']
        if date_admitted:
            self.write(cr, uid, ids, { 'state' : 'Admitted' , 'status':'Not in Ward'})
        else:
            self.write(cr, uid, ids, { 'state' : 'Admitted' , 'status':'Not in Ward', 'date_admitted' : time.strftime('%Y-%m-%d %H:%M:%S')})

        dept_group_hr = self.pool.get('hr.department').browse(cr, uid, department_id).dept_group
        dept_group_ward = self.pool.get('his.ward').search(cr, uid, [('group','=',dept_group_hr)])
        self.pool.get('his.room.transfer').create(cr, uid, {'dept_name':department_id, 
                                                            'admission_id':ids[0], 
                                                            'ward_no2':dept_group_ward[0],
                                                            'admit_count': True,
                                                            'date_in': time.strftime('%Y-%m-%d %H:%M:%S'),
                                                            't_out': False,
                                                            't_in': False,
                                                            'ward_count': False,
                                                            'locked': True,
                                                            'discharge_count': False,})
        
        res_partner = self.pool.get('res.partner')
        res_partner.write(cr, uid, patient_id, { 'admitted' : True, 'charity' : charity, 'property_product_pricelist': pricelist_id, 'admission_id' : ids[0]})
        return True 
        
    def patient_admitted_ward(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        
        patient_data = self.read(cr, uid, ids, ['name', 'charity','date_admitted'])[0]
        patient_id = patient_data['name'][0]
        charity = patient_data['charity']
        date_admitted = patient_data['date_admitted']
        if date_admitted:
            self.write(cr, uid, ids, { 'state' : 'Admitted' , 'status':'Inpatient'})
            his_room_transfer = self.pool.get('his.room.transfer')
            count_room = his_room_transfer.search(cr, uid, [('admission_id','=',ids[0])], count=True)
            if count_room > 0:
                count_config = his_room_transfer.search(cr, uid, [('id','>',0), ('admission_id','=',ids[0])])
                sorted_id = sorted(count_config,reverse=True)
                his_room_transfer.write(cr, uid, sorted_id[0], { 't_out' : True, 'date_out' : time.strftime('%Y-%m-%d %H:%M:%S') })
        else:
            self.write(cr, uid, ids, { 'state' : 'Admitted' , 'status':'Inpatient', 'date_admitted' : time.strftime('%Y-%m-%d %H:%M:%S')})
        res_partner = self.pool.get('res.partner')
        
        pricelist_group = "outpay"
        if charity == True:
            pricelist_group = "b"
        pricelist_id = self.pool.get('product.pricelist').search(cr, uid, [('pricelist_group','=',pricelist_group)])[0]
        res_partner.write(cr, uid, patient_id, { 'property_product_pricelist': pricelist_id, 'charity' : charity, 'admitted' : True , 'admission_id' : ids[0]})
        return True   
        
    def patient_outpatient(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        patient_data = self.read(cr, uid, ids, ['name'])[0]
        patient_id = patient_data['name'][0]
        pricelist_id = self.pool.get('product.pricelist').search(cr, uid, [('pricelist_group','=','outpay')])[0]
        res_partner = self.pool.get('res.partner')
        res_partner.write(cr, uid, patient_id, { 'property_product_pricelist': pricelist_id, 'admitted' : False , 'admission_id' : ids[0]})
        self.write(cr, uid, ids, { 'state' : 'Outpatient', 'date_admitted' : time.strftime('%Y-%m-%d %H:%M:%S'), 'date_discharged' : time.strftime('%Y-%m-%d %H:%M:%S')})
        return True   
        
    def locked_date(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'unlocked' : False, 'for_transfer' : False})
        return True     
        
    def unlocked_date(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'unlocked' : True, 'for_transfer' : 'Unlocked'})
        return True 
        
    def patient_discharge(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'state' : 'Discharged' , 'date_discharged' : time.strftime('%Y-%m-%d %H:%M:%S')})
        patient_data = self.read(cr, uid, ids, ['name'])[0]
        patient_id = patient_data['name'][0]
        discount_id = self.pool.get('res.partner').browse(cr, uid, patient_id).disc_id.id
        if discount_id:
            pricelist_id = self.pool.get('his.discounts').browse(cr, uid, discount_id).pricelist_id
        else:
            pricelist_id = self.pool.get('product.pricelist').search(cr, uid, [('pricelist_group','=','outpay')])[0]
        self.pool.get('res.partner').write(cr, uid, patient_id, { 'property_product_pricelist': pricelist_id, 'admitted' : False, 'admission_id' : False })
        
        his_room_tranfer = self.pool.get('his.room.transfer')
        count_room = his_room_tranfer.search(cr, uid, [('id','>',0), ('admission_id','=',ids), ('t_out','=',False)])
        if count_room:
            room_tranfer = his_room_tranfer.browse(cr, uid, count_room[0])
            bed_id = room_tranfer.bed_no.id
            room_tranfer_id = room_tranfer.id
            self.pool.get('his.bed').write(cr, uid, bed_id, { 'state' : 'For Cleaning' })
            his_room_tranfer.write(cr, uid, room_tranfer_id, { 'ward_count' : False, 'discharge_count' : True, 't_out' : True, 'date_out' : time.strftime('%Y-%m-%d %H:%M:%S') })
        return True        

    def patient_cancel(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'state' : 'Cancelled' })
        patient_data = self.read(cr, uid, ids, ['name'])[0]
        patient_id = patient_data['name'][0]
        self.pool.get('res.partner').write(cr, uid, patient_id, { 'admitted' : False })
        return True
    
    def unlink(self, cr, uid, ids, context=None):
        for rec in self.browse(cr, uid, ids, context=context):
            if rec.state not in ('Draft','Cancelled'):
                raise osv.except_osv(_('Unable to Delete !'), _('In order to delete a record, it must be draft or cancelled.'))
        return super(his_admission_class, self).unlink(cr, uid, ids, context=context)
        
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        vals['state'] = 'Draft'
        vals['unlocked'] = False
        vals['admission_no'] = self.pool.get('ir.sequence').get(cr, uid, 'patient.admission.id')
        name = vals.get('name')
        res_partner = self.pool.get('res.partner').browse(cr, uid, name)
        admission_id = self.search(cr, uid, [('name','=',name), ('state','=','Admitted')])
        if admission_id:
            admission = self.browse(cr, uid, admission_id[0])
            department_name = admission.department_id.name
            taken_by= admission.data_taken_by.name
        admitted = res_partner.admitted
        whole_name = res_partner.whole_name
        ref = res_partner.ref
        if admitted == True:
            warn_msg = "Warning \n\n Case No.: " + ref + "\nName: " + whole_name + "\n\n This patient is already admitted\nat "+ department_name +"\nby "+ taken_by +"."
            result = {'value':{'name':''}, 'warning':{'title':'Warning', 'message':warn_msg}}
            return result
        return super(his_admission_class, self).create(cr, uid, vals, context)
        
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        patient_data = self.read(cr, uid, ids, ['name', 'state','for_transfer','date_admitted'])[0]
        patient_id = patient_data['name'][0]
        state = patient_data['state']
        if patient_data['for_transfer'] == "Unlocked":
            vals['unlocked'] = False
            vals['for_transfer'] = False
        if state != "Draft":
            if vals.get('charity') == True:
                self.pool.get('res.partner').write(cr, uid, patient_id, { 'charity' : True })
            elif vals.get('charity') == False:
                self.pool.get('res.partner').write(cr, uid, patient_id, { 'charity' : False })
                
        if vals.get('class_type'):
            class_type = vals.get('class_type')
            ss_class_id = self.pool.get('his.social_services_class').search(cr, uid, [('id','=',class_type)])
            ss_class_credit = self.pool.get('his.social_services_class').browse(cr, uid, ss_class_id[0]).with_credit
            self.pool.get('res.partner').write(cr, uid, patient_id, { 'with_credit' : ss_class_credit })
            
        if state == "Outpatient":
            #result = {'value':{'date_discharged':date_admitted, 'backlogs':True}}
            vals['date_discharged'] = patient_data['date_admitted']
        
        return super(his_admission_class, self).write(cr, uid, ids, vals, context=context)
    
    def admission_transfer(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'for_transfer' : 'For Admission Transfer'})
        return True
    
    def accept_transfer(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res={}
        res_users = self.pool.get('res.users').browse(cr, uid, uid)
        user_id = res_users.id
        
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        
        user_dept = employee.browse(cr, uid, employee_id[0]).department_id.id
        department_group = employee.browse(cr, uid, employee_id[0]).department_id.dept_group
        
        state = 'Admitted'
        pricelist_group = "outpay"
        if department_group == 'DEMS' or department_group == 'OB-AS':
            status = 'Not in Ward'
            pricelist_group = "b"
        elif department_group == 'OPD':
            state = 'Outpatient'
            status = False
        elif department_group == 'DPPS':
            status = 'Inpatient'
        user_designation = employee.browse(cr, uid, employee_id[0]).job_id.id
        charity = employee.browse(cr, uid, employee_id[0]).department_id.charity
        
        if charity == False:
            class_type_id = self.pool.get('his.social_services_class').search(cr, uid, [('pay','=',True)])
        else:
            class_type_id = self.pool.get('his.social_services_class').search(cr, uid, [('charity','=',True)])
        ss_type = class_type_id[0]
        self.write(cr, uid, ids, {'state': state,'status': status,'department_group': department_group,'for_transfer' : False, 'disc_type':'', 'clinic_id':'', 'class_type' : ss_type, 'data_taken_by' : user_id, 'department_id' : user_dept, 'designation' : user_designation, 'charity' : charity})
        return True
        
    def cancel_transfer(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr, uid, ids, { 'for_transfer' : False})
        return True
        
    def _get_user(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        return res_users.browse(cr, uid, uid).id
        
    def _get_user_department(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        return employee.browse(cr, uid, employee_id[0]).department_id.id
    
    def _get_department_group(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        return employee.browse(cr, uid, employee_id[0]).department_id.dept_group
        
    def _get_user_designation(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        return employee.browse(cr, uid, employee_id[0]).job_id.id
        
    def _get_user_charity_department(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        return employee.browse(cr, uid, employee_id[0]).department_id.charity
    
    def _get_ss_class(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        charity = employee.browse(cr, uid, employee_id[0]).department_id.charity
        if charity == False:
            class_type_id = self.pool.get('his.social_services_class').search(cr, uid, [('pay','=',True)])[0]
        else:
            class_type_id = self.pool.get('his.social_services_class').search(cr, uid, [('charity','=',True)])[0]
        result = class_type_id
        return result
        
    _defaults = {
        'state': 'New',
        'data_taken_by' : _get_user,
        'designation' : _get_user_designation,
        'department_id' : _get_user_department,
        'charity' : _get_user_charity_department,
        'class_type' : _get_ss_class,
        'department_group' : _get_department_group,
    }

his_admission_class ()

class res_partner_custom(osv.osv):

    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'name', 'Patient Admission ID'),
        'charity' : fields.boolean ('Charity'),
        'admitted' : fields.boolean ('Admitted'),
        'admission_id' : fields.integer ('Admission ID'),
    }
    
    _defaults = {
        'charity' : lambda * a: False,
        'admitted' : lambda * a: False,
    }

res_partner_custom ()

class pos_order_line_custom(osv.osv):

    _name = "pos.order.line"
    _inherit = "pos.order.line"
    _columns = {
        'admission_id': fields.many2one('his.admission', 'Admission ID'),
    }

pos_order_line_custom ()

class his_clinics_custom(osv.osv):

    _name = "his.clinics"
    _inherit = "his.clinics"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'clinic_id', 'Patient Admission ID'),
    }

his_clinics_custom ()

class hr_department_custom(osv.osv):

    _name = "hr.department"
    _inherit = "hr.department"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'department_id', 'Patient Admission ID'),
    }

hr_department_custom ()

class res_users_custom(osv.osv):

    _name = "res.users"
    _inherit = "res.users"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'data_taken_by', 'Patient Admission ID'),
    }

res_users_custom ()

class hr_job_custom(osv.osv):

    _name = "hr.job"
    _inherit = "hr.job"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'designation', 'Patient Admission ID'),
    }

hr_job_custom ()

class his_discounts_custom(osv.osv):

    _name = "his.discounts"
    _inherit = "his.discounts"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'disc_type', 'Patient Admission ID'),
    }

his_discounts_custom ()

class his_social_services_class_custom(osv.osv):

    _name = "his.social_services_class"
    _inherit = "his.social_services_class"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'class_type', 'Patient Admission ID'),
    }

his_social_services_class_custom ()

class product_pricelist_custom(osv.osv):

    _name = "product.pricelist"
    _inherit = "product.pricelist"
    _columns = {
        'pricelist_group' : fields.selection ([('a_ward','Type A - Ward'), 
                                               ('a_semi','Type A - Semi Private'), 
                                               ('a_private','Type A - Private'), 
                                               ('a_suite','Type A - Suite'),
                                               ('b','Type B'),
                                               ('c','Type C'),
                                               ('d','Type D'),
                                               ('outpay','Outpay')],'Pricelist Group'),
    }

product_pricelist_custom ()

class his_icd10_code_custom(osv.osv):

    _name = "medical.pathology"
    _inherit = "medical.pathology"
    _columns = {
        'patient_admission_id' : fields.one2many ('his.admission', 'final_diag_icd', 'Patient Admission ID'),
    }

his_icd10_code_custom ()

