import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class his_room_transfer(osv.osv):

    _name = "his.room.transfer"
    _columns = {
        'admission_id' : fields.many2one ('his.admission', 'Admission ID'),
        'ward_no' : fields.many2one ('his.ward', 'Ward Name'),
        'ward_no2' : fields.many2one ('his.ward', 'Ward Name'),
        'bed_no' : fields.many2one ('his.bed', 'Bed No.', domain="[('bed_no','=',ward_no), ('state','=','Vacant')]"),
        'date_in' : fields.datetime ('Date/Time-in', readonly=True),
        'date_out' : fields.datetime ('Date/Time-out', readonly=True),
        't_in' : fields.boolean ('Transfer-in', readonly=True),
        't_out' : fields.boolean ('Transfer-out', readonly=True),
        'ward_count' : fields.boolean ('Ward Count', readonly=True),
        'admit_count' : fields.boolean ('Admit Count', readonly=True),
        'discharge_count' : fields.boolean ('Discharge Count', readonly=True),
        'dept_name' : fields.many2one ('hr.department','Department', readonly=True),
        'locked' : fields.boolean ('Locked'),
    }
    def onchange_ward_no(self, cr, uid, ids, ward_no, context=None):
        result = {'value':{'bed_no':False}}
        return result
            
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        admission_id = vals.get('admission_id')
        vals['dept_name'] = self.pool.get('his.admission').browse(cr, uid, admission_id).department_id.id
        ward_id_new = vals.get('ward_no')
        ward_id_new2 = vals.get('ward_no2')
        bed_id_new = vals.get('bed_no')
        count_room = self.search(cr, uid, [('admission_id','=',admission_id)], count=True)
        vals['ward_count'] = True
        if count_room > 0:
            count_config = self.search(cr, uid, [('id','>',0), ('admission_id','=',admission_id)])
            sorted_id = sorted(count_config,reverse=True)
            room_tranfer = self.browse(cr, uid, sorted_id[0])
            room_tranfer_id = room_tranfer.id
            t_out = room_tranfer.t_out
            bed_id = room_tranfer.bed_no.id
            ward_id = room_tranfer.ward_no.id
            ward_id2 = room_tranfer.ward_no2.id
            if ward_id_new == ward_id or ward_id_new2 == ward_id2:
                if ward_id:
                    vals['ward_count'] = False
                    #raise osv.except_osv(_('Warning'), _("This patient is already in %s.") %(room_tranfer.ward_no.name))
                else:
                    raise osv.except_osv(_('Warning'), _("This patient is already in %s.") %(room_tranfer.ward_no2.name))
            his_bed = self.pool.get('his.bed')
            his_bed.write(cr, uid, bed_id, { 'state' : 'For Cleaning' })
            if t_out == False:
                self.write(cr, uid, room_tranfer_id, { 't_out' : True, 'date_out' : time.strftime('%Y-%m-%d %H:%M:%S') })
            vals['t_in'] = True
            his_bed.write(cr, uid, bed_id_new, { 'state' : 'Occupied' })
        else:
            vals['ward_count'] = False
            vals['admit_count'] = True
            self.pool.get('his.bed').write(cr, uid, bed_id_new, { 'state' : 'Occupied' })
        return super(his_room_transfer, self).create(cr, uid, vals, context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if vals.get('bed_no'):
            bed_id_new = vals.get('bed_no')
            bed_id_old = self.browse(cr, uid, ids[0]).bed_no.id
            his_bed = self.pool.get('his.bed')
            his_bed.write(cr, uid, bed_id_old, { 'state' : 'For Cleaning' })
            his_bed.write(cr, uid, bed_id_new, { 'state' : 'Occupied' })
        return super(his_room_transfer, self).write(cr, uid, ids, vals, context=context)
        
    _defaults = {
        'date_in' : lambda * a: time.strftime('%Y-%m-%d %H:%M:%S'), 
        'locked' : lambda * a: True,    
    }
    
    _order = "id desc" 
    
his_room_transfer ()

class his_ward_custom(osv.osv):

    _name = "his.ward"
    _inherit = "his.ward"
    _columns = {
        'his_room_transfer_id' : fields.one2many ('his.room.transfer', 'ward_no', 'Room Transfer ID'),
        'his_room_transfer_id2' : fields.one2many ('his.room.transfer', 'ward_no2', 'Room Transfer ID'),
    }

his_ward_custom ()

class his_bed_custom(osv.osv):

    _name = "his.bed"
    _inherit = "his.bed"
    _columns = {
        'his_room_transfer_id' : fields.one2many ('his.room.transfer', 'bed_no', 'Room Transfer ID'),
    }

his_ward_custom ()
    
