import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class white_card_config(osv.osv):

    _name = "white.card.config"
    _description = "White Card Configuration"
        
    _columns = {
        'amount' : fields.float ('Amount'),
        'date' : fields.date ('Date', readonly=True),
    }
    
    _defaults = {
        'date': lambda * a: time.strftime('%Y-%m-%d'),
    }
    
    _order = "id desc"
white_card_config ()
