{

    'name' : 'White Card Management',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['account', 'hospital_mgmt', 'his_admission'],
    'description' : """

White Card Management

""",
	"website" : "http://www.fossibility.com",
	"init_xml" : [],
	"update_xml" : ["white_card_mgmt_view.xml", "config_view.xml"],
	"active": False 
}
