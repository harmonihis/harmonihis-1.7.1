import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class white_card_management(osv.osv):

    _name = "white.card"
    _description = "White Card"
    
    def _date_expire(self, cr, uid, ids, field_list, arg, context=None):
        res = {}

        for line in self.browse(cr, uid, ids):
            date_select = line.date_issued
            date_select = date_select.split('-')
            date_select = str(int(date_select[0]) + 1)+ '-' + date_select[1]  + '-' + date_select[2]
            res[line.id] = date_select
        return res
        
    def _state(self, cr, uid, ids, field_list, arg, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
            date_expire = line.date_expire
            balance = line.balance
            date_expire = date_expire.split('-')
            date_year = int(date_expire[0])
            date_month = int(date_expire[1])
            date_day = int(date_expire[2])
            if date_year < int(time.strftime('%Y')) or (date_year == int(time.strftime('%Y')) and date_month < int(time.strftime('%m'))) or (date_year == int(time.strftime('%Y')) and date_month == int(time.strftime('%m')) and date_day < int(time.strftime('%d'))):
                _state = "Expired"
                self.write(cr, uid, line.id, { 'active' : False })
            elif balance == 0.0:
                _state = "Zero Credits"
                self.write(cr, uid, line.id, { 'active' : False })
            else:
                _state = "Active"
                #self.write(cr, uid, line.id, { 'active' : True })  
            res[line.id] = _state
        return res
        
    _columns = {
        'card_number' : fields.char ('White Card No.', size=15, required="1"),
        'name' : fields.many2one ('res.partner', 'Patient Name', required="1"),
        'date_issued' : fields.date ('Date Issued'),
        'date_expire' : fields.function (_date_expire, method=True, string='Expiry Date', type="date"),
        'amount' : fields.float ('Pharmacy Credit Limit', readonly=True),
        'balance' : fields.float ('Current Balance', readonly=True),
        'state' : fields.function (_state, method=True, fnct_search=None, string="State", type="char", size=30),
        'active' : fields.boolean ('Active'),
    }
    
    def onchange_calculer(self, cr, uid, ids, date_issued):     
        date_select = date_issued
        date_select = date_select.split('-')
        date_select = str(int(date_select[0]) + 1)+ '-' + date_select[1]  + '-' + date_select[2]
        return {'value': {'date_expire': date_select}}
        
    def onchange_patient_name(self, cr, uid, ids, name):
        his_admission = self.pool.get('his.admission')
        admission_id = his_admission.search(cr, uid, [('name','=',name), ('state','=','Admitted')])
        with_credit = his_admission.browse(cr, uid, admission_id[0]).class_type.with_credit
        amount = 0.00
        if with_credit == True:
            amount_config = self.pool.get('white.card.config')
            count_config = amount_config.search(cr, uid, [('id','>',0)])
            sorted_id = sorted(count_config,reverse=True)
            amount = amount_config.browse(cr, uid, sorted_id[0]).amount
        return {'value': {'amount': amount, 'balance': amount}}
    
    def create(self, cr, uid, vals, context=None):
        patient_id = vals['name']
        count_config = self.search(cr, uid, [('name','=',patient_id),('active','=',True)], count=True)
        if count_config > 0:
            raise osv.except_osv(_('Warning:'),_("Only one(1) active white card is allowed for every admitted patient."))
        else:
            his_admission = self.pool.get('his.admission')
            admission_id = his_admission.search(cr, uid, [('name','=',patient_id), ('state','=','Admitted')])
            with_credit = his_admission.browse(cr, uid, admission_id[0]).class_type.with_credit
            amount = 0.00
            if with_credit == True:
                amount_config = self.pool.get('white.card.config')
                count_config = amount_config.search(cr, uid, [('id','>',0)])
                sorted_id = sorted(count_config,reverse=True)
                amount = amount_config.browse(cr, uid, sorted_id[0]).amount
            vals['amount'] = amount
            vals['balance'] = amount
            return super(white_card_management, self).create(cr, uid, vals, context)
 
    _defaults = {
        #'amount': _default_amount,
        #'balance': _default_amount,
        'date_issued': lambda * a: time.strftime('%Y-%m-%d'),
        'active': lambda * a: True,
    }

white_card_management ()

class res_partner_custom(osv.osv):

    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'white_cards' : fields.one2many ('white.card', 'name', 'Patient Name'),
    }

res_partner_custom ()
