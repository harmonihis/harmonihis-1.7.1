import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class res_partner_custom(osv.osv):

    _name = "res.partner"
    _inherit = "res.partner"
    
    def get_whole_name(self, cr, uid, ids, field_name, arg, context):
        whole_name = {}
        for line in self.browse(cr, uid, ids ,context):
            if line.fname == False:
                fname = ''
            else:
                fname = ', ' + line.fname
            if line.mname == False:
                mname = ''
            else:
                mname = ' ' + line.mname
            whole_name[line.id] = str(line.name) + fname + mname
        return whole_name
        
    def get_maiden_name(self, cr, uid, ids, field_name, arg, context):
        maiden_name = {}
        for line in self.browse(cr, uid, ids ,context):
            if line.gender == 'FEMALE':
                if line.fname == False:
                        fname = ''
                else:
                    fname = ', ' + line.fname
                if line.status == 'SINGLE':
                    if line.mname == False:
                        mname = ''
                    else:
                        mname = ' ' + line.mname
                    maiden_name[line.id] = str(line.name) + fname + mname
                else:
                    if line.mname == False:
                        mname = ''
                    else:
                        mname = line.mname
                    maiden_name[line.id] = mname + fname
            else:
                maiden_name[line.id] = False
        return maiden_name
        
    def _age(self, cr, uid, ids, name, arg, context={}):
        result={}
        for patient_data in self.browse(cr, uid, ids, context=context):
            result[patient_data.id] = self.compute_age_from_dates (patient_data.his_birthdate)
        return result
        
    def compute_age_from_dates (self, patient_dob):
        now=datetime.now()
        if (patient_dob):
            dob=datetime.strptime(patient_dob,'%Y-%m-%d')
            delta=relativedelta (now, dob)
            years_months_days = str(delta.years) +"y "+ str(delta.months) +"m "+ str(delta.days)+"d"
        else:
            years_months_days = "No Birthdate!"
        return years_months_days
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['ref','name','fname','mname','his_birthdate','donor'], context=context)
        res = []
        for record in reads:
            if record['his_birthdate'] == False:
                bday = ''
            else:
                if record['ref'] == False:
                    bday = ''
                else:
                    dob = record['his_birthdate'].split('-')
                    bday = ' - ' + dob[1]  + '/' + dob[2] + '/' + dob[0]
            if record['fname'] == False:
                fname = ''
            else:
                fname = ', ' + record['fname']
            if record['mname'] == False:
                mname = ''
            else:
                mname = ' ' + record['mname']
            if record['ref'] == False:
                ref = ''
            else:
                ref = "[" + record['ref'] + "] "
            
            if record['donor'] == True:
                name = record['name'] + fname + mname
            else:   
                name = ref + record['name'] + fname + mname + bday
            res.append((record['id'], name))
        return res

    def _spouse_address(self, cr, uid, ids, field_name, arg, context):
        spouse_address = {}
        for line in self.browse(cr, uid, ids ,context):
            if str(line.spouse) == '':
                spouse_address[line.id] = ''
            else:
                res_partner_address_id = self.search(cr, uid, [('id','=',line.spouse.id)])
                partner_address = self.browse(cr, uid, res_partner_address_id[0])
                if partner_address.street == False:
                    street = ''
                else:
                    street = partner_address.street
                if partner_address.street2 == False:
                    street2 = ''
                else:
                    street2 = partner_address.street2
                if partner_address.city == False:
                    city = ''
                else:
                    if partner_address.street == False:
                        city = partner_address.city
                    else:
                        city = ', ' + partner_address.city
                if str(partner_address.state_id) == '':
                    province = ''
                else:
                    if partner_address.city == False:
                        province = partner_address.state_id.name
                    else:
                        province = ', ' + partner_address.state_id.name
                if str(partner_address.country_id) == '':
                    country = ''
                else:
                    if str(partner_address.state_id) == '':
                        country = partner_address.country_id.name
                    else:
                        country = ', ' + partner_address.country_id.name
                spouse_address[line.id] = street + street2 + city + province + country
        return spouse_address
        
    _columns = {
        'fname' : fields.char ('Firstname', size=50, required=True),
        'mname' : fields.char ('Middlename', size=50),
        'whole_name' : fields.function (get_whole_name, method=True, fnct_search=None, string="Name", type="char", size=150, store=True),
        'maiden_name' : fields.function (get_maiden_name, method=True, fnct_search=None, string="Maiden Name", type="char", size=150, store=True),
        'phone_no' : fields.char ('Phone No.', size=15),
        'gender' : fields.selection ([('MALE','Male'), ('FEMALE','Female')],'Gender'),
        'status' : fields.selection ([('SINGLE','Single'), ('MARRIED','Married'), ('SEPARATED','Separated'), ('DIVORCED','Divorced'), ('WIDOW','Widowed')],'Civil Status'),
        'his_birthdate' : fields.date ('Birthdate(mm/dd/yyyy)'),
        'age' : fields.function (_age, method=True, fnct_search=None, string="Age", type="char", size= 50,readonly=True),
        'birthplace' : fields.char ('Birthplace', size=100),
        'nationality' : fields.char ('Nationality', size=20),
        'religion' : fields.char ('Religion', size=20),
        'educ_attain' : fields.char ('Educ. Attain.', size=20),
        'occupation' : fields.char ('Occupation', size=20),
        'sss_member' : fields.boolean ('SSS Member'),
        'sss_no' : fields.char ('SSS No.', size=20),
        'gsis_member' : fields.boolean ('GSIS Member'),
        'gsis_no' : fields.char ('GSIS No.', size=20),
        'phic' : fields.selection ([('None','None'), ('Member','Member'), ('Dependent','Dependent')],'PHIC'),
        'phic_no' : fields.char ('PHIC No.', size=20),
        'phic_sponsor_name' : fields.many2one ('res.partner', 'PHIC Sponsor', domain=[('customer', '=', 1), ('phic', '=', 'Member')]),
        'phic_sponsor_id' : fields.one2many ('res.partner', 'phic_sponsor_name', 'PHIC Sponsor'),
        'bus_name' : fields.char ('Name', size=100),
        'bus_address' : fields.char ('Address', size=200),
        'bus_phone_no' : fields.char ('Phone No.', size=15),
        'mother' : fields.many2one ('res.partner', 'Mother\'s Name', domain=[('customer', '=', 1)]),
        'mother_id' : fields.one2many ('res.partner', 'mother', 'Mother\'s Name'),
        'father' : fields.many2one ('res.partner', 'Father\'s Name', domain=[('customer', '=', 1)]),
        'father_id' : fields.one2many ('res.partner', 'father', 'Father\'s Name'),
        'spouse' : fields.many2one ('res.partner', 'Spouse\'s Name', domain=[('customer', '=', 1)]),
        'spouse_id' : fields.one2many ('res.partner', 'spouse', 'Spouse\'s Name'),
        'spouse_address' : fields.function (_spouse_address, method=True, fnct_search=None, string="Address", type="char", size= 200,readonly=True),
        'spouse_empl' : fields.char ('Employer', size=100),
        'spouse_empl_address' : fields.char ('Address of Employer', size=200),
        'spouse_empl_phone_no' : fields.char ('Phone No. of Employer', size=15),
        'with_credit' : fields.boolean ('With White Card Credit'),
        'disc_id' : fields.many2one ('his.discounts', 'Discount Type'),
        'disc_card_id' : fields.char ('Discount ID', size=32),
        'hmo' : fields.selection ([('None','None'), ('Member','Member'), ('Dependent','Dependent')],'HMO'),
        'hmo_id' : fields.many2one ('res.partner', 'HMO Partner', domain=[('hmo_partner', '=', 1)]),
        'hmo_no' : fields.char ('HMO ID No.', size=20),
        'hmo_principal' : fields.many2one ('res.partner', 'Principal', domain=[('customer', '=', 1)]),
        'patient' : fields.boolean ('Patient'),
    }
    
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        #raise osv.except_osv(_('Warning :'), _("%s") %(pricelist_id))
        if type(ids) is dict or type(ids) is list:
            #patient_data = self.read(cr, uid, ids, ['name', 'admitted'])[0]
            #patient_id = patient_data['name'][0]
            #admitted = patient_data['admitted']
            admitted = self.browse(cr, uid, ids[0]).admitted
            
            if vals.get('disc_id') and admitted != True:
                discount_id = vals['disc_id']
                pricelist_id = self.pool.get('his.discounts').browse(cr, uid, discount_id).pricelist_id
                #raise osv.except_osv(_('Warning :'), _("%s") %(pricelist_id))
                vals['property_product_pricelist'] = pricelist_id
            
        return super(res_partner_custom, self).write(cr, uid, ids, vals, context=context)
    
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        partner_id = super(res_partner_custom, self).create(cr, uid, vals, context)
        if self.browse(cr, uid, partner_id).patient == True:
            if vals.get('disc_id'):
                discount_id = vals['disc_id']
                pricelist_id = self.pool.get('his.discounts').browse(cr, uid, discount_id).pricelist_id
                vals['property_product_pricelist'] = pricelist_id
            
            if vals.get('street'):
                street = vals['street']
            else:
                street = False
                
            if vals.get('street2'):
                street2 = vals['street2']
            else:
                street = False
                
            if vals.get('city'):
                city = vals['city']
            else:
                city = False
            
            if vals.get('state_id'):
                province = vals['state_id']
            else:
                province = False
                
            if vals.get('country_id'):
                country = vals['country_id']
            else:
                country = False
                
            if vals.get('father') > 0:
                father = vals['father']
                res_partner_address_id = self.search(cr, uid, [('id','=',father)])
                partner_address = self.browse(cr, uid, res_partner_address_id[0])
                if partner_address.street == False and partner_address.street2 == False and partner_address.city == False and str(partner_address.state_id) == '' and partner_address.country_id.id == country:
                    self.write(cr, uid, res_partner_address_id, { 'street' : street, 'street2' : street2, 'city' : city, 'state_id' : province, })
            
            if vals.get('mother') > 0:
                mother = vals['mother']
                res_partner_address_id = self.search(cr, uid, [('id','=',mother)])
                partner_address = self.browse(cr, uid, res_partner_address_id[0])
                if partner_address.street == False and partner_address.street2 == False and partner_address.city == False and str(partner_address.state_id) == '' and partner_address.country_id.id == country:
                    self.write(cr, uid, res_partner_address_id, { 'street' : street, 'street2' : street2, 'city' : city, 'state_id' : province, })
            
            if vals.get('spouse') > 0:
                spouse = vals['spouse']
                res_partner_address_id = self.search(cr, uid, [('id','=',spouse)])
                partner_address = self.browse(cr, uid, res_partner_address_id[0])
                if partner_address.street == False and partner_address.street2 == False and partner_address.city == False and str(partner_address.state_id) == '' and partner_address.country_id.id == country:
                    self.write(cr, uid, res_partner_address_id, { 'street' : street, 'street2' : street2, 'city' : city, 'state_id' : province, })
        return partner_id
        
    def onchange_sss_member(self, cr, uid, ids, sss_member, context=None):
        result = {'value':{'sss_no':''}}
        return result
        
    def onchange_gsis_member(self, cr, uid, ids, gsis_member, context=None):
        result = {'value':{'gsis_no':''}}
        return result
        
    def onchange_phic(self, cr, uid, ids, phic, context=None):
        if phic == False:
            result = {'value':{'phic_no':'', 'phic_sponsor_name':'', 'phic':'None'}}
        else:
            result = {'value':{'phic_no':'', 'phic_sponsor_name':''}}
        return result
    
    _defaults = {
        'his_birthdate': lambda * a: time.strftime('%Y-%m-%d'),
        'phic': lambda * a: 'None',
        'with_credit': lambda * a: False,
    }

res_partner_custom ()
