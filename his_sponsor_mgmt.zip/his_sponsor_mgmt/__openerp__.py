{

    'name' : 'Sponsor Management',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['account', 'hospital_mgmt'],
    'description' : """

Sponsor Management

""",
        "website" : "http://www.fossibility.com",
        "init_xml" : [],
        "update_xml" : ["his_sponsor_mgmt_view.xml"],
        "active": False 
}
