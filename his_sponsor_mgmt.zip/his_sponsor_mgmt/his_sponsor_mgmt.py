import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

class res_partner_custom(osv.osv):

    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'donor' : fields.boolean ('Sponsor'),
        'sponsor_id' : fields.one2many ('his.sponsored.patients','name','Sponsor ID'),
    }

res_partner_custom ()

class his_sponsored_patients(osv.osv):

    _name = "his.sponsored.patients"
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['name'], context=context)
        res = []
        for record in reads:
            name = self.pool.get('res.partner').browse(cr, uid, record['name'][0], context=context).whole_name
            res.append((record['id'], name))
        return res
    
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        credit_limit = vals.get('credit_limit')
        vals['balance'] = credit_limit
        return super(his_sponsored_patients, self).create(cr, uid, vals, context)
        
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        sponsored_patient = self.read(cr, uid, ids, ['credit_limit', 'balance'])[0]
        credit_limit = sponsored_patient['credit_limit']
        balance = sponsored_patient['balance']
        
        if vals.get('credit_limit'):
            
            credit_limit_new = vals.get('credit_limit')
            balance = balance + (credit_limit_new - credit_limit)
            if balance >= 0:
                vals['balance'] = balance
            else:
                raise osv.except_osv(_('Warning'),_('%s') % ("Balance will become lesser than zero(0)."))
        return super(his_sponsored_patients, self).write(cr, uid, ids, vals, context=context)
        
    _columns = {
        'name' : fields.many2one ('res.partner', 'Sponsor\'s Name'),
        'sponsored_patient_name' : fields.many2one ('res.partner', 'Patient\'s Name', domain=[('customer', '=', 1)]),
        'credit_limit' : fields.float ('Credit Limit', required=True),
        'balance' : fields.float ('Balance', readonly=True),
        'state' : fields.boolean ('Active'),
    }
    
    _defaults = {
        'state': lambda * a: True
    }

his_sponsored_patients ()
