import his_sponsor_mgmt
