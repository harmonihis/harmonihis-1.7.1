from osv import fields, osv
import time

class search_product(osv.osv):
	_name = "search_product"
	_description = "Search Products"
	_columns = {
                'brand' : fields.many2one('product.product', 'brand'),
		'name' : fields.many2one('product.template', 'name', size=30, required=True),
                'dosage' : fields.many2one('product.product', 'dosage'),
		'qty_available' : fields.many2one('product.template', 'seller_qty'),
		'lst_price' : fields.many2one('product.template', 'list_price'),
	}
	
search_product()

