{
	"name" : "Product Finder",
	"version" : "3.0",
	"author" : "Jaynar L. Santos",
	"website" : "http://www.fossibility.com",
	"category" : "Generic Modules/Others",
	"depends" : ["base", "product"],
	"description" : "Simple module to search products",
	"init_xml" : [],
	"demo_xml" : [],
	"update_xml" : ["product_finder_view.xml", "security/product_finder_security.xml"],
	"active": False,
	"installable": True
}
