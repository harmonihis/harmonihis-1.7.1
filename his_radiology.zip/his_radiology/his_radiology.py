##############################################################################
#
#    Harmoni HIS
#    Copyright (C) 2013 onwards Electronic Health Records International (<http://ehrinternational.com>).
#    By: Edwin N. Gonzales, EHRI-CTO and Jaynar L. Santos, EHRI-Senior Programmer
#    All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import time
from mx import DateTime
import datetime
from osv import fields, osv
from tools.translate import _
import math

# Add rad exam information to the Patient object

class patient_data_rad (osv.osv):
    _name = "res.partner"
    _inherit = "res.partner"
    _columns = {
        'rad_exam_ids': fields.one2many('his.rad.exam','patient_id','rad exams Required'),
    }

patient_data_rad ()

class exam_type (osv.osv):
    _name = "his.rad.exam_type"
    _description = "Type of Radiology Examination"
    _columns = {
        'name' : fields.char ('Examination Type',size=128),
        'code' : fields.char ('Code',size=128,help="Short name - code for the exam"),
        'rad_section_id': fields.many2one('his.department.section','Rad Section', domain="[('hr_department_id.section_group','=','Radiology')]"),
        'info' : fields.text ('Description'),
        'product_id' : fields.many2one('product.product', 'Service', required=True, domain="[('type','=','service')]"),
        #'critearea': fields.one2many('his.rad.exam_critearea','exam_type_id','exam Cases'),
    }

    _sql_constraints = [
                ('code_uniq', 'unique (name)', 'The rad exam Name must be unique')]

exam_type ()

class rad (osv.osv):
    _name = "his.rad"
    _description = "rad exam"
    _columns = {
        'name' : fields.char ('ID', size=128, help="Radiology Result ID"),
        'exam' : fields.many2one ('his.rad.exam_type', 'Examination Type', help="Examination Type"),
        'patient' : fields.many2one ('res.partner', 'Patient', help="Patient ID", domain=    "[('customer','=',True)]"),
        'staff' : fields.many2one ('hr.employee','staff',help="staff", domain="[('doctor','=',True)]"),
        'requestor' : fields.many2one ('hr.employee', 'Physician', help="Doctor who requested the exam", domain="[('doctor','=',True)]"),
        'results' : fields.text ('Results'),
        'diagnosis' : fields.text ('Diagnosis'),
        #'critearea': fields.one2many('his.rad.exam_critearea','his_rad_id','exam Cases'),
        'date_requested' : fields.datetime ('Date Requested'),
        'date_analysis' : fields.datetime ('Date of the Analysis'),
        #'specimen' : fields.char ('Specimen', size=128,),
        #'collection_site' : fields.char ('Site of Collection', size=128,),
        #'collected_by' : fields.char ('Collected By', size=128,),
        #'date_collected' : fields.datetime ('Date and Time Collected'),
        #'date_received' : fields.datetime ('Date and Time Received'),
        #'received_by' : fields.char ('Recived By', size=128,),
        #'rad_info_no' : fields.char ('rad Info No.', size=128,),
    }

    _defaults = {
        'date_requested': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'date_analysis': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        #'date_collected': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        #'date_received': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'name' : lambda obj, cr, uid, context: obj.pool.get('ir.sequence').get(cr, uid, 'his.rad'),
    }

    _sql_constraints = [
                ('id_uniq', 'unique (name)', 'The exam ID code must be unique')]
rad ()

class rad_exam_units(osv.osv):
    _name = "his.rad.exam.units"
    _description = "rad exam Units"
    _columns = {
        'name' : fields.char('Unit', size=25),
        'code' : fields.char('Code', size=25),
        }
    _sql_constraints = [
            ('name_uniq', 'unique(name)', 'The Unit name must be unique')]

rad_exam_units()
############################
#class rad_exam_critearea(osv.osv):
#    _name = "his.rad.exam_critearea"
#    _description = "rad Examination Critearea"
#    _columns ={
#       'name' : fields.char('Examination', size=64),
#       'result' : fields.text('Result'),
#       'normal_range' : fields.text('Normal Range'),
#       'units' : fields.many2one('his.rad.exam.units', 'Units'),
#       'exam_type_id' : fields.many2one('his.rad.exam_type','Examination Type'),
#       'his_rad_id' : fields.many2one('his.rad','Examination Cases'),
#       'sequence' : fields.integer('Sequence'),
#       }
#    _defaults = {
#         'sequence' : lambda *a : 1,
#         }
#    _order="sequence"
#rad_exam_critearea()
########################


class his_patient_rad_exam(osv.osv):
    _name = 'his.patient.rad.exam'
    
    def onchange_name(self, cr, uid, ids, name, pricelist_id, patient_id):

        val = {}
        service_id = self.pool.get('his.rad.exam_type').browse(cr, uid, name, context=None).product_id.id
        price = self.pool.get('product.pricelist').price_get(cr, uid, [pricelist_id],
                service_id, 1.0, patient_id)[pricelist_id]
        #raise osv.except_osv(_('Debug !'),_('Patient ID %s') % (price))
        return {'value': {'price': price}}
        
    def onchange_charge_to_phic(self, cr, uid, ids, phic_balance, price, charge_to_phic):
        if charge_to_phic == True:
            if phic_balance < price:
                warn_msg = "PHIC Passbook Balance is not enough.\n\n Total Charges: " + str("%.2f" % price) + "\n PHIC Balance: " + str("%.2f" % phic_balance)
                return {'value':{'charge_to_phic':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
            else:
                return {'value': {'charge_to' : False}}
        return True
    
    def onchange_pdaf_balance(self, cr, uid, ids, pdaf_balance, price, charge_to, partner_sponsor_id):
        if pdaf_balance < price and charge_to == True and partner_sponsor_id != False:
            warn_msg = "PDAF Balance is not enough.\n\n Total Charges: " + str("%.2f" % price) + "\n PDAF Balance: " + str("%.2f" % pdaf_balance)
            return {'value':{'partner_sponsor_id':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
        return True
        
    def onchange_charge_to(self, cr, uid, ids, charge_to):
        if charge_to == True:
           return {'value': {'charge_to_phic' : False, 'partner_sponsor_id' : False}}
        return {'value': {'partner_sponsor_id' : False}}
        
    def onchange_partner_sponsor_id(self, cr, uid, ids, partner_sponsor_id, patient_id):
        #if not part:
        #    return {'value': {}}
        pdaf_balance = 0.00
        if patient_id:
            if partner_sponsor_id:
                sponsored_patient = self.pool.get('his.sponsored.patients')
                sponsored_patient_id = sponsored_patient.search(cr, uid, [('sponsored_patient_name', '=', patient_id),('name', '=', partner_sponsor_id), ('state', '=', 1)])
                
                if sponsored_patient_id:
                    pdaf_balance = sponsored_patient.browse(cr, uid, sponsored_patient_id[0], context=None).balance
        
        return {'value': {'pdaf_balance' : pdaf_balance}}
    
    def onchange_patient_id(self, cr, uid, ids, patient):
        if not patient:
            return {'value': {'pricelist_id': False}}

        val = {}
        val['patient_adstatus'] = False
        part = self.pool.get('res.partner').browse(cr, uid, patient)
        phic_passbook = self.pool.get('philhealth.passbook')
        phic_id = phic_passbook.search(cr, uid, [('name','=',patient)])
        val['phic_balance'] = 0.00
        val['with_phic'] = False
        val['with_pdaf'] = False
        if phic_id:
            val['with_phic'] = True
            val['phic_balance'] = self.pool.get('philhealth.passbook').get_phic_passbook_balance(cr, uid, patient, True, bal='xlab')
        
        sponsor_ids = []
        for sponsor in self.pool.get('his.sponsored.patients').search(cr, uid, [('sponsored_patient_name', '=', patient), ('state', '=', 1)]):
            if sponsor:
                val['with_pdaf'] = True
                sponsor_ids.append(self.pool.get('his.sponsored.patients').browse(cr, uid, sponsor, context=None).name.id)
        val['sponsor_ids'] = str(sponsor_ids)
        
        admitted = part.admitted
        val['ward_name'] = False
        val['bed_name'] = False
        if admitted == True:
            admission_id = self.pool.get('his.admission').search(cr, uid, [('name', '=', part.id),('state', '=', "Admitted")])
            val['patient_adstatus'] = True
            room_transfer_id = self.pool.get('his.room.transfer').search(cr, uid, [('admission_id', '=', admission_id[0]),('t_out', '=', False)])
            if room_transfer_id:
                room_transfer = self.pool.get('his.room.transfer').browse(cr, uid, room_transfer_id[0])
                ward=room_transfer.ward_no.name.name
                bed=room_transfer.bed_no.name.name
                val['ward_name'] = ward
                val['bed_name'] = bed
            #raise osv.except_osv(_('Debug !'),_('%s /n %s ') % (ward, bed))

        pricelist = part.property_product_pricelist and part.property_product_pricelist.id or False
        if pricelist:
            val['pricelist_id'] = pricelist
        return {'value': val}


    #def _get_default_dr(self, cr, uid, context={}):
    #    partner_id = self.pool.get('res.partner').search(cr,uid,[('user_id','=',uid)])
    #    if partner_id:
    #        dr_id = self.pool.get('medical.physician').search(cr,uid,[('name','=',partner_id[0])])
    #        if dr_id:
    #            return dr_id[0]
            #else:
            #    raise osv.except_osv(_('Error !'),
            #            _('There is no physician defined ' \
            #                    'for current user.'))
    #    else:
    #        return False
        
    def _get_sponsors(self,cr,uid,ids,field_names,arg,context=None):
        res = {}
        patient_id = self.browse(cr, uid, ids).patient_id.id
        #raise osv.except_osv(_('Debug !'),_('%s') % (patient_id))
        for technical_id in ids:
            cr.execute("SELECT rpe.name FROM his_sponsored_patients rpe "\
            "WHERE rpe.sponsored_patient_name = " + patient_id)
            res[technical_id] = map(lambda x:x[0], cr.fetchall())
        return res
    
    _columns = {
        'lab_section_no': fields.many2one('his.department.section','Rad Section', domain="[('hr_department_id.section_group','=','Radiology')]"),
        'name' : fields.many2one('his.rad.exam_type','Examination Type', domain="[('rad_section_id','=',lab_section_no)]"),
        'date' : fields.datetime('Date'),
        'state' : fields.selection([('draft','Draft'),('examined','Examined'),('cancel','Cancel')],'State',readonly=True),
        'patient_id' : fields.many2one('res.partner','Patient', change_default=True, select=True),
        'partner_patient_id' : fields.many2one('res.partner','Patient'),
        'pricelist_id': fields.many2one('product.pricelist', 'Pricelist', readonly=True, states={'draft': [('readonly', False)]}),
        'doctor_id' : fields.many2one('hr.employee','Doctor', domain="[('doctor','=',True)]", help="Doctor who Request the rad exam."),
        'patient_adstatus' : fields.boolean ('Admitted'),
        #'patient_status': fields.related ('patient_id','admitted',type="boolean",string="Admitted?",store=True, readonly=True),
        'note' : fields.text('Desired Examnation:'),
        'impression' : fields.text('Complete Clinical Impression:'),
        'rad_info_no' : fields.char ('Info No.', size=128,),
        'ward_name' : fields.char ('Ward', size=128,),
        'bed_name' : fields.char ('Bed', size=128,),
        'price' : fields.float ('Price'),
        'phic_balance' : fields.float ('Balance'),
        'charge_to' : fields.boolean ('Charge to Sponsor'),
        'pdaf_balance' : fields.float ('Balance'),
        'sponsor_ids' : fields.char ('Sponsor ID', size = 20),
        'partner_sponsor_id': fields.many2one('res.partner', 'Charge to', change_default=True, select=1, domain="[('donor', '=', True)]"),
        'rad_request_id' : fields.many2one('his.patient.rad.request','Rad Exam Request ID', change_default=True, select=True),
        'charge_to_phic' : fields.boolean ('Charge to PHIC'),
        'with_phic' : fields.boolean ('With PHIC'),
        'with_pdaf' : fields.boolean ('With PDAF'),
    }

    _defaults={
       'date' : lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
       'state' : lambda *a : 'draft',
       #'doctor_id' : _get_default_dr,
    }

his_patient_rad_exam()


class his_patient_rad_request(osv.osv):
    _name = "his.patient.rad.request"
    _description = "Rad Exam Request"
    _columns ={
       'patient_id' : fields.many2one('res.partner','Patient', change_default=True, select=True, domain="[('customer', '=', True)]"),
       'lab_section_no': fields.many2one('his.department.section','Rad Section', domain="[('hr_department_id.section_group','=','Radiology')]"),
       'date' : fields.datetime('Date'),
       'ward_name' : fields.char ('Ward', size=128,),
       'bed_name' : fields.char ('Bed', size=128,),
       'patient_adstatus' : fields.boolean ('Admitted'),
       'doctor_id' : fields.many2one('hr.employee','Doctor', domain="[('doctor','=',True)]", help="Doctor who Request the lab test."),
       'pricelist_id': fields.many2one('product.pricelist', 'Pricelist'),
       'his_patient_rad_exam' : fields.one2many('his.patient.rad.exam', 'rad_request_id', 'Rad Exam'),
       }
    
    _defaults={
       'date' : lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    def onchange_patient_id(self, cr, uid, ids, patient):
        if not patient:
            return {'value': {'pricelist_id': False}}

        val = {}
        val['patient_adstatus'] = False
        part = self.pool.get('res.partner').browse(cr, uid, patient)
        admitted = part.admitted
        if admitted == True:
            admission_id = self.pool.get('his.admission').search(cr, uid, [('name', '=', part.id),('state', '=', "Admitted")])
            val['patient_adstatus'] = True
            room_transfer_id = self.pool.get('his.room.transfer').search(cr, uid, [('admission_id', '=', admission_id[0]),('t_out', '=', False)])
            if room_transfer_id:
                room_transfer = self.pool.get('his.room.transfer').browse(cr, uid, room_transfer_id[0])
                ward=room_transfer.ward_no.name.name
                bed=room_transfer.bed_no.name.name
                val['ward_name'] = ward
                val['bed_name'] = bed

        pricelist = part.property_product_pricelist and part.property_product_pricelist.id or False
        if pricelist:
            val['pricelist_id'] = pricelist
        return {'value': val}
        
his_patient_rad_request()
