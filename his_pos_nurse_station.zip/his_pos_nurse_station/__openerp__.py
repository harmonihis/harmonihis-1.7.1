# -*- coding: utf-8 -*-
{

    'name' : 'POS for Nurse Stations',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['point_of_sale'],
    'description' : """

Point of Sale for Nurse Stations

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : ["data/his_pos_nurse_station_sequence.xml", "security/his_pos_nurse_station_security.xml"],
    "update_xml" : ["his_pos_nurse_station_view.xml", "data/his_pos_nurse_station_sequence.xml", "security/his_pos_nurse_station_security.xml"],
    "active": False 
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
