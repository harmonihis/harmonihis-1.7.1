import time
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from osv import fields, osv
from tools.translate import _

import logging
from PIL import Image

import netsvc
from decimal import Decimal
import decimal_precision as dp

from tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT, float_compare
from operator import itemgetter

_logger = logging.getLogger(__name__)

class his_pos_nurse_stations(osv.osv):
    _name = "his.pos.nurse.stations"
    _description = "POS for Nurse Stations"
    
    def onchange_admission_name(self, cr, uid, ids, admission_name):
        #raise osv.except_osv(_('Warning'),_(" '%s'.") % (admission_name))
        if admission_name:
            partner_patient_id = self.pool.get('his.admission').browse(cr, uid, admission_name).name.id
            return {'value': {'name': partner_patient_id}}
    
    def onchange_partner_id(self, cr, uid, ids, partner_id, partner_patient_id, part=False, context=None):
        #if not part:
        #    return {'value': {}}
        #pricelist = self.pool.get('res.partner').browse(cr, uid, part, context=context).property_product_pricelist.id
        pdaf_balance = 0.00
        if partner_patient_id:
            if partner_id:
                sponsored_patient = self.pool.get('his.sponsored.patients')
                sponsored_patient_id = sponsored_patient.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id),('name', '=', partner_id), ('state', '=', 1)])
                
                if sponsored_patient_id:
                    pdaf_balance = sponsored_patient.browse(cr, uid, sponsored_patient_id[0], context=None).balance
        
        return {'value': {'pdaf_balance' : pdaf_balance}}
        
    def onchange_partner_patient_id(self, cr, uid, ids, partner_patient_id):
        philhealth_balance = 0.00
        whitecard_balance = 0.00
        #sponsor_balance = 0.00
        
        if partner_patient_id:
            philhealth_balance = self.pool.get('philhealth.passbook').get_phic_passbook_balance(cr, uid, partner_patient_id, phic_passbook=True, bal='drugmed')
            
            whitecard = self.pool.get('white.card')
            whitecard_id = whitecard.search(cr, uid, [('name', '=', partner_patient_id), ('active', '=', 1)])
            if whitecard_id:
                whitecard_balance = whitecard.browse(cr, uid, whitecard_id[0], context=None).balance
                
            sponsor_ids = []
            his_sponsor = self.pool.get('his.sponsored.patients')
            for sponsor in his_sponsor.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id), ('state', '=', 1)]):
                if sponsor:
                    sponsor_ids.append(self.pool.get('his.sponsored.patients').browse(cr, uid, sponsor, context=None).name.id)
                    
            
            #sponsor_id = his_sponsor.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id), ('state', '=', True)])
            #if sponsor_id:
            #    sponsor_balance = his_sponsor.browse(cr, uid, sponsor_id[0], context=None).balance
                
        return {'value': {'philhealth_balance': philhealth_balance,
                          'whitecard_balance': whitecard_balance, 
                          #'pdaf_balance': sponsor_balance,
                          'sponsor_ids': str(sponsor_ids)}}
                          
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        #raise osv.except_osv(_('Warning'),_(" '%s'.") % (context))
        vals['trans_id'] = self.pool.get('ir.sequence').get(cr, uid, 'pos_nurse_station.trans_id')
        if context['default_state'] == "Recorded":
            vals['state'] = 'Recorded'
        else:
            vals['state'] = 'Draft'
        
        philhealth_balance = 0.00
        whitecard_balance = 0.00
        pdaf_balance = 0.00
        if vals.get('name',False):
            partner_patient_id = vals['name']

            if partner_patient_id:
                philhealth_balance = self.pool.get('philhealth.passbook').get_phic_passbook_balance(cr, uid, partner_patient_id, phic_passbook=True, bal='drugmed')
                
                whitecard = self.pool.get('white.card')
                whitecard_id = whitecard.search(cr, uid, [('name', '=', partner_patient_id), ('active', '=', 1)])
                if whitecard_id:
                    whitecard_balance = whitecard.browse(cr, uid, whitecard_id[0], context=None).balance
                
                if vals.get('partner_id',False):
                    partner_id = vals['partner_id']
                    if partner_id:
                        sponsor = self.pool.get('his.sponsored.patients')
                        sponsor_id = sponsor.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id), ('name', '=', partner_id), ('state', '=', True)])
                        if sponsor_id:
                            pdaf_balance = sponsor.browse(cr, uid, sponsor_id[0], context=None).balance
                    
                vals['philhealth_balance'] = philhealth_balance
                vals['whitecard_balance'] = whitecard_balance
                vals['pdaf_balance'] = pdaf_balance 
                
        return super(his_pos_nurse_stations, self).create(cr, uid, vals, context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        if type(ids) is dict or type(ids) is list:
            patient_data = self.read(cr, uid, ids, ['name', 'partner_id', 'state'])[0]
            if patient_data['state'] == 'Draft' or patient_data['state'] == 'Recorded':
                philhealth_balance = 0.00
                whitecard_balance = 0.00
                pdaf_balance = 0.00
                if patient_data['name'][0] or vals.get('name',False):
                    if vals.get('name', False):
                        partner_patient_id = vals['name']
                    else:
                        partner_patient_id = patient_data['name'][0]
                    if partner_patient_id:
                        philhealth_balance = self.pool.get('philhealth.passbook').get_phic_passbook_balance(cr, uid, partner_patient_id, phic_passbook=True, bal='drugmed')
                
                        whitecard = self.pool.get('white.card')
                        whitecard_id = whitecard.search(cr, uid, [('name', '=', partner_patient_id), ('active', '=', 1)])
                        if whitecard_id:
                            whitecard_balance = whitecard.browse(cr, uid, whitecard_id[0], context=None).balance
                        
                        sponsor_ids = []
                        for sponsor in self.pool.get('his.sponsored.patients').search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id), ('state', '=', 1)]):
                            if sponsor:
                                sponsor_ids.append(self.pool.get('his.sponsored.patients').browse(cr, uid, sponsor, context=None).name.id)
                        vals['sponsor_ids'] = str(sponsor_ids)
                        if patient_data['partner_id'] or vals.get('partner_id', False):
                            if vals.get('partner_id', False):
                                partner_id = vals.get('partner_id')
                            else:
                                partner_id = patient_data['partner_id']
                                partner_id = partner_id[0]
                                
                            if partner_id:
                                sponsored_patient = self.pool.get('his.sponsored.patients')
                                sponsored_patient_id = sponsored_patient.search(cr, uid, [('sponsored_patient_name', '=', partner_patient_id),('name', '=', partner_id), ('state', '=', 1)])
                            
                                if sponsored_patient_id:
                                    pdaf_balance = sponsored_patient.browse(cr, uid, sponsored_patient_id[0], context=None).balance
                        
                vals['philhealth_balance'] = philhealth_balance
                vals['whitecard_balance'] = whitecard_balance
                vals['pdaf_balance'] = pdaf_balance        
            if vals.get('partner_id') == False:
                vals['pdaf_balance'] = 0.00 
            #raise osv.except_osv(_('Warning'),_(" '%s'.") % (pdaf_balance))
            return super(his_pos_nurse_stations, self).write(cr, uid, ids, vals, context=context)
            
    def _amount_all_philhealth_balance(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        philhealth_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_phic in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('phic','=', 1)]):
                subtotal_phic = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_phic).price_subtotal_incl
                philhealth_used += subtotal_phic
            
            res[order.id] = cur_obj.round(cr, uid, cur, philhealth_used)
        return res
        
    def _amount_all_whitecard_balance(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        whitecard_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_whitecard in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('whitecard','=', 1)]):
                subtotal_whitecard = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_whitecard).price_subtotal_incl
                whitecard_used += subtotal_whitecard
                
            res[order.id] = cur_obj.round(cr, uid, cur, whitecard_used)
        return res
        
    def _amount_all_pdaf_balance(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        pdaf_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_pdaf in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('pdaf','=', 1)]):
                subtotal_pdaf = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_pdaf).price_subtotal_incl
                pdaf_used += subtotal_pdaf
                
            res[order.id] = cur_obj.round(cr, uid, cur, pdaf_used)
        return res
        
    def _amount_all_caap(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        caap_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_caap in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('caap','=', 1)]):
                subtotal_caap = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_caap).price_subtotal_incl
                caap_used += subtotal_caap
                
            res[order.id] = cur_obj.round(cr, uid, cur, caap_used)
        return res
        
    def _amount_all_ecart(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        ecart_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_ecart in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('ecart','=', 1)]):
                subtotal_ecart = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_ecart).price_subtotal_incl
                ecart_used += subtotal_ecart
                
            res[order.id] = cur_obj.round(cr, uid, cur, ecart_used)
        return res
    
    def _amount_all_cash(self, cr, uid, ids, name, args, context=None):
        res = {}
        cur_obj = self.pool.get('res.currency')
        cash_used = 0
        for order in self.browse(cr, uid, ids, context=None):
            cur = order.pricelist_id.currency_id
            for line_cash in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0]), ('cash','=', 1)]):
                subtotal_cash = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line_cash).price_subtotal_incl
                cash_used += subtotal_cash
                
            res[order.id] = cur_obj.round(cr, uid, cur, cash_used)
        return res
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        
        reads = self.read(cr, uid, ids, ['trans_id'])        
        res = []
        for record in reads:
            if record['trans_id'] == False:
                name = ""
            else:
                name = record['trans_id']
            res.append((record['id'], name))
        return res
        
    _columns = {
        'trans_id' : fields.char ('Transaction ID', size=20, readonly=True),
        'name' : fields.many2one ('res.partner', 'Patient Name', domain="[('customer','=',1), ('admitted','=',1)]", required="1"),
        'admission_name' : fields.many2one ('his.admission', 'Patient Name', domain="[('state','=','Admitted')]", required="1"),
        'date_encoded' : fields.datetime ('Date Encoded', readonly=True),
        'pos_line' : fields.one2many ('his.pos.nurse.stations.line', 'pos', 'POS Nurse Station - Line'),
        'shop_id': fields.many2one('sale.shop', 'Shop', required=True, readonly=True),
        'secondary_shop_id': fields.many2one('sale.shop', 'Secondary Shop', readonly=True),
        'user_id': fields.many2one('res.users', 'Encoded By', help="Person who encoded the Product/s.", readonly=True),
        'department_id': fields.many2one('hr.department', 'Department', readonly=True),
        'pricelist_id': fields.many2one('product.pricelist', 'Pricelist', required=True, readonly=True),
        'state' : fields.selection([('New', 'New'),
                                   ('Draft', 'Draft'),
                                   ('Recorded', 'Recorded'),
                                   ('Cancelled', 'Cancelled'),
                                   ('Partially Done', 'Partially Done'),
                                   ('Completely Done', 'Completely Done')],
                                  'State', readonly=True),
        'philhealth_balance' : fields.float ('Balance', readonly=True),
        'philhealth_used' : fields.function(_amount_all_philhealth_balance, string='Used', type="float"),
        'whitecard_balance' : fields.float ('Balance', readonly=True),
        'whitecard_used' : fields.function(_amount_all_whitecard_balance, string='Used', type="float"),
        'pdaf_balance' : fields.float ('Balance', readonly=True),
        'pdaf_used' : fields.function(_amount_all_pdaf_balance, string='Used', type="float"),
        'caap_used' : fields.function(_amount_all_caap, string='Used', type="float"),
        'ecart_used' : fields.function(_amount_all_ecart, string='Used', type="float"),
        'cash' : fields.function(_amount_all_cash, string='Used', type="float"),
        'sponsor_ids' : fields.char ('Sponsor ID', size = 20),
        'partner_id': fields.many2one('res.partner', 'Sponsor', change_default=True, select=1, domain="[('donor', '=', True)]", states={'Draft': [('readonly', False)], 'New': [('readonly', False)]}),
        'use_pdaf' : fields.boolean ('Use PDAF'),
        'with_phic' : fields.boolean ('With PHIC'),
        
    }
    
    def process_button(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        pos_nurse_data_line = self.pool.get('his.pos.nurse.stations.line')
        pos_order = self.pool.get('pos.order')
        pos_order_line = self.pool.get('pos.order.line')
        pos_nurse_data = self.read(cr, uid, ids, ['name', 'partner_id', 'trans_id','shop_id','secondary_shop_id','user_id','department_id','pricelist_id'])[0]
        
        patient_partner_id = pos_nurse_data['name'][0]
        trans_id = pos_nurse_data['trans_id']
        department_id = pos_nurse_data['department_id'][0]
        shop_id = pos_nurse_data['shop_id'][0]
        secondary_shop_id = pos_nurse_data['secondary_shop_id'][0]
        user_id = pos_nurse_data['user_id'][0]
        pricelist_id = int(pos_nurse_data['pricelist_id'][0])

#Check Available Quantity - Begin
        context_temp = {'shop':self.pool.get('res.users').browse(cr, uid, uid).shop_id}
        context_temp2 = {'shop':self.pool.get('res.users').browse(cr, uid, uid).secondary_shop_id} 

        warn_msg = 'Insufficient Product Quantity \n'
        x = 0
        y = 0
        for line in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos','=',ids[0])]):
            y += 1
            order_line = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line, context=context_temp)
            order_line_qty = order_line.qty
            order_line_qty_available = order_line.product_id.qty_available
            
            order_line2 = self.pool.get('his.pos.nurse.stations.line').browse(cr, uid, line, context=context_temp2)
            order_line_qty_available2 = order_line2.product_id.qty_available
            #raise osv.except_osv(_('Warning'),_(" '%s'.") % (order_line_qty_available2))
            if order_line_qty_available < order_line_qty:
                x = 1
                prod_name = order_line.product_id.name_template
                prod_item_code = order_line.product_id.default_code
                warn_msg += '\n Product Line No.: ' + str(y) \
                         + '\n    Item Code: ' + prod_item_code \
                         + '\n    Generic Name: ' + prod_name \
                         + '\n    You Plan to sell: ' + str(order_line_qty) \
                         + '\n    Available Quantity \n    - Main Stock: ' + str(order_line_qty_available) \
                         + '\n    - Temporary Stock: ' + str(order_line_qty_available2) + '\n'
        
        if x == 1:
            raise osv.except_osv(_('Warning'),_(" %s ") % (warn_msg))

#Check Available Quantity - End

        count_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0])], count=True)
        
        # For PHIC
        count_phic_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('phic','=',True),('done','=',False)], count=True)
        if count_phic_nurse_data_line > 0:
            pos_order.create(cr, uid, {'phic_passbook':True,
                                       'whitecard' : False,
                                       'pdaf' : False,
                                       'ecart' : False,
                                       'caap' : False,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       #'shop_id':shop_id, 
                                       #'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'partner_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('phic','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'phic':True, 
                                       'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': 'PHIC',
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, { 'done' : done, 'requested_qty':requested_qty, 'qty':0 })
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
        
        # For PDAF
        count_pdaf_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('pdaf','=',True),('done','=',False)], count=True)
        if count_pdaf_nurse_data_line > 0:
            partner_id = pos_nurse_data['partner_id'][0]
            # Get Sponsor IDS
            sponsor_ids = []
            
            for sponsor in self.pool.get('his.sponsored.patients').search(cr, uid, [('sponsored_patient_name', '=', patient_partner_id), ('state', '=', 1)]):
                if sponsor:
                    sponsor_ids.append(self.pool.get('his.sponsored.patients').browse(cr, uid, sponsor, context=None).name.id)
                    
            sponsor_ids = str(sponsor_ids)
            
            pos_order.create(cr, uid, {'charge_to' : True,
                                       'phic_passbook':False,
                                       'whitecard' : False,
                                       'pdaf' : True,
                                       'sponsor_ids': sponsor_ids,
                                       'partner_id' : partner_id,
                                       'ecart' : False,
                                       'caap' : False,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       #'shop_id':shop_id, 
                                       #'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('pdaf','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': 'PDAF',
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, {'done' : done, 'requested_qty':requested_qty, 'qty':0})
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
        
        # For Whitecard(MSS)
        count_whitecard_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('whitecard','=',True),('done','=',False)], count=True)
        if count_whitecard_nurse_data_line > 0:
            pos_order.create(cr, uid, {'phic_passbook':False,
                                       'whitecard' : True,
                                       'pdaf' : False,
                                       'ecart' : False,
                                       'caap' : False,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       #'shop_id':shop_id, 
                                       #'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'partner_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('whitecard','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': 'MSS',
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, {'done' : done, 'requested_qty':requested_qty, 'qty':0})
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
                        
        # For Cash
        count_cash_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('cash','=',True),('done','=',False)], count=True)
        if count_cash_nurse_data_line > 0:
            pos_order.create(cr, uid, {'phic_passbook':False,
                                       'whitecard' : False,
                                       'pdaf' : False,
                                       'ecart' : False,
                                       'caap' : False,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       #'shop_id':shop_id, 
                                       #'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'partner_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('cash','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                cash_charge = nurse_order_line.cash_charge
                payment_mode = 'Cash'
                if cash_charge == True:
                    payment_mode = 'Charged'
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': payment_mode,
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, {'done' : done, 'requested_qty':requested_qty, 'qty':0})
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
        
        # For CAAP
        count_caap_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('caap','=',True),('done','=',False)], count=True)
        if count_caap_nurse_data_line > 0:
            pos_order.create(cr, uid, {'phic_passbook':False,
                                       'whitecard' : False,
                                       'pdaf' : False,
                                       'ecart' : False,
                                       'caap' : True,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       #'shop_id':shop_id, 
                                       #'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'partner_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('caap','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'caap':True, 
                                       'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': 'CAAP',
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, {'done' : done, 'requested_qty':requested_qty, 'qty':0})
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
                
        # For ECART
        count_ecart_nurse_data_line = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('ecart','=',True),('done','=',False)], count=True)
        if count_ecart_nurse_data_line > 0:
            #ecart_partner_id = self.pool.get('hr.department').browse(cr, uid, department_id, context=None).nurse_partner_id.id
            pos_order.create(cr, uid, {'phic_passbook':False,
                                       'whitecard' : False,
                                       'pdaf' : False,
                                       'ecart' : True,
                                       'caap' : False,
                                       'phic_passbook_auto' : False,
                                       'pos_nurse_trans_id':trans_id, 
                                       'shop_id':shop_id, 
                                       'shop_id2':secondary_shop_id, 
                                       'user_id': uid,
                                       'pricelist_id': pricelist_id,
                                       'partner_patient_id': patient_partner_id,
                                       'partner_id': patient_partner_id,
                                       'walk_in': False})
            pos_order_id = pos_order.search(cr, uid, [('pos_nurse_trans_id','=',trans_id)])
            for rec in pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('ecart','=',True),('done','=',False)]):
                nurse_order_line = pos_nurse_data_line.browse(cr, uid, rec)
                product_id = nurse_order_line.product_id.id
                qty = nurse_order_line.qty
                requested_qty = nurse_order_line.requested_qty
                requested_qty -= qty
                done = False
                if requested_qty == 0:
                    done = True
                dose_frequency = nurse_order_line.dose_frequency
                price_unit = nurse_order_line.price_unit
                price_subtotal_incl = nurse_order_line.price_subtotal_incl
                pos_order_line.create(cr, uid, {'ecart':True, 
                                       'product_id':product_id, 
                                       'order_id':pos_order_id[0], 
                                       'qty':qty, 
                                       'discount': 0.00,
                                       'price_unit': price_unit,
                                       'payment_mode': 'Ecart',
                                       'dose_frequency': dose_frequency})
                pos_nurse_data_line.write(cr, uid, rec, {'done' : done, 'requested_qty':requested_qty, 'qty':0})
                pos_nurse_data_line.write(cr, uid, rec, {'phic' : False,'pdaf' : False,'whitecard' : False,'caap' : False,'ecart' : False,'cash' : False,'cash_charge' : False})
        
        count_nurse_data_line_done = pos_nurse_data_line.search(cr, uid, [('pos','=',ids[0]),('done','=',True)], count=True)
        remarks = 'Recorded'
        if count_nurse_data_line_done > 0:
            if count_nurse_data_line == count_nurse_data_line_done:
                remarks = 'Completely Done'
            else:
                remarks = 'Partially Done'
        return self.write(cr, uid, ids, {'state':remarks}, context=None)
    
    def unlink(self, cr, uid, ids, context=None):
        for rec in self.browse(cr, uid, ids, context=context):
            if rec.state not in ('Draft','Cancelled'):
                raise osv.except_osv(_('Unable to Delete !'), _('In order to delete, it must be Draft or Cancelled.'))
        return super(his_pos_nurse_stations, self).unlink(cr, uid, ids, context=context)
        
    def _default_secondary_shop(self, cr, uid, context=None):
        res={}
        res_users = self.pool.get('res.users')
        return res_users.browse(cr, uid, uid).secondary_shop_id.id
        
    def _default_shop(self, cr, uid, context=None):
        res={}
        res_users = self.pool.get('res.users')
        return res_users.browse(cr, uid, uid).shop_id.id
    
    def _default_pricelist(self, cr, uid, context=None):
        res = self.pool.get('sale.shop').search(cr, uid, [], context=context)
        if res:
            shop = self.pool.get('sale.shop').browse(cr, uid, res[0], context=context)
            return shop.pricelist_id and shop.pricelist_id.id or False
        return False
        
    def _get_user_department(self, cr, uid, ids, context=None):
        res={}
        res_users = self.pool.get('res.users')
        resource = self.pool.get('resource.resource')
        employee = self.pool.get('hr.employee')
        resource_id = resource.search(cr, uid, [('user_id','=',uid)])
        employee_id = employee.search(cr, uid, [('resource_id','=',resource_id)])
        return employee.browse(cr, uid, employee_id[0]).department_id.id
    
    def submit_button(self, cr, uid, ids, context=None):
        for rec in self.pool.get('his.pos.nurse.stations.line').search(cr, uid, [('pos', '=', ids[0])], context=None):
            self.pool.get('his.pos.nurse.stations.line').write(cr, uid, rec, {'recorded':True}, context=None)
        return self.write(cr, uid, ids, {'state':'Recorded'}, context=None)
    
    def cancel_button(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids, {'state':'Cancelled'}, context=None)
    
    def set_to_draft_button(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids, {'state':'Draft'}, context=None)
        
    _defaults = {
        'pricelist_id': _default_pricelist,
        'date_encoded': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'state' : 'New',
        'department_id': _get_user_department,
        'shop_id': _default_shop,
        'secondary_shop_id': _default_secondary_shop,
        'user_id': lambda self, cr, uid, context: uid,
        'sponsor_ids' : '[]',
    }
his_pos_nurse_stations ()

class his_pos_nurse_stations_line(osv.osv):
    _name = "his.pos.nurse.stations.line"
    _description = "POS for Nurse Stations - Line"
    
    def get_dose_frequency(self, cr, uid, ids, field_name, arg, context):
        dose_frequency = {}
        for line in self.browse(cr, uid, ids ,context):
            if line.dose == False:
                dose = ''
            else:
                dose = line.dose
            if line.frequency == False:
                frequency = ''
            else:
                frequency = ' - ' + line.frequency
            if line.routes == False:
                routes = ''
            else:
                routes = '(' + line.routes + ')'
            dose_frequency[line.id] = dose + frequency + routes
        return dose_frequency
        
    _columns = {
        'pos' : fields.many2one ('his.pos.nurse.stations', 'POS Nurse Station ID'),
        'product_id': fields.many2one('product.product', 'Product', domain=[('product_tmpl_id.type', '=', 'product')], required=True),
        'dose': fields.char('Dose', size=10),
        'routes': fields.selection([('Oral','Oral'), ('Topical','Topical'),('Inhalation','Inhalation'),('Injection-IV','Injection-IV'),('Injection-IM','Injection-IM'),('Injection-SC','Injection-SC')],'Route'),
        'frequency': fields.char('Freq.', size=50),
        'dose_frequency': fields.function(get_dose_frequency, method=True, fnct_search=None, string="Dose and Freq.", type="char", size=150, store=True),
        'qty': fields.float('Qty', digits=(16, 2)),
        'requested_qty': fields.float('QTS', digits=(16, 2)),
        'phic' : fields.boolean ('PHIC'),
        'pdaf' : fields.boolean ('PDAF'),
        'whitecard' : fields.boolean ('MSS'),
        'caap' : fields.boolean ('CAAP'),
        'ecart' : fields.boolean ('Ecart'),
        'cash' : fields.boolean ('Cash'),
        'cash_charge' : fields.boolean ('Charge'),
        'remarks' : fields.char ('Remarks', size=250),
        'price_unit': fields.float(string='Price', digits=(16, 2)),
        'price_subtotal_incl': fields.float(string='Subtotal', digits=(16, 2)),
        'done': fields.boolean('Processed'),
        'recorded': fields.boolean('Recorded'),
        'with_phic' : fields.related ('pos','with_phic',type="boolean",string='With PHIC', store=True),
    }
    
    _defaults = {
        'qty': lambda *a: 1,
        'requested_qty': lambda *a: 1
    }
    
    def onchange_product_id(self, cr, uid, ids, shop_id2, pricelist, product_id, qty=0, partner_id=False, context=None):
        
        context = context or {}
        
        if not product_id:
            return {}
        if not pricelist:
            raise osv.except_osv(_('No Pricelist !'),
                _('You have to select a pricelist in the sale form !\n' \
                'Please set one before choosing a product.'))

        price = self.pool.get('product.pricelist').price_get(cr, uid, [pricelist],
                product_id, qty or 1.0, partner_id)[pricelist]
        #raise osv.except_osv(_('Warning'),_(" '%s'.") % (price))
        result = self.onchange_qty(cr, uid, ids, product_id, qty, price, shop_id2, requested_qty=1, context=context)
        result['value']['price_unit'] = price
        
        return result
        
    def onchange_phic(self, cr, uid, ids, phic, philhealth_balance, price_subtotal, trans_id, product_id, caap, pdaf, cash):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        warn_msg = "Philhealth Passbook\n Insufficient Balance!\n\n Current Balance: "
        if phic == True:
            philhealth_used = price_subtotal
            his_pos_id = self.pool.get('his.pos.nurse.stations').search(cr, uid, [('trans_id','=',trans_id)])
            for rec in self.search(cr, uid, [('phic','=',True), ('pos','=',his_pos_id[0])]):
                his_pos_line = self.browse(cr, uid, rec)
                philhealth_used += his_pos_line.price_subtotal_incl
            if philhealth_balance >= philhealth_used:
                self.write(cr, uid, ids, {'phic':True}, context=None)
                result = {'value':{'pdaf':False, 'whitecard':False, 'cash':False, 'price_unit': selling_price}}
            else:
                if philhealth_balance == 0:
                    warn_msg += "Zero(0.00)."
                else:
                    warn_msg += str("%.2f" % philhealth_balance) + "\nAmount Charged: " + str("%.2f" % (philhealth_used - price_subtotal)) + "\n\nYou plan to charge additional " + str("%.2f" % price_subtotal)
                result = {'value':{'phic':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
        else:
            self.write(cr, uid, ids, {'phic':False}, context=None)
            if caap == True and (pdaf == True or cash == True):
                result = {'value':{'price_unit': selling_price}}
            else:
                if pdaf == True or cash == True:
                    result = {'value':{'price_unit': selling_price}}
                else:
                    result = {'value':{'price_unit': cost_price}}
        return result
            
    def onchange_pdaf(self, cr, uid, ids, pdaf, pdaf_balance, price_subtotal, trans_id, product_id, caap, phic, cash):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        warn_msg = "PDAF\n Insufficient Balance!\n\n Current Balance: "
        if pdaf == True:
            pdaf_used = price_subtotal
            his_pos_id = self.pool.get('his.pos.nurse.stations').search(cr, uid, [('trans_id','=',trans_id)])
            for rec in self.search(cr, uid, [('pdaf','=',True), ('pos','=',his_pos_id[0])]):
                his_pos_line = self.browse(cr, uid, rec)
                pdaf_used += his_pos_line.price_subtotal_incl
            if pdaf_balance >= pdaf_used:
                self.write(cr, uid, ids, {'pdaf':True}, context=None)
                result = {'value':{'phic':False, 'whitecard':False, 'cash':False,  'price_unit': selling_price}}
            else:
                if pdaf_balance == 0:
                    warn_msg += "Zero(0.00)."
                else:
                    warn_msg += str("%.2f" % pdaf_balance) + "\nAmount Charged: " + str("%.2f" % (pdaf_used - price_subtotal)) + "\n\nYou plan to charge additional " + str("%.2f" % price_subtotal)
                result = {'value':{'pdaf':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
        else:
            self.write(cr, uid, ids, {'pdaf':False}, context=None)
            if caap == True and (phic == True or cash == True):
                result = {'value':{'price_unit': selling_price}}
            else:
                if phic == True or cash == True:
                    result = {'value':{'price_unit': selling_price}}
                else:
                    result = {'value':{'price_unit': cost_price}}
        return result
        
    def onchange_whitecard(self, cr, uid, ids, whitecard, whitecard_balance, price_subtotal, trans_id, product_id, caap):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        warn_msg = "Whitecard(MSS)\n Insufficient Balance!\n\n Current Balance: "
        if whitecard == True:
            whitecard_used = price_subtotal
            his_pos_id = self.pool.get('his.pos.nurse.stations').search(cr, uid, [('trans_id','=',trans_id)])
            for rec in self.search(cr, uid, [('whitecard','=',True), ('pos','=',his_pos_id[0])]):
                his_pos_line = self.browse(cr, uid, rec)
                whitecard_used += his_pos_line.price_subtotal_incl
            if whitecard_balance >= whitecard_used:
                self.write(cr, uid, ids, {'whitecard':True}, context=None)
                result = {'value':{'pdaf':False, 'phic':False, 'cash':False, 'price_unit':cost_price}}
            else:
                if whitecard_balance == 0:
                    warn_msg += "Zero(0.00)."
                else:
                    warn_msg += str("%.2f" % whitecard_balance) + "\nAmount Charged: " + str("%.2f" % (whitecard_used - price_subtotal)) + "\n\nYou plan to charge additional " + str("%.2f" % price_subtotal)
                result = {'value':{'whitecard':False}, 'warning':{'title':'Warning', 'message':warn_msg}}
        else:
            self.write(cr, uid, ids, {'whitecard':False}, context=None)
            #if caap == True:
            #    result = {'value':{'price_unit':cost_price}}
            #else:
            #    result = {'value':{'price_unit':selling_price}}
            #raise osv.except_osv(_('Warning'),_(" '%s'.") % (selling_price))
        return result
            
    def onchange_caap(self, cr, uid, ids, caap, product_id, phic, pdaf, whitecard, cash):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        #if caap == True:
        if phic == True or pdaf == True or cash == True:
            result = {'value':{'price_unit':selling_price}}
        else:
            result = {'value':{'price_unit':cost_price}}
        #else:
        #   if phic == True or pdaf == True or cash == True:
        #        result = {'value':{'price_unit':selling_price}}
        #    result = {'value':{'price_unit':selling_price}}
        return result
            
    def onchange_ecart(self, cr, uid, ids, ecart, phic, pdaf, whitecard, caap, cash, product_id):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        if ecart == True:
            if whitecard == True or caap == True:
                result = {'value':{'price_unit':cost_price}}
            elif phic == True or pdaf == True or cash == True:
                result = {'value':{'price_unit':selling_price}}
        return result

    def onchange_cash(self, cr, uid, ids, cash, product_id, caap, phic, pdaf):
        result = {}
        cost_price = self.pool.get('product.template').browse(cr, uid, product_id).standard_price
        selling_price = self.pool.get('product.template').browse(cr, uid, product_id).list_price
        if cash == True:
            result = {'value':{'pdaf':False, 'whitecard':False, 'phic':False, 'price_unit': selling_price, 'cash_charge':False}}
        else:
            if caap == True and (pdaf == True or phic == True):
                result = {'value':{'price_unit': selling_price,'cash_charge':False}}
            else:
                if pdaf == True or phic == True:
                    result = {'value':{'price_unit': selling_price,'cash_charge':False}}
                else:
                    result = {'value':{'price_unit': cost_price,'cash_charge':False}}
        return result

    def onchange_price_unit(self, cr, uid, ids, price_unit, qty):
        result = {}
        result = {'value':{'price_subtotal_incl': price_unit * qty}}
        return result
        
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}

        if vals.get('cash') == False:
            vals['cash_charge'] = False
        #raise osv.except_osv(_('Warning'),_(" '%s'.") % (pdaf_balance))
        return super(his_pos_nurse_stations_line, self).write(cr, uid, ids, vals, context=context)
            
    def onchange_qty(self, cr, uid, ids, product, qty, price_unit, shop_id2, requested_qty, context=None):
        result = {}
        
        if not product:
            return result
        account_tax_obj = self.pool.get('account.tax')
        cur_obj = self.pool.get('res.currency')

        prod = self.pool.get('product.product').browse(cr, uid, product, context=context)
        
        taxes = prod.taxes_id
        price = price_unit * (1 - (0.0) / 100.0)
        #discount_amt = (price_unit * ((discount or 0.0) / 100.0)) * qty
        taxes = account_tax_obj.compute_all(cr, uid, prod.taxes_id, price, qty, product=prod, partner=False)

        #result['price_subtotal'] = taxes['total']
        result['price_subtotal_incl'] = taxes['total_included']
        #result['discount_amt'] = discount_amt
        if qty <= requested_qty:
            my_product_obj = self.pool.get('product.product')
            my_context = {'shop': self.pool.get('res.users').browse(cr, uid, uid).shop_id}
            product_obj = my_product_obj.browse(cr, uid, product, context=my_context)
                    
            compare_qty = float_compare(product_obj.qty_available, qty, precision_rounding=product_obj.uom_id.rounding)

            if (product_obj.type=='product') and int(compare_qty) == -1 \
              and (product_obj.procure_method=='make_to_stock'):
                
                warn_msg = _('OUT OF STOCK \n\n Itemd Code: %s \n Generic Name: %s \n\n Available Quantity \n - Main Stock: %.2f %s \n') % \
                        (product_obj.default_code, 
                        product_obj.name_template, 
                        max(0,product_obj.qty_available), product_obj.uom_id.name)
                if shop_id2:
                    my_context2 = {'shop': self.pool.get('res.users').browse(cr, uid, uid).secondary_shop_id}
                    product_obj1 = my_product_obj.browse(cr, uid, product, context=my_context2)
                    warn_msg += _(' - Temporary Stock: %.2f %s') % (max(0,product_obj1.qty_available), product_obj1.uom_id.name)
                        
                result = {'value':{'qty':max(0,product_obj.qty_available)}, 'warning':{'title':'Warning', 'message':warn_msg}}
                return result
        else:
            my_product_obj = self.pool.get('product.product')
            my_context = {'shop': self.pool.get('res.users').browse(cr, uid, uid).shop_id}
            product_obj = my_product_obj.browse(cr, uid, product, context=my_context)
            if max(0,product_obj.qty_available) >= requested_qty:
                qty_to_serve = requested_qty
            else:
                qty_to_serve = max(0,product_obj.qty_available)
            result['qty'] = qty_to_serve
            return {'value':result, 'warning':{'title':'Warning', 'message':'Quantity to Serve cannot be greater than to Quantity Requested'}}
        return {'value': result}

his_pos_nurse_stations_line ()

class pos_order_custom(osv.osv):

    _name = "pos.order"
    _inherit = "pos.order"
    _columns = {
        'pos_nurse_trans_id' : fields.char ('POS Nurse Transaction ID', size=20),
    }
pos_order_custom ()

class pos_order_line_custom(osv.osv):

    _name = "pos.order.line"
    _inherit = "pos.order.line"
    _columns = {
        'dose_frequency' : fields.char ('Dose and Frequency', size=150),
    }
pos_order_line_custom ()

