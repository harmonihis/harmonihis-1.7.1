import time
from dateutil.relativedelta import relativedelta
from datetime import datetime
from osv import fields, osv
from tools.translate import _

class product_critical_level (osv.osv):

    _name = "product.critical_level"
    _description = "Critical Level"
    
    def _qty_available(self, cr, uid, ids, field_list, arg, context=None):
		res = {}
		for line1 in self.browse(cr, uid, ids):
			shop_id = line1.shop_name
			product_id1 = line1.product_name
			my_context = {'shop': shop_id}
			for line in self.browse(cr, uid, ids, context = my_context):
				if product_id1 == line.product_name:
				    product_id = line.product_name.qty_available
			res[line1.id] = product_id
		return res
        
    def _state(self, cr, uid, ids, field_list, arg, context=None):
        res = {}
        for line in self.browse(cr, uid, ids):
			qty_available = line.qty_available
			critical_level = line.critical_level
			if qty_available > critical_level:
				_state = "Above Critical"
			elif qty_available < critical_level:
				_state = "Below Critical"
			else:
				_state = "Equal to Critical"	
			res[line.id] = _state
        return res
    
    _columns = {
        'product_name' : fields.many2one ('product.product', '[Item Code]Generic Name'),
        'shop_name' : fields.many2one ('sale.shop', 'Shop Name'),
        'qty_available' : fields.function (_qty_available, method=True, string="Quantity Available", type="integer", size=10),
        'critical_level' : fields.integer ('Critical Level'),
        'state' : fields.function (_state, method=True, fnct_search=None, string="State", type="char", size=20),
    }
    
    def onchange_shop(self, cr, uid, ids, product_name, shop_name, context=None):
		result = {}
		product_id = product_name
		shop_id = shop_name
		if product_id and shop_id:
		    my_context =  {'shop': shop_id}
		    prod = self.pool.get('product.product').browse(cr, uid, product_id, context=my_context)
		    result['qty_available'] = prod.qty_available
		else:
			result['qty_available'] = 0.00
		return {'value':result}
		
    def create(self, cr, uid, vals, context=None):
        prod_id = vals['product_name']
        shop_id = vals['shop_name']
        count_config = self.search(cr, uid, [('product_name','=',prod_id),('shop_name','=',shop_id)])
        if count_config:
			prod = self.browse(cr, uid, count_config[0], context=None)
			raise osv.except_osv(_('Warning'),_('Shop Name: \n - %s \n Item Code: \n - %s \n Generic Name: \n - %s \n\n This product had already set the critical level to %s.') % (prod.shop_name.name, prod.product_name.default_code, prod.product_name.name_template, prod.critical_level))
        else:
            return super(product_critical_level, self).create(cr, uid, vals, context)

product_critical_level ()
