{

    'name' : 'Product Customizations',  
    'version' : '3.0',
    'author' : 'Jaynar L. Santos',
    'category' : 'Generic Modules/Others',
    'complexity': "easy",
    'depends' : ['product', 'hospital_mgmt', 'sale'],
    'description' : """

Product Customizations

""",
    "website" : "http://www.fossibility.com",
    "init_xml" : [],
    "update_xml" : ["product_custom_view.xml", "security/product_custom_security.xml"],
    "active": False 
}
