import time
from dateutil.relativedelta import relativedelta
from datetime import datetime
from osv import fields, osv
from tools.translate import _

class product_customization (osv.osv):

    _name = "product.product"
    _inherit = "product.product"
    _columns = {
        'medicine_code' : fields.char ('Medicine Code', size=15),
        'brand' : fields.many2one ('product.brand', 'Brand'),
        'dosage' : fields.many2one ('product.dosage', 'Dosage'),
        'app_discount' : fields.boolean ('Do not apply discounts'),
    }

    def copy(self, cr, uid, id, default=None, context=None):
        if context is None:
            context={}

        if not default:
            default = {}

        # Craft our own `<name> (copy)` in en_US (self.copy_translation()
        # will do the other languages).
        context_wo_lang = context.copy()
        context_wo_lang.pop('lang', None)
        product = self.read(cr, uid, id, ['name'], context=context_wo_lang)
        default = default.copy()
        default['name'] = product['name']
        #raise osv.except_osv(_('Error !'),_('Name: ' + product['name']))
        default['standard_price'] = '0.00'
        default['list_price'] = '0.00'
        default['default_code'] = ''

        if context.get('variant',False):
            fields = ['product_tmpl_id', 'active', 'variants', 'default_code',
                    'price_margin', 'price_extra']
            data = self.read(cr, uid, id, fields=fields, context=context)
            for f in fields:
                if f in default:
                    data[f] = default[f]
            data['product_tmpl_id'] = data.get('product_tmpl_id', False) \
                    and data['product_tmpl_id'][0]
            del data['id']
            return self.create(cr, uid, data)
        else:
            return super(product_customization, self).copy(cr, uid, id, default=default, context=context)

    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context={}

        itemcode = ''
        #Get the original values (dosage, categ_id, brand) before the modifications to this record
        product = self.read(cr, uid, ids, ['default_code','medicine_code','dosage','categ_id','brand','standard_price','list_price'])[0]
        default_code = product['default_code']
        medicine_code = product['medicine_code']
        dosage = product['dosage'] and product['dosage'][0]
        categ_id = product['categ_id'] and product['categ_id'][0]
        brand = product['brand'] and product['brand'][0]
        standard_price = product['standard_price']
        list_price = product['list_price']

        #Check if the dosage was updated
        if vals.get('dosage', False):
            dosage = vals['dosage']
        if dosage:
            if not default_code or vals.get('categ_id', False) or vals.get('brand', False) or vals.get('standard_price', False) or vals.get('list_price', False):
                dosage_code = self.pool.get('product.dosage').browse(cr, uid, dosage).code
                if dosage_code:
                    itemcode += dosage_code
                    #Since the Dosage field was used, we continue with the creation of the ItemCode
                    #Check if categ_id was updated
                    if vals.get('categ_id', False):
                        categ_id = vals['categ_id']
                    if categ_id:
                        categ_code = self.pool.get('product.category').browse(cr, uid, categ_id).code
                        if categ_code:
                            itemcode += categ_code
                        else:
                            itemcode += 'NOCATEGORY'
                    #Check if brand was updated
                    if vals.get('brand', False):
                        brand = vals['brand']
                    if brand:
                        brand_code = self.pool.get('product.brand').browse(cr, uid, brand).code
                        if brand_code:
                            itemcode += brand_code
                        else:
                            itemcode += 'NOBRAND'

                    if vals.get('standard_price', False) or vals.get('list_price', False):
                        #Check if price was updated
                        if vals.get('standard_price', False):
                            standard_price = vals['standard_price']

                        if vals.get('list_price', False):
                            list_price = vals['list_price']

                        #Check if product already exist and the product cost is unique
                        prodexist = self.search(cr, uid, [('medicine_code','=',medicine_code),('standard_price','=',standard_price),('list_price','=',list_price)])

                        if prodexist:
                            raise osv.except_osv(_('Error !'),_('Cannot save this record because a product with the same dosage, brand, category, selling price and unit cost already exist.'))

                #Generate a unique number based on the product category selected
                maxmedcode = self.search(cr, uid, [('medicine_code','=',medicine_code)], order='default_code')
                
                if maxmedcode:
                    maxmedcode_count = self.search(cr, uid, [('medicine_code','=',medicine_code)], count=True)
                    if maxmedcode_count and maxmedcode > 0:
                        maxmedcode_count -= 1
                    else:
                        maxmedcode_count = 0

                    maxmedcode = self.browse(cr, uid, maxmedcode)[maxmedcode_count]
                    
                    #raise osv.except_osv(_('Error :'), _("Code: %s.") %(maxmedcode.default_code))
                    if not maxmedcode.default_code:
                        maxmedcode = 1
                    else:
                        #raise osv.except_osv(_('Error :'), _("Code: %s.") %(maxmedcode.default_code))
                        maxmedcode = maxmedcode.default_code
                        
                        maxmedcode = int(maxmedcode[9:]) + 1
                else:
                    maxmedcode = 1
                
                itemcode += str(maxmedcode)
                #raise osv.except_osv(_('Error :'), _("Code: %s.") %(itemcode))

                #Apply changes to the ItemCode    
                vals.update({'default_code': itemcode})

            else:
                vals.update({'default_code': default_code})

        #Check if medicine_code was updated
        if vals.get('medicine_code', False):
            medicine_code = vals['medicine_code']

        if vals.get('medicine_code', False) or vals.get('categ_id', False) or vals.get('brand', False) or vals.get('dosage', False):
            #Check if medicine code already exist with the same brand, dosage and category
            med_code_exist = self.search(cr, uid, [('medicine_code','=',medicine_code)])

            if med_code_exist:
                brand_dosage_categ_id = self.search(cr, uid, [('brand','=',brand), ('dosage','=',dosage), ('categ_id','=',categ_id)])
                if not brand_dosage_categ_id:
                    raise osv.except_osv(_('Error !'),_('Medicine code already exist.'))
                else:
                    raise osv.except_osv(_('Error !'),_('Please check Medicine code.'))

        return super(product_customization, self).write(cr, uid, ids, vals, context=context)

product_customization ()

class product_brand (osv.osv):

    _name = "product.brand"
    _description = "Product Brands"
    _columns = {
         'name' : fields.char ('Brand',size=50),	
         'code' : fields.char ('Code', size=4, readonly=True, help='Four(4) digits numeric value that will be part of the Product Item Code'),
    }

    def _default_sequence(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        max_sequence = 0
        brand_code_id = self.search(cr, uid, [('code','!=','')], order='code')
        brand_code_count = self.search(cr, uid, [('code','!=','')], count=True)
        
        if brand_code_count > 0:
            code = self.browse(cr, uid, brand_code_id)[brand_code_count - 1]
            code = int(code.code) + 1
        else:
			code = 1
			
        if code >= 0 and code <= 9:
            max_sequence = '000' + str(code)
        elif code >= 10 and code <= 99:
            max_sequence = '00' + str(code)
        elif code >= 100 and code <= 999:
            max_sequence = '0' + str(code)
        else:
            max_sequence = str(code)
        #raise osv.except_osv(_('Error :'), _("Code: %s.") %(max_sequence))
        return max_sequence

    _defaults = {
        'code': lambda obj, cr, uid, context: obj._default_sequence(cr, uid, context),
    }

product_brand ()

class product_dosage (osv.osv):

    _name = "product.dosage"
    _description = "Product Dosage"
    _columns = {
         'name' : fields.char ('Dosage',size=150),	
         'code' : fields.char ('Code', size=3, readonly=True, help='Three(3) digits numeric value that will be part of the Product Item Code'),
    }

    def _default_sequence(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        max_sequence = 0
        brand_code_id = self.search(cr, uid, [('code','!=','')], order='code')
        brand_code_count = self.search(cr, uid, [('code','!=','')], count=True)
        if brand_code_count > 0:
			code = self.browse(cr, uid, brand_code_id)[brand_code_count - 1]
			code = int(code.code) + 1
        else:
		    code = 1
		    
        
        if code >= 0 and code <= 9:
            max_sequence = '00' + str(code)
        elif code >= 10 and code <= 99:
            max_sequence = '0' + str(code)
        else:
            max_sequence = str(code)
        #raise osv.except_osv(_('Error :'), _("Code: %s.") %(max_sequence))
        return max_sequence

    _defaults = {
        'code': lambda obj, cr, uid, context: obj._default_sequence(cr, uid, context),
    }

product_dosage ()

class product_category_customization (osv.osv):

    _inherit = "product.category"
    _columns = {
        'code' : fields.char ('Code', size=2, readonly=True, help='Two(2) digits numeric value that will be part of the Product Item Code'),
    }

    def _default_sequence(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        max_sequence = 0
        brand_code_id = self.search(cr, uid, [('code','!=','')], order='code')
        brand_code_count = self.search(cr, uid, [('code','!=','')], count=True)
        if brand_code_count > 0:
			code = self.browse(cr, uid, brand_code_id)[brand_code_count - 1]
			code = int(code.code) + 1
        else:
			code = 1
		
        if code >= 0 and code <= 9:
            max_sequence = '0' + str(code)
        else:
            max_sequence = str(code)
            
        #raise osv.except_osv(_('Error :'), _("Code: %s.") %(max_sequence))
        return max_sequence

    _defaults = {
        'code': lambda obj, cr, uid, context: obj._default_sequence(cr, uid, context),
    }

product_category_customization ()
